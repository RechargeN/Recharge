package com.example.rechargenew.ui.categories

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rechargenew.data.categories.CategoriesRepository
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.model.EventCategory
import com.example.rechargenew.ui.events.EventCard
import com.example.rechargenew.ui.events.EventModel
import com.example.rechargenew.ui.events.filterEventsByCategoryAndSubcategory

/**
 * Экран C + D (вариант под именем SubcategoriesScreen):
 *  - сверху: красивые «пилюли» с категориями (мультивыбор)
 *  - ниже: подкатегории для ВСЕХ выбранных категорий (мультивыбор)
 *  - снизу: лента событий D, отфильтрованных по выбору.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubcategoriesScreen(
    viewModel: CategoriesViewModel = viewModel(),
    onCategoryClickExternal: (EventCategory) -> Unit = {},
    onEventClick: (String) -> Unit = {}
) {
    val context = LocalContext.current

    // Категории из VM
    val categories by viewModel.categories.collectAsState()

    // Все субкатегории (загрузим один раз из репозитория)
    var allSubcategories by remember { mutableStateOf<List<SubcategoryItem>>(emptyList()) }

    // Локальный выбор
    var selectedCategories by remember { mutableStateOf<Set<EventCategory>>(emptySet()) }
    var selectedSubcategoryIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    // События
    var allEvents by remember { mutableStateOf<List<EventModel>>(emptyList()) }
    var filteredEvents by remember { mutableStateOf<List<EventModel>>(emptyList()) }

    // Один раз подгружаем данные
    LaunchedEffect(Unit) {
        viewModel.loadCategories(context)

        val subsData = CategoriesRepository.getSubcategories(context)
        allSubcategories = subsData.map { it.toUi() }

        val events = EventRepository.getAllEvents()
        allEvents = events
        filteredEvents = events
    }

    // Подкатегории, которые нужно показывать: объединение по всем выбранным категориям
    val visibleSubcategories by remember(allSubcategories, selectedCategories) {
        mutableStateOf(
            if (selectedCategories.isEmpty()) {
                emptyList()
            } else {
                allSubcategories.filter { it.parent in selectedCategories }
            }
        )
    }

    // Пересчёт D при изменении фильтра
    LaunchedEffect(allEvents, selectedCategories, selectedSubcategoryIds) {
        filteredEvents = filterEventsByCategoryAndSubcategory(
            allEvents = allEvents,
            selectedCategories = selectedCategories,
            selectedSubcategoryIds = selectedSubcategoryIds
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Categories") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {

            // ───── Категории (C, мультивыбор) ─────
            Text(
                text = "What mood are you in?",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(categories) { category ->
                    val isSelected = selectedCategories.contains(category.id)

                    CategoryChip(
                        category = category,
                        isSelected = isSelected,
                        onClick = {
                            selectedCategories =
                                if (isSelected) {
                                    selectedCategories - category.id
                                } else {
                                    selectedCategories + category.id
                                }

                            // вычищаем sub, которые больше не принадлежат выбранным категориям
                            selectedSubcategoryIds =
                                selectedSubcategoryIds.filter { subId ->
                                    allSubcategories.any {
                                        it.id == subId && it.parent in selectedCategories
                                    }
                                }.toSet()

                            onCategoryClickExternal(category.id)
                        }
                    )
                }
            }

            // ───── Подкатегории (C-sub, мультивыбор) ─────
            if (visibleSubcategories.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Fine tune your vibe",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(visibleSubcategories, key = { it.id }) { sub ->
                        val isSelected = selectedSubcategoryIds.contains(sub.id)

                        SubcategoryChip(
                            subcategory = sub,
                            isSelected = isSelected,
                            onClick = {
                                selectedSubcategoryIds =
                                    if (isSelected) {
                                        selectedSubcategoryIds - sub.id
                                    } else {
                                        selectedSubcategoryIds + sub.id
                                    }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // ───── Лента D ─────
            Text(
                text = "Matching activities",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (filteredEvents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No activities for this combo yet.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredEvents, key = { it.id }) { event ->
                        EventCard(
                            event = event,
                            onClick = { id -> onEventClick(id) },
                            onToggleFavorite = { e ->
                                val toggled = e.copy(isFavorite = !e.isFavorite)
                                allEvents = allEvents.map {
                                    if (it.id == toggled.id) toggled else it
                                }

                                filteredEvents = filterEventsByCategoryAndSubcategory(
                                    allEvents = allEvents,
                                    selectedCategories = selectedCategories,
                                    selectedSubcategoryIds = selectedSubcategoryIds
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

// ───────────────────── UI-элементы ─────────────────────

@Composable
private fun CategoryChip(
    category: CategoryItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .height(56.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(28.dp),
        color = if (isSelected)
            MaterialTheme.colorScheme.primaryContainer
        else
            MaterialTheme.colorScheme.surface,
        contentColor = if (isSelected)
            MaterialTheme.colorScheme.onPrimaryContainer
        else
            MaterialTheme.colorScheme.onSurface,
        tonalElevation = if (isSelected) 4.dp else 1.dp,
        border = if (!isSelected)
            BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        else null
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Эмодзи чуть крупнее
            Text(
                text = category.emoji,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = category.title,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (category.subtitle.isNotBlank()) {
                    Text(
                        text = category.subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun SubcategoryChip(
    subcategory: SubcategoryItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(50),
        color = if (isSelected)
            MaterialTheme.colorScheme.secondaryContainer
        else
            MaterialTheme.colorScheme.surface,
        contentColor = if (isSelected)
            MaterialTheme.colorScheme.onSecondaryContainer
        else
            MaterialTheme.colorScheme.onSurface,
        tonalElevation = if (isSelected) 2.dp else 0.dp,
        border = if (!isSelected)
            BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
        else null
    ) {
        Text(
            text = subcategory.title,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
