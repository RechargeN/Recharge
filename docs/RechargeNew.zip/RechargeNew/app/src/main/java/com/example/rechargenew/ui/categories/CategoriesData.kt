package com.example.rechargenew.ui.categories

/**
 * Модель категории для блока C.
 * id должен совпадать с category в EventModel (D) – тогда фильтрация будет точной.
 * Для "Все" id = null.
 */
data class EventCategory(
    val id: String?,       // "Comedy", "Games", ... или null для "All"
    val title: String,     // заголовок
    val subtitle: String,  // короткое описание
    val emoji: String      // иконка-эмодзи
)

object CategoriesData {

    val categories: List<EventCategory> = listOf(
        EventCategory(
            id = null,
            title = "Все",
            subtitle = "Все активности рядом",
            emoji = "⭐"
        ),
        EventCategory(
            id = "Comedy",
            title = "Комедия",
            subtitle = "Стендапы и юмор",
            emoji = "🎤"
        ),
        EventCategory(
            id = "Games",
            title = "Настолки",
            subtitle = "Игры и квизы",
            emoji = "🎲"
        ),
        EventCategory(
            id = "Sport",
            title = "Спорт",
            subtitle = "Йога, бег, тренировки",
            emoji = "🏃"
        ),
        EventCategory(
            id = "Walk",
            title = "Прогулки",
            subtitle = "Пешие маршруты и прогулки",
            emoji = "🚶"
        ),
        EventCategory(
            id = "Party",
            title = "Вечеринки",
            subtitle = "Клубы и встречи",
            emoji = "🎉"
        ),
        EventCategory(
            id = "Concert",
            title = "Концерты",
            subtitle = "Живая музыка",
            emoji = "🎵"
        ),
        EventCategory(
            id = "Workshop",
            title = "Обучение",
            subtitle = "Мастер-классы и курсы",
            emoji = "🧠"
        ),
        EventCategory(
            id = "Cinema",
            title = "Кино",
            subtitle = "Просмотры фильмов",
            emoji = "🎬"
        )
    )
}
