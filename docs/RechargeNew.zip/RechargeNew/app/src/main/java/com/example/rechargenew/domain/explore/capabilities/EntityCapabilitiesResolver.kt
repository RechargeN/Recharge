package com.example.rechargenew.domain.explore.capabilities

import com.example.rechargenew.domain.explore.model.AccessLevel
import com.example.rechargenew.domain.explore.model.EntityType
import com.example.rechargenew.domain.explore.model.UserRole

/**
 * Главная логика: EntityType + roles + access -> capabilities.
 * UI НЕ знает про роли — UI получает только capabilities.
 */
object EntityCapabilitiesResolver {

    fun resolve(
        entityType: EntityType,
        roles: Set<UserRole>,
        access: AccessLevel
    ): EntityPageCapabilities {

        return when (entityType) {
            EntityType.USER -> userPage(roles, access)
            EntityType.PLACE -> placePage(roles, access)
            EntityType.HOST -> hostPage(roles, access)
            EntityType.LOCATION -> locationPage(roles, access)
        }
    }

    private fun userPage(roles: Set<UserRole>, access: AccessLevel): EntityPageCapabilities {
        // USER page обычно принадлежит самому пользователю (access OWNER),
        // но если кто-то смотрит чужую — тогда VIEWER.
        val isSelf = access == AccessLevel.OWNER

        val isContributor = UserRole.CONTRIBUTOR in roles
        val isCreator = UserRole.CREATOR in roles
        val isVenueOwner = UserRole.VENUE_OWNER in roles

        return EntityPageCapabilities(
            canCreateEvent = isSelf && isCreator,
            canCreatePlace = isSelf && isContributor,
            canEditEntity = isSelf,

            canManageEvents = isSelf && isCreator,
            canManageLocation = isSelf && isVenueOwner,

            canComment = true,
            canRateEvents = true,

            canRequestUpgrade = isSelf // апгрейд показываем только на своей user page
        )
    }

    private fun placePage(roles: Set<UserRole>, access: AccessLevel): EntityPageCapabilities {
        val isContributor = UserRole.CONTRIBUTOR in roles

        val canEdit = isContributor && (access == AccessLevel.OWNER || access == AccessLevel.EDITOR)

        return EntityPageCapabilities(
            canEditEntity = canEdit,
            canComment = true,
            // place может не иметь событий — оценка событий не обязательна
            canRateEvents = false,
            canRequestUpgrade = false
        )
    }

    private fun hostPage(roles: Set<UserRole>, access: AccessLevel): EntityPageCapabilities {
        val isCreator = UserRole.CREATOR in roles
        val isOwner = access == AccessLevel.OWNER

        val canManage = isCreator && isOwner

        return EntityPageCapabilities(
            canCreateEvent = canManage,
            canManageEvents = canManage,
            canEditEntity = canManage,
            canComment = true,
            canRateEvents = true,
            canRequestUpgrade = false
        )
    }

    private fun locationPage(roles: Set<UserRole>, access: AccessLevel): EntityPageCapabilities {
        val isVenueOwner = UserRole.VENUE_OWNER in roles
        val isOwnerOrEditor = access == AccessLevel.OWNER || access == AccessLevel.EDITOR

        val canManage = isVenueOwner && isOwnerOrEditor

        return EntityPageCapabilities(
            canCreateEvent = canManage,
            canManageEvents = canManage,
            canManageLocation = canManage,
            canEditEntity = canManage,
            canComment = true,
            canRateEvents = true,
            canRequestUpgrade = false
        )
    }
}
