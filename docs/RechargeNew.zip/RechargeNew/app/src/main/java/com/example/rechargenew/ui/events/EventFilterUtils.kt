package com.example.rechargenew.ui.events

import com.example.rechargenew.model.EventCategory

/**
 * Фильтрация D по выбору в блоке C.
 *
 * selectedSubcategoryId – строковый id подкатегории из subcategories.json
 * (например "music_concerts"). Он должен лежать в EventModel.tags.
 */
fun filterEventsByCategoryAndSubcategory(
    allEvents: List<EventModel>,
    selectedCategories: Set<EventCategory>,
    selectedSubcategoryId: String?
): List<EventModel> {

    // имена категорий в верхнем регистре, чтобы сравнение было нечувствительно к регистру
    val selectedCategoryNames = selectedCategories
        .map { it.name.uppercase() }
        .toSet()

    val selectedSubUpper = selectedSubcategoryId?.uppercase()

    return allEvents.filter { event ->
        val eventCategory = event.category.uppercase()
        val tagsUpper = event.tags.map { it.uppercase() }.toSet()

        // совпадение по категориям:
        //  - либо category совпадает с выбранной
        //  - либо тег события содержит имя выбранной категории
        val matchCategory =
            if (selectedCategoryNames.isNotEmpty())
                eventCategory in selectedCategoryNames || tagsUpper.any { it in selectedCategoryNames }
            else
                true

        // совпадение по подкатегории:
        //  - если sub не выбран, пропускаем всех
        //  - если выбран – его id должен быть в тегах
        val matchSub =
            if (selectedSubUpper != null)
                selectedSubUpper in tagsUpper
            else
                true

        matchCategory && matchSub
    }
}
