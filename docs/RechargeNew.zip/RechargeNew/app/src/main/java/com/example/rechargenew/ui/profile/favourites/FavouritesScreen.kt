package com.example.rechargenew.ui.profile

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rechargenew.ui.profile.components.ProfileHeader
import com.example.rechargenew.ui.profile.components.ProfileMenuItem
import com.example.rechargenew.ui.profile.components.ProfileSectionHeader
import com.example.rechargenew.ui.profile.components.SpacerBlock

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    // данные о пользователе — потом возьмёшь из ViewModel
    name: String = "Nikita",
    city: String = "Amsterdam",
    status: String = "Explorer",

    // колбэки навигации
    onEditProfileClick: () -> Unit = {},
    onFavouritesClick: () -> Unit = {},
    onSavedSearchesClick: () -> Unit = {},
    onMyBookingsClick: () -> Unit = {},
    onHistoryClick: () -> Unit = {},
    onMyReviewsClick: () -> Unit = {},
    onPaymentsClick: () -> Unit = {},
    onInviteFriendsClick: () -> Unit = {},
    onPrivacyClick: () -> Unit = {},
    onHelpClick: () -> Unit = {},
    onSettingsClick: () -> Unit = {},
    onLogoutClick: () -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "My Recharge") },
                actions = {
                    IconButton(onClick = onSettingsClick) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // шапка профиля
            ProfileHeader(
                name = name,
                city = city,
                status = status,
                onEditClick = onEditProfileClick
            )

            Spacer(modifier = Modifier.height(8.dp))

            // --- блок: избранное и сохранённые поиски ---
            ProfileSectionHeader(title = "My favourites & searches")

            ProfileMenuItem(
                icon = Icons.Default.FavoriteBorder,
                title = "Favourite activities",
                onClick = onFavouritesClick
            )

            ProfileMenuItem(
                icon = Icons.Default.Search,
                title = "Saved searches",
                badgeText = "New",
                onClick = onSavedSearchesClick
            )

            SpacerBlock()

            // --- блок: мои действия ---
            ProfileSectionHeader(title = "My activity")

            ProfileMenuItem(
                icon = Icons.Default.Event,
                title = "My bookings",
                onClick = onMyBookingsClick
            )

            ProfileMenuItem(
                icon = Icons.Default.History,
                title = "Visited & history",
                onClick = onHistoryClick
            )

            ProfileMenuItem(
                icon = Icons.Default.StarBorder,
                title = "My reviews",
                onClick = onMyReviewsClick
            )

            SpacerBlock()

            // --- блок: деньги и друзья ---
            ProfileSectionHeader(title = "Payments & friends")

            ProfileMenuItem(
                icon = Icons.Default.CreditCard,
                title = "Payments",
                onClick = onPaymentsClick
            )

            ProfileMenuItem(
                icon = Icons.Default.Group,
                title = "Invite a friend",
                onClick = onInviteFriendsClick
            )

            SpacerBlock()

            // --- блок: настройки, приватность, помощь ---
            ProfileSectionHeader(title = "Settings & privacy")

            ProfileMenuItem(
                icon = Icons.Default.Security,
                title = "Privacy preferences",
                onClick = onPrivacyClick
            )

            ProfileMenuItem(
                icon = Icons.Default.Info,
                title = "Help & info",
                onClick = onHelpClick
            )

            SpacerBlock()

            // --- выход ---
            ProfileMenuItem(
                icon = Icons.Default.ExitToApp,
                title = "Log out",
                isDestructive = true,
                onClick = onLogoutClick
            )
        }
    }
}
