package com.example.rechargenew.ui.categories

import com.example.rechargenew.data.categories.CategoryData
import com.example.rechargenew.data.categories.SubcategoryData
import com.example.rechargenew.model.EventCategory

/**
 * UI-модель категории для блока C.
 */
data class CategoryItem(
    val id: EventCategory,
    val title: String,
    val subtitle: String,
    val emoji: String
)

/**
 * UI-модель подкатегории для блока C (C-sub).
 *
 * id – строковый (из subcategories.json), parent – enum EventCategory.
 */
data class SubcategoryItem(
    val id: String,
    val parent: EventCategory,
    val title: String
)

/**
 * Маппинг из data-слоя в UI-слой.
 */
fun CategoryData.toUi(): CategoryItem =
    CategoryItem(
        id = id,
        title = title,
        subtitle = subtitle,
        emoji = emoji
    )

fun SubcategoryData.toUi(): SubcategoryItem =
    SubcategoryItem(
        id = id,
        parent = parent,
        title = title
    )
