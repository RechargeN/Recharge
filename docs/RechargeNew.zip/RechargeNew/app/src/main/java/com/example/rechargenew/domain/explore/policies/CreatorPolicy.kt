package com.example.rechargenew.domain.explore.policies

/**
 * Правила для CREATOR: ответственность за контент, базовые условия.
 */
object CreatorPolicy {
    fun canCreateEvent(isBanned: Boolean): Boolean = !isBanned
}
