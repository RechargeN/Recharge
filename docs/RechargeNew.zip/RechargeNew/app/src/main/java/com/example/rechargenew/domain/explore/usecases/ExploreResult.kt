package com.example.rechargenew.domain.explore.usecases

sealed class ExploreResult<out T> {
    data class Success<T>(val value: T) : ExploreResult<T>()
    data class Error(val message: String, val cause: Throwable? = null) : ExploreResult<Nothing>()
}
