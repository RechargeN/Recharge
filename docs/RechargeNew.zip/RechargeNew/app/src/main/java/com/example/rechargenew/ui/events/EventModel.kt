package com.example.rechargenew.ui.events

data class EventModel(
    val id: String,
    val title: String,
    val category: String,
    val imageUrl: String,
    val dateTimeMillis: Long,
    val locationName: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val price: Double? = null,
    val isFree: Boolean = false,
    val maxParticipants: Int? = null,
    val currentParticipants: Int? = null,
    val isFavorite: Boolean = false,
    val tags: List<String> = emptyList(),
    val shortDescription: String = "",
    val fullDescription: String = ""
) {
    val isSoldOut: Boolean
        get() = maxParticipants != null &&
                currentParticipants != null &&
                currentParticipants >= maxParticipants

    val isAlmostFull: Boolean
        get() {
            if (maxParticipants == null || currentParticipants == null) return false
            val left = maxParticipants - currentParticipants
            return !isSoldOut && left in 1..3
        }
}
