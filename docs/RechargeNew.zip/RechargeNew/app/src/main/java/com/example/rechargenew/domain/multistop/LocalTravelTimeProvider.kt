package com.example.rechargenew.domain.multistop

import kotlin.math.*

class LocalTravelTimeProvider(
    private val driveKmh: Double = 45.0,
    private val transitKmh: Double = 28.0,
    private val bikeKmh: Double = 16.0,
    private val walkKmh: Double = 4.8
) : TravelTimeProvider {

    override suspend fun minutesBetween(a: GeoPoint, b: GeoPoint, mode: TravelMode): Int {
        val km = haversineKm(a.lat, a.lng, b.lat, b.lng)
        val kmh = when (mode) {
            TravelMode.DRIVE -> driveKmh
            TravelMode.TRANSIT -> transitKmh
            TravelMode.BIKE -> bikeKmh
            TravelMode.WALK -> walkKmh
        }.coerceAtLeast(1.0)

        val minutes = (km / kmh * 60.0).roundToInt()
        return minutes.coerceAtLeast(1)
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}