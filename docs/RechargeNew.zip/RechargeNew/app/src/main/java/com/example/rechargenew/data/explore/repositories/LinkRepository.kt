package com.example.rechargenew.data.explore.links

import com.example.rechargenew.domain.explore.model.AccessLevel

/**
 * MVP: простая логика доступа.
 * Позже будет реальная таблица связей user ↔ entity.
 */
class LinkRepository {

    fun getAccessLevel(
        userId: String,
        entityId: String
    ): AccessLevel {
        // MVP правило:
        // если userId == entityId → OWNER
        return if (userId == entityId) {
            AccessLevel.OWNER
        } else {
            AccessLevel.VIEWER
        }
    }
}
