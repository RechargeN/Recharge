package com.example.rechargenew.data.explore.entities

import com.example.rechargenew.domain.explore.model.EntityType
import com.example.rechargenew.domain.explore.model.UserRole
import com.example.rechargenew.domain.explore.usecases.MyEntityDomainItem

/**
 * MVP: генерируем "мои страницы" детерминированно из userId + roles.
 * Позже заменится на реальные сущности/репозитории/сервер.
 */
class InMemoryMyEntitiesRepository : MyEntitiesRepository {

    override fun buildMyEntities(userId: String, roles: Set<UserRole>): List<MyEntityDomainItem> {
        val items = mutableListOf<MyEntityDomainItem>()

        if (UserRole.CREATOR in roles) {
            items += MyEntityDomainItem(
                type = EntityType.HOST,
                id = "host_$userId",
                title = "My creator page"
            )
        }

        if (UserRole.VENUE_OWNER in roles) {
            items += MyEntityDomainItem(
                type = EntityType.LOCATION,
                id = "location_$userId",
                title = "My venue"
            )
        }

        if (UserRole.CONTRIBUTOR in roles) {
            items += MyEntityDomainItem(
                type = EntityType.PLACE,
                id = "place_$userId",
                title = "My public place"
            )
        }

        return items
    }
}
