package com.example.rechargenew.data.explore.entities

import com.example.rechargenew.domain.explore.model.UserRole
import com.example.rechargenew.domain.explore.usecases.MyEntityDomainItem

interface MyEntitiesRepository {
    fun buildMyEntities(userId: String, roles: Set<UserRole>): List<MyEntityDomainItem>
}
