package com.example.rechargenew.ui.events

object EventsDestinations {
    const val SEARCH = "search"
    const val MAP = "map"
    const val FEED = "events_feed"
    const val DETAILS = "event_details"
}
