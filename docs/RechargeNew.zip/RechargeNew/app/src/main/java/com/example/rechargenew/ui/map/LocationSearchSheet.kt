package com.example.rechargenew.ui.map

import android.location.Geocoder
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationSearchSheet(
    open: Boolean,
    onClose: () -> Unit,
    onSelectLatLng: (LatLng, String) -> Unit
) {
    if (!open) return

    val context = LocalContext.current
    val geocoder = remember { Geocoder(context, Locale.getDefault()) }

    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Pair<String, LatLng>>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }

    LaunchedEffect(query) {
        if (query.length < 3) {
            results = emptyList()
            return@LaunchedEffect
        }
        loading = true
        delay(350) // debounce
        val q = query
        val found = withContext(Dispatchers.IO) {
            runCatching {
                @Suppress("DEPRECATION")
                geocoder.getFromLocationName(q, 10)?.mapNotNull { a ->
                    val line = a.getAddressLine(0) ?: return@mapNotNull null
                    val lat = a.latitude
                    val lng = a.longitude
                    line to LatLng(lat, lng)
                } ?: emptyList()
            }.getOrDefault(emptyList())
        }
        if (q == query) results = found
        loading = false
    }

    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.padding(16.dp)) {
            Text("Город / адрес", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Введите город или адрес") }
            )

            Spacer(Modifier.height(10.dp))

            if (loading) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
            }

            LazyColumn {
                items(results) { (label, latLng) ->
                    ListItem(
                        headlineContent = { Text(label) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onSelectLatLng(latLng, label)
                                onClose()
                            }
                    )
                    Divider()
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}
