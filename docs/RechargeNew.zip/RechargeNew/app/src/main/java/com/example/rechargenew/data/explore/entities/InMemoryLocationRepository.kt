
package com.example.rechargenew.data.explore.entities

import com.example.rechargenew.data.explore.entities.model.LocationEntity

class InMemoryLocationRepository : LocationRepository {

    private val store = mutableMapOf<String, LocationEntity>()

    fun seedIfMissing(id: String, title: String) {
        store.putIfAbsent(
            id,
            LocationEntity(
                id = id,
                title = title,
                about = "This is your venue page. People will see events history, photos and venue details.",
                tags = listOf("venue", "location")
            )
        )
    }

    override suspend fun getById(id: String): LocationEntity? = store[id]
}
