package com.example.rechargenew.ui.features.explore.entity.blocks

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding

@Composable
fun EmptyStateBlock(text: String, modifier: Modifier = Modifier) {
    Text(text = text, modifier = modifier.padding(16.dp))
}
