package com.example.rechargenew.domain.explore.usecases

import com.example.rechargenew.domain.explore.model.UserRole

interface RequestRoleUpgradeUseCase {
    suspend fun execute(requestRole: UserRole): ExploreResult<Unit>
}
