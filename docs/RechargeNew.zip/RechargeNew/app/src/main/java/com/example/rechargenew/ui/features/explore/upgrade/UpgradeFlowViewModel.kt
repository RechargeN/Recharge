package com.example.rechargenew.ui.features.explore.upgrade

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.rechargenew.data.explore.ExploreDI
import com.example.rechargenew.domain.explore.model.UserRole
import com.example.rechargenew.domain.explore.usecases.ExploreResult
import com.example.rechargenew.domain.explore.usecases.RequestRoleUpgradeUseCase
import com.example.rechargenew.domain.explore.usecases.RequestRoleUpgradeUseCaseImpl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class UpgradeFlowViewModel(
    private val requestUpgrade: RequestRoleUpgradeUseCase =
        RequestRoleUpgradeUseCaseImpl(ExploreDI.roles)
) : ViewModel() {

    private val _uiState = MutableStateFlow(UpgradeUiState())
    val uiState: StateFlow<UpgradeUiState> = _uiState

    fun performUpgrade(role: UserRole) {
        _uiState.value = _uiState.value.copy(isUpgrading = true, error = null, upgradedRole = null)

        viewModelScope.launch {
            when (val res = requestUpgrade.execute(role)) {
                is ExploreResult.Success -> {
                    _uiState.value = _uiState.value.copy(
                        isUpgrading = false,
                        upgradedRole = role
                    )
                }
                is ExploreResult.Error -> {
                    _uiState.value = _uiState.value.copy(
                        isUpgrading = false,
                        error = res.message
                    )
                }
            }
        }
    }

    fun resetResult() {
        _uiState.value = _uiState.value.copy(upgradedRole = null, error = null)
    }
}
