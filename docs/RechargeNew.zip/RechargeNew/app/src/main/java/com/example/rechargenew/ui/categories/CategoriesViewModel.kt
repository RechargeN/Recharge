package com.example.rechargenew.ui.categories

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.rechargenew.data.categories.CategoriesRepository
import com.example.rechargenew.data.filters.FilterState
import com.example.rechargenew.model.EventCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel блока C (категории и подкатегории).
 *
 * Задачи:
 *  - загрузить список категорий и подкатегорий из репозитория
 *  - хранить выбранную категорию / подкатегорию
 *  - обновлять общий FilterState, который потом использует блок D
 */
class CategoriesViewModel : ViewModel() {

    // ----- списки категорий / подкатегорий для UI -----

    private val _categories = MutableStateFlow<List<CategoryItem>>(emptyList())
    val categories: StateFlow<List<CategoryItem>> = _categories.asStateFlow()

    private val _subcategories = MutableStateFlow<List<SubcategoryItem>>(emptyList())
    val subcategories: StateFlow<List<SubcategoryItem>> = _subcategories.asStateFlow()

    // ----- выбранные значения -----

    private val _selectedCategory = MutableStateFlow<EventCategory?>(null)
    val selectedCategory: StateFlow<EventCategory?> = _selectedCategory.asStateFlow()

    // id подкатегории из subcategories.json, например "music_concerts"
    private val _selectedSubcategoryId = MutableStateFlow<String?>(null)
    val selectedSubcategoryId: StateFlow<String?> = _selectedSubcategoryId.asStateFlow()

    // ----- общий фильтр, который будет использовать D -----

    private val _filterState = MutableStateFlow(FilterState())
    val filterState: StateFlow<FilterState> = _filterState.asStateFlow()

    // ================== ПУБЛИЧНЫЕ МЕТОДЫ ==================

    /**
     * Загрузить список категорий из репозитория.
     * Вызывается из CategoriesScreen внутри LaunchedEffect.
     */
    fun loadCategories(context: Context) {
        viewModelScope.launch {
            val data = CategoriesRepository.getCategories(context)
            _categories.value = data.map { it.toUi() }
        }
    }

    /**
     * Загрузить подкатегории для выбранной категории.
     * Вызывается из CategoriesScreen при выборе категории.
     */
    fun loadSubcategoriesFor(category: EventCategory, context: Context) {
        viewModelScope.launch {
            val data = CategoriesRepository.getSubcategoriesFor(category, context)
            _subcategories.value = data.map { it.toUi() }
        }
    }

    /**
     * Пользователь выбрал категорию C.
     */
    fun selectCategory(category: EventCategory?, context: Context) {
        _selectedCategory.value = category
        _selectedSubcategoryId.value = null
        _subcategories.value = emptyList()

        if (category != null) {
            // подтягиваем подкатегории для выбранной категории
            loadSubcategoriesFor(category, context)

            _filterState.value = _filterState.value.copy(
                categories = setOf(category),
                subcategoryIds = emptySet()
            )
        } else {
            // полное снятие фильтра по категориям
            _filterState.value = _filterState.value.copy(
                categories = emptySet(),
                subcategoryIds = emptySet()
            )
        }
    }

    /**
     * Пользователь выбрал подкатегорию C-sub.
     */
    fun selectSubcategory(subId: String?) {
        _selectedSubcategoryId.value = subId

        _filterState.value = _filterState.value.copy(
            subcategoryIds = if (subId != null) setOf(subId) else emptySet()
        )
    }

    /**
     * Полный сброс фильтра по категориям.
     * (может пригодиться в A/B/DCBA или в "Очистить фильтры").
     */
    fun clearCategoryFilter() {
        _selectedCategory.value = null
        _selectedSubcategoryId.value = null
        _subcategories.value = emptyList()

        _filterState.value = _filterState.value.copy(
            categories = emptySet(),
            subcategoryIds = emptySet()
        )
    }
}
