package com.example.rechargenew.data.explore.entities

import com.example.rechargenew.data.explore.entities.model.LocationEntity

interface LocationRepository {
    suspend fun getById(id: String): LocationEntity?
}
