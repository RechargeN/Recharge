package com.example.rechargenew.ui.map

data class MapUiState(
    val leftPanelOpen: Boolean = false,
    val panelEventIds: List<String> = emptyList(),
    val selectedEventId: String? = null,

    val radiusPanelOpen: Boolean = false,
    val radiusPreviewMeters: Int? = null, // <-- важно для preview

    val locationSearchOpen: Boolean = false // <-- для города/адреса
)
