package com.example.rechargenew.ui.features.explore.entity

import com.example.rechargenew.ui.features.explore.entity.model.EntityTabUi

sealed class ExploreEntityIntent {
    data class SelectTab(val tab: EntityTabUi) : ExploreEntityIntent()
    data class OnActionClick(val actionId: String) : ExploreEntityIntent()
}
