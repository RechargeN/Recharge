package com.example.rechargenew.domain.explore.usecases

import com.example.rechargenew.domain.explore.model.EntityId
import com.example.rechargenew.domain.explore.model.EntityType

data class EntityPageInput(
    val type: EntityType,
    val id: EntityId
)
