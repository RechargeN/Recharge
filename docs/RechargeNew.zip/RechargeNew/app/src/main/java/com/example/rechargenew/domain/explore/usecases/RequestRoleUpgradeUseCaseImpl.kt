package com.example.rechargenew.domain.explore.usecases

import com.example.rechargenew.data.explore.roles.RoleRepository
import com.example.rechargenew.domain.explore.model.UserRole

class RequestRoleUpgradeUseCaseImpl(
    private val roleRepository: RoleRepository
) : RequestRoleUpgradeUseCase {

    override suspend fun execute(requestRole: UserRole): ExploreResult<Unit> {
        return try {
            if (!roleRepository.hasRole(requestRole)) {
                roleRepository.addRole(requestRole)
            }
            ExploreResult.Success(Unit)
        } catch (e: Exception) {
            ExploreResult.Error(e.message ?: "Upgrade failed", e)
        }
    }
}
