package com.example.rechargenew.model

/**
 * Тип события:
 *  - ONE_TIME  — разовое событие с конкретной датой/временем
 *  - PLACE     — точка/место (лес, парк, набережная, рыбалка и т.д.)
 */
enum class EventKind {
    ONE_TIME,
    PLACE
}

/**
 * В какое время суток это место/активность уместно рекомендовать.
 */
enum class TimeOfDay {
    MORNING,   // примерно 06–11
    DAY,       // 11–17
    EVENING,   // 17–22
    NIGHT      // 22–06
}
