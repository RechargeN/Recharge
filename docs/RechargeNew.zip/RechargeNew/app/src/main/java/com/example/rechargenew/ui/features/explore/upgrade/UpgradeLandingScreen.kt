package com.example.rechargenew.ui.features.explore.upgrade

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rechargenew.domain.explore.model.UserRole
import com.example.rechargenew.ui.features.explore.upgrade.blocks.RoleCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UpgradeLandingScreen(
    onBack: () -> Unit,
    vm: UpgradeFlowViewModel = viewModel()
) {
    val ui by  vm.uiState.collectAsState()
    val pendingRoleState = remember { mutableStateOf<UserRole?>(null) }
    val pendingRole = pendingRoleState.value

    LaunchedEffect(ui.upgradedRole) {
        if (ui.upgradedRole != null) {
            vm.resetResult()
            onBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Upgrade profile") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier.padding(paddingValues)
        ) {
            if (ui.isUpgrading) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth()
                )
            }

            ui.error?.let { errorText ->
                Text(
                    text = errorText,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            LazyColumn(
                contentPadding = PaddingValues(
                    start = 16.dp,
                    top = 16.dp,
                    end = 16.dp,
                    bottom = 16.dp
                )
            ) {
                items(ui.roles, key = { it.id }) { role ->
                    RoleCard(
                        role = role,
                        onClick = {
                            pendingRoleState.value = when (role.id) {
                                "contributor" -> UserRole.CONTRIBUTOR
                                "creator" -> UserRole.CREATOR
                                "venue_owner" -> UserRole.VENUE_OWNER
                                else -> null
                            }
                        }
                    )
                }
            }
        }
    }

    if (pendingRole != null) {
        AlertDialog(
            onDismissRequest = { pendingRoleState.value = null },
            title = { Text("Confirm upgrade") },
            text = {
                Text(
                    when (pendingRole) {
                        UserRole.CONTRIBUTOR ->
                            "You will be able to create public places (parks, walks, spots)."
                        UserRole.CREATOR ->
                            "You will be responsible for events you create."
                        UserRole.VENUE_OWNER ->
                            "You will manage a venue page and its information."
                        UserRole.USER -> ""
                    }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val role = pendingRole
                        pendingRoleState.value = null
                        vm.performUpgrade(role)
                    }
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { pendingRoleState.value = null }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}