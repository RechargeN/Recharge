package com.example.rechargenew.ui.features.explore.common

import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun LoadingBlock(modifier: Modifier = Modifier) {
    CircularProgressIndicator(modifier = modifier)
}
