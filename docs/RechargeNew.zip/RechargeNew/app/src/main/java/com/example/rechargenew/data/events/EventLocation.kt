package com.example.rechargenew.data.events

/**
 * Универсальная модель локации.
 * Можно хранить как адрес, так и координаты — и то, и другое.
 */
data class EventLocation(
    val address: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null
)
