package com.example.rechargenew.ui.features.explore.entity.blocks

import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Card
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun PhotosGridBlock(urls: List<String>, emptyText: String) {
    if (urls.isEmpty()) {
        EmptyStateBlock(emptyText)
        return
    }

    // MVP: пустые карточки (потом подключим Coil и реальные картинки)
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 200.dp, max = 420.dp)
    ) {
        items(urls) { _ ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
            ) {}
        }
    }
}
