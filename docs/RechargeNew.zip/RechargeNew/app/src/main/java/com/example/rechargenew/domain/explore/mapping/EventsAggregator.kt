package com.example.rechargenew.domain.explore.mapping

/**
 * Здесь будет логика: какие события относятся к entity,
 * и разделение upcoming/past.
 *
 * Сейчас только каркас — позже подключим EventModel/Entity links.
 */
object EventsAggregator {
    // TODO: add: fun filterByEntity(...)
    // TODO: add: fun splitUpcomingPast(...)
}
