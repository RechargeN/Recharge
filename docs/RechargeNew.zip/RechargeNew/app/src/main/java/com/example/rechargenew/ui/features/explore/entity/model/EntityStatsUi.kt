package com.example.rechargenew.ui.features.explore.entity.model

data class EntityStatsUi(
    val eventsCount: Int = 0,
    val photosCount: Int = 0,
    val rating: Double? = null
)
