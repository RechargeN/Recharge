package com.example.rechargenew.ui.screens.explore

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.navArgument
import androidx.navigation.compose.composable
import androidx.navigation.compose.navigation
import androidx.navigation.NavGraphBuilder
import com.example.rechargenew.ui.screens.explore.create.ExploreCreateEventScreen
import com.example.rechargenew.ui.screens.explore.entity.ExploreEntityScreen
import com.example.rechargenew.ui.screens.explore.myevents.ExploreMyEventsScreen
import com.example.rechargenew.ui.screens.explore.organizer.ExploreOrganizerHubScreen

/**
 * Explore feature nav graph (our internal "L" block).
 * Keep Explore screens wiring here.
 */
fun NavGraphBuilder.exploreNavGraph(
    navController: NavHostController,
    // If you use nested navigation, you can pass startDestination from outside.
    startDestination: String = ExploreRoutes.ORGANIZER_HUB,
    // Optional: route to EventDetails (existing screen elsewhere)
    eventDetailsRouteBuilder: (eventId: String) -> String = { id -> "event/$id" }
) {
    navigation(
        route = ExploreRoutes.ROOT,
        startDestination = startDestination
    ) {

        // Organizer hub (former bottom-tab E)
        composable(route = ExploreRoutes.ORGANIZER_HUB) {
            ExploreOrganizerHubScreen(
                onCreateEvent = { navController.navigate(ExploreRoutes.ORGANIZER_CREATE) },
                onMyEvents = { navController.navigate(ExploreRoutes.ORGANIZER_EVENTS) },
                onBack = { navController.popBackStack() }
            )
        }

        // Create event flow
        composable(route = ExploreRoutes.ORGANIZER_CREATE) {
            ExploreCreateEventScreen(
                onBack = { navController.popBackStack() },
                onCreated = {
                    // MVP: after create -> go to my events
                    navController.navigate(ExploreRoutes.ORGANIZER_EVENTS) {
                        // avoid building a huge stack of create screens
                        popUpTo(ExploreRoutes.ORGANIZER_HUB) { inclusive = false }
                        launchSingleTop = true
                    }
                }
            )
        }

        // My events list (management)
        composable(route = ExploreRoutes.ORGANIZER_EVENTS) {
            ExploreMyEventsScreen(
                onBack = { navController.popBackStack() },
                onOpenEvent = { eventId ->
                    navController.navigate(eventDetailsRouteBuilder(eventId))
                }
            )
        }

        // Entity page (location/host/place)
        composable(
            route = ExploreRoutes.ENTITY,
            arguments = listOf(
                navArgument(ExploreRoutes.ARG_ENTITY_TYPE) { type = NavType.StringType },
                navArgument(ExploreRoutes.ARG_ENTITY_ID) { type = NavType.StringType }
            )
        ) { entry ->
            val type = entry.arguments?.getString(ExploreRoutes.ARG_ENTITY_TYPE).orEmpty()
            val id = entry.arguments?.getString(ExploreRoutes.ARG_ENTITY_ID).orEmpty()

            ExploreEntityScreen(
                entityType = type,
                entityId = id,
                onBack = { navController.popBackStack() },
                onOpenEvent = { eventId -> navController.navigate(eventDetailsRouteBuilder(eventId)) }
            )
        }
    }
}
