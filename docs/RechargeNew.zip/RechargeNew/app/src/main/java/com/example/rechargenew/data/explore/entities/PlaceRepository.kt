package com.example.rechargenew.data.explore.entities

import com.example.rechargenew.data.explore.entities.model.PlaceEntity

interface PlaceRepository {
    suspend fun getById(id: String): PlaceEntity?
}
