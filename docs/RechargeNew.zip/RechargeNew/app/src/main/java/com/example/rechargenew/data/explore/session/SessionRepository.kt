package com.example.rechargenew.data.explore.session

import com.example.rechargenew.domain.explore.model.UserRole
import kotlinx.coroutines.flow.StateFlow

interface SessionRepository {
    val userId: String
    val rolesFlow: StateFlow<Set<UserRole>>
}
