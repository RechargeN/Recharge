package com.example.rechargenew.ui.features.explore.entity

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.rechargenew.data.explore.ExploreDI
import com.example.rechargenew.domain.explore.model.EntityId
import com.example.rechargenew.domain.explore.model.EntityType
import com.example.rechargenew.domain.explore.model.UserRole
import com.example.rechargenew.domain.explore.usecases.EntityPageInput
import com.example.rechargenew.domain.explore.usecases.ExploreResult
import com.example.rechargenew.domain.explore.usecases.GetEntityPageUseCase
import com.example.rechargenew.domain.explore.usecases.GetEntityPageUseCaseImpl
import com.example.rechargenew.ui.features.explore.entity.model.EntityActionUi
import com.example.rechargenew.ui.features.explore.entity.model.EntityTypeUi
import com.example.rechargenew.ui.features.explore.entity.variants.HostPageComposer
import com.example.rechargenew.ui.features.explore.entity.variants.LocationPageComposer
import com.example.rechargenew.ui.features.explore.entity.variants.PlacePageComposer
import com.example.rechargenew.ui.features.explore.entity.variants.UserPageComposer
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ExploreEntityViewModel(
    private val getEntityPageUseCase: GetEntityPageUseCase =
        GetEntityPageUseCaseImpl(
            ExploreDI.session,
            ExploreDI.links,
            ExploreDI.hostRepo,
            ExploreDI.locationRepo,
            ExploreDI.placeRepo
        )
) : ViewModel() {

    private val _uiState = MutableStateFlow(ExploreEntityUiState(isLoading = true))
    val uiState: StateFlow<ExploreEntityUiState> = _uiState

    private var observeRolesJob: Job? = null
    private var currentRoles: Set<UserRole> = emptySet()

    private val userPageComposer = UserPageComposer()
    private val hostPageComposer = HostPageComposer()
    private val locationPageComposer = LocationPageComposer()
    private val placePageComposer = PlacePageComposer()

    fun load(entityTypeRaw: String, entityIdRaw: String) {
        if (observeRolesJob == null) {
            observeRolesJob = viewModelScope.launch {
                ExploreDI.session.rolesFlow.collectLatest { roles ->
                    currentRoles = roles

                    val currentType = _uiState.value.entityType.name.lowercase()
                    val currentId = _uiState.value.entityId

                    if (currentId.isNotBlank()) {
                        loadInternal(currentType, currentId)
                    }
                }
            }
        }

        viewModelScope.launch {
            loadInternal(entityTypeRaw, entityIdRaw)
        }
    }

    private suspend fun loadInternal(entityTypeRaw: String, entityIdRaw: String) {
        _uiState.value = _uiState.value.copy(
            isLoading = true,
            error = null
        )

        val entityTypeUi = EntityTypeUi.from(entityTypeRaw)

        val result = getEntityPageUseCase.execute(
            EntityPageInput(
                type = EntityType.from(entityTypeRaw),
                id = EntityId(entityIdRaw)
            )
        )

        when (result) {
            is ExploreResult.Success -> {
                val domain = result.value

                val baseState = _uiState.value.copy(
                    entityType = entityTypeUi,
                    entityId = entityIdRaw,
                    isLoading = false,
                    header = _uiState.value.header.copy(
                        title = domain.title,
                        subtitle = domain.subtitle
                    ),
                    about = domain.about,
                    actions = buildActions(domain.capabilities),
                    error = null
                )

                _uiState.value = applyComposer(
                    state = baseState,
                    roles = currentRoles
                )
            }

            is ExploreResult.Error -> {
                _uiState.value = _uiState.value.copy(
                    entityType = entityTypeUi,
                    entityId = entityIdRaw,
                    isLoading = false,
                    error = result.message
                )
            }
        }
    }

    private fun applyComposer(
        state: ExploreEntityUiState,
        roles: Set<UserRole>
    ): ExploreEntityUiState {
        return when (state.entityType) {
            EntityTypeUi.USER -> userPageComposer.compose(state, roles)
            EntityTypeUi.HOST -> hostPageComposer.compose(state, roles)
            EntityTypeUi.LOCATION -> locationPageComposer.compose(state, roles)
            EntityTypeUi.PLACE -> placePageComposer.compose(state, roles)
        }
    }

    private fun buildActions(
        caps: com.example.rechargenew.domain.explore.capabilities.EntityPageCapabilities
    ): List<EntityActionUi> {
        val actions = mutableListOf<EntityActionUi>()

        if (caps.canRequestUpgrade) {
            actions += EntityActionUi(
                id = "my_entities",
                title = "My pages",
                kind = EntityActionUi.Kind.SECONDARY
            )
        }

        if (caps.canCreateEvent) {
            actions += EntityActionUi(
                id = "create_event",
                title = "Create event"
            )
        }

        if (caps.canManageLocation || caps.canManageEvents) {
            actions += EntityActionUi(
                id = "manage",
                title = "Manage"
            )
        }

        return actions
    }

    fun onIntent(intent: ExploreEntityIntent) {
        when (intent) {
            is ExploreEntityIntent.SelectTab -> {
                _uiState.value = _uiState.value.copy(activeTab = intent.tab)
            }

            is ExploreEntityIntent.OnActionClick -> {
                handleAction(intent.actionId)
            }
        }
    }

    private fun handleAction(actionId: String) {
        when (actionId) {
            "my_pages" -> {
                // TODO: navigation → MyEntitiesScreen
            }

            "create_event" -> {
                // TODO: navigation → CreateEvent
            }

            "add_place" -> {
                // TODO: navigation → CreatePlace
            }

            "manage_venue" -> {
                // TODO: navigation → ManageVenue
            }

            "upgrade_profile" -> {
                // TODO: navigation → UpgradeFlow
            }
        }
    }
}