package com.example.rechargenew.ui.features.explore.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.compose.navigation
import androidx.navigation.navArgument
import com.example.rechargenew.ui.features.explore.entity.ExploreEntityScreen
import com.example.rechargenew.ui.features.explore.manage.MyEntitiesScreen
import com.example.rechargenew.ui.features.explore.upgrade.UpgradeLandingScreen

/**
 * L feature graph (Explore).
 *
 * eventDetailsRouteBuilder: как открыть твою существующую деталку события.
 * onOpenSettings: куда вести ⚙️ (твой settings_profile).
 */
fun NavGraphBuilder.exploreNavGraph(
    navController: NavHostController,
    startDestination: String,
    eventDetailsRouteBuilder: (eventId: String) -> String,
    onOpenSettings: () -> Unit
) {
    navigation(
        route = ExploreRoutes.ROOT,
        startDestination = startDestination
    ) {

        composable(
            route = ExploreRoutes.ENTITY,
            arguments = listOf(
                navArgument(ExploreNavConstants.ARG_ENTITY_TYPE) { type = NavType.StringType },
                navArgument(ExploreNavConstants.ARG_ENTITY_ID) { type = NavType.StringType }
            )
        ) { entry ->
            val type = entry.arguments?.getString(ExploreNavConstants.ARG_ENTITY_TYPE).orEmpty()
            val id = entry.arguments?.getString(ExploreNavConstants.ARG_ENTITY_ID).orEmpty()

            ExploreEntityScreen(
                entityType = type,
                entityId = id,
                onBack = { navController.popBackStack() },
                onOpenEvent = { eventId -> navController.navigate(eventDetailsRouteBuilder(eventId)) },
                onOpenSettings = onOpenSettings,
                onOpenUpgrade = { navController.navigate(ExploreRoutes.UPGRADE) },
                onOpenMyEntities = { navController.navigate(ExploreRoutes.MY_ENTITIES) }
            )
        }

        composable(route = ExploreRoutes.UPGRADE) {
            UpgradeLandingScreen(
                onBack = { navController.popBackStack() }
            )
        }

        composable(route = ExploreRoutes.MY_ENTITIES) {
            MyEntitiesScreen(
                onBack = { navController.popBackStack() },
                onOpenEntity = { type, id -> navController.navigate(ExploreRoutes.entity(type, id)) }
            )
        }
    }
}
