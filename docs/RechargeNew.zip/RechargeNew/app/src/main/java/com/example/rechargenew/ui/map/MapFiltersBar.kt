package com.example.rechargenew.ui.map

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rechargenew.data.filters.FilterState

private data class MapFilterChip(
    val id: String,
    val label: String,
    val valueText: String?,
    val onClick: () -> Unit
)

@Composable
fun MapFiltersBar(
    filter: FilterState,
    modifier: Modifier = Modifier,
    onDateClick: () -> Unit,
    onTimeClick: () -> Unit,
    onCategoriesClick: () -> Unit,
    onPeopleClick: () -> Unit
) {
    // Простейшие подписи, чтобы всё работало
    val selectedCategoriesCount = filter.selectedCategoryIds.size
    val categoriesText = if (selectedCategoriesCount == 0) {
        "Все"
    } else {
        "$selectedCategoriesCount выбрано"
    }

    val peopleText = "${filter.peopleCount} чел."

    val chips = listOf(
        MapFilterChip(
            id = "date",
            label = "Дата",
            valueText = null,          // пока без реальной даты
            onClick = onDateClick
        ),
        MapFilterChip(
            id = "time",
            label = "Время",
            valueText = null,          // пока без реального времени
            onClick = onTimeClick
        ),
        MapFilterChip(
            id = "categories",
            label = "Категории",
            valueText = categoriesText,
            onClick = onCategoriesClick
        ),
        MapFilterChip(
            id = "people",
            label = "Люди",
            valueText = peopleText,
            onClick = onPeopleClick
        )
    )

    LazyRow(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(chips, key = { it.id }) { chip ->
            AssistChip(
                onClick = chip.onClick,
                label = {
                    if (chip.valueText.isNullOrBlank()) {
                        Text(chip.label)
                    } else {
                        Text("${chip.label}: ${chip.valueText}")
                    }
                },
                colors = AssistChipDefaults.assistChipColors(
                    labelColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }

        // маленький отступ в конце
        item { Spacer(modifier = Modifier.width(8.dp)) }
    }
}
