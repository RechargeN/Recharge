package com.example.rechargenew.ui.features.explore.manage

import com.example.rechargenew.ui.features.explore.manage.model.MyEntityItemUi

data class MyEntitiesUiState(
    val items: List<MyEntityItemUi> = emptyList()
)
