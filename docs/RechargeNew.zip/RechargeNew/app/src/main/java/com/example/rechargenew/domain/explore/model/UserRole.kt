package com.example.rechargenew.domain.explore.model

enum class UserRole {
    USER,
    CONTRIBUTOR,
    CREATOR,
    VENUE_OWNER
}
