package com.example.rechargenew.ui.features.explore.manage

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.rechargenew.data.explore.ExploreDI
import com.example.rechargenew.domain.explore.usecases.*
import com.example.rechargenew.ui.features.explore.manage.model.MyEntityItemUi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MyEntitiesViewModel(
    private val getMyEntitiesUseCase: GetMyEntitiesUseCase =
        GetMyEntitiesUseCaseImpl(ExploreDI.session, ExploreDI.myEntities)
) : ViewModel() {

    private val _uiState = MutableStateFlow(MyEntitiesUiState())
    val uiState: StateFlow<MyEntitiesUiState> = _uiState

    private var observeRolesJob: Job? = null

    init {
        startObserveRoles()
        reload()
    }

    private fun startObserveRoles() {
        if (observeRolesJob != null) return

        observeRolesJob = viewModelScope.launch {
            ExploreDI.session.rolesFlow.collectLatest {
                // роли изменились (апгрейд) → обновляем список
                reload()
            }
        }
    }

    fun reload() {
        viewModelScope.launch {
            when (val res = getMyEntitiesUseCase.execute()) {
                is ExploreResult.Success -> {
                    _uiState.value = MyEntitiesUiState(
                        items = res.value.map {
                            MyEntityItemUi(
                                type = it.type.name.lowercase(), // host/location/place
                                id = it.id,
                                title = it.title
                            )
                        }
                    )
                }
                is ExploreResult.Error -> {
                    // MVP: можно добавить поле error в state, если хочешь
                    _uiState.value = MyEntitiesUiState(items = emptyList())
                }
            }
        }
    }
}
