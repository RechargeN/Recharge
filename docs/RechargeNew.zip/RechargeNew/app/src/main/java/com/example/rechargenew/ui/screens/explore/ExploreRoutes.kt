package com.example.rechargenew.ui.screens.explore

/**
 * Explore feature routes (our internal "L" block).
 * Keep ALL explore routes here to avoid scattering strings across the app.
 */
object ExploreRoutes {

    // Root (optional, useful if you use nested navigation)
    const val ROOT = "explore"

    // Organizer hub (formerly bottom-tab E, now inside Explore)
    const val ORGANIZER_HUB = "explore/organizer"
    const val ORGANIZER_CREATE = "explore/organizer/create"
    const val ORGANIZER_EVENTS = "explore/organizer/events"

    // Entity pages (Location / Host / Place)
    const val ENTITY_BASE = "explore/entity"
    const val ARG_ENTITY_TYPE = "type"
    const val ARG_ENTITY_ID = "id"
    const val ENTITY = "$ENTITY_BASE/{$ARG_ENTITY_TYPE}/{$ARG_ENTITY_ID}"

    fun entity(type: String, id: String): String = "$ENTITY_BASE/$type/$id"
}
