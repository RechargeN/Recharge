package com.example.rechargenew.data.filters

import com.example.rechargenew.model.EventCategory

/**
 * ЕДИНЫЙ ГЛОБАЛЬНЫЙ FilterState для A / B / C / D.
 *
 * Принципы:
 * - Никаких legacy-дубликатов
 * - Один источник правды для гео
 * - Готов к масштабированию
 * - UI-поля отделены от логики
 */
data class FilterState(

    // =========================
    // A — Поиск
    // =========================
    val query: String = "",

    // =========================
    // C — Категории
    // =========================
    val categories: Set<EventCategory> = emptySet(),
    val subcategoryIds: Set<String> = emptySet(),

    // UI-категории (если нужно строковое хранение)
    val selectedCategoryIds: Set<String> = emptySet(),

    // =========================
    // D — Дата
    // =========================
    val dateFromMillis: Long? = null,
    val dateToMillis: Long? = null,

    // =========================
    // D — Цена
    // =========================
    val minPrice: Double? = null,
    val maxPrice: Double? = null,
    val onlyFree: Boolean = false,

    // UI-ввод бюджета
    val budgetMinInput: Int? = null,
    val budgetMaxInput: Int? = null,

    // =========================
    // Люди
    // =========================
    val peopleCount: Int = 1,
    val minPeople: Int? = null,
    val maxPeople: Int? = null,

    // =========================
    // B — Гео (ЕДИНСТВЕННАЯ МОДЕЛЬ)
    // =========================
    val centerLat: Double? = null,
    val centerLng: Double? = null,
    val radiusMeters: Int? = null,

    // =========================
    // Пользователь
    // =========================
    val userAge: Int? = null,
    val onlyFavorites: Boolean = false,

    // =========================
    // Будущие расширения
    // =========================
    val onlyVerified: Boolean = false,
    val onlyWithTickets: Boolean = false,
    val onlyOutdoor: Boolean = false,
    val onlyIndoor: Boolean = false,
    val freeTimeMinutes: Int? = null,
    val includeReturnTrip: Boolean = true,
    val multiStopEnabled: Boolean = false,
    val maxStops: Int = 2,
    val maxTravelTimeMinutes: Int? = null,

    val travelMode: String = "DRIVE", // или enum

    // временные фильтры
    val onlyToday: Boolean = false,
    val onlyThisWeek: Boolean = false,
    val onlyWeekend: Boolean = false
) {

    /**
     * Проверка "пуст ли фильтр"
     * Используется для reset-кнопок и логики.
     */
    fun isEmpty(): Boolean =
        query.isBlank() &&
                categories.isEmpty() &&
                subcategoryIds.isEmpty() &&
                selectedCategoryIds.isEmpty() &&
                dateFromMillis == null &&
                dateToMillis == null &&
                minPrice == null &&
                maxPrice == null &&
                !onlyFree &&
                peopleCount == 1 &&
                minPeople == null &&
                maxPeople == null &&
                centerLat == null &&
                centerLng == null &&
                radiusMeters == null &&
                userAge == null &&
                maxTravelTimeMinutes == null &&
                !onlyFavorites &&
                !onlyVerified &&
                !onlyWithTickets &&
                !onlyOutdoor &&
                !onlyIndoor &&
                !onlyToday &&
                !onlyThisWeek &&
                !onlyWeekend
}
