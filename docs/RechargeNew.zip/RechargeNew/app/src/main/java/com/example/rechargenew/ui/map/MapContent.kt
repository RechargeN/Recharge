package com.example.rechargenew.ui.map

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import com.example.rechargenew.R
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import com.google.maps.android.compose.Marker
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberMarkerState
import kotlin.math.roundToInt
import com.google.maps.android.compose.rememberMarkerState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import com.google.android.gms.maps.model.CircleOptions
import com.google.maps.android.compose.Circle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.rechargenew.ui.events.EventModel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.example.rechargenew.data.filters.FilterState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.launch
import com.google.maps.android.compose.Circle


@Composable
fun MapContent(
    events: List<EventModel>,
    filter: com.example.rechargenew.data.filters.FilterState,
    onCenterChange: (Double, Double) -> Unit,
    onEventOpen: (EventModel) -> Unit
)
 {
    val scope = rememberCoroutineScope()
     val test = filter.centerLat


     // Центр карты
    val center = if (filter.centerLat != null && filter.centerLng != null) {
        LatLng(filter.centerLat!!, filter.centerLng!!)
    } else {
        LatLng(52.3740, 4.8897) // Amsterdam default
    }

    val cameraState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(center, 10f)
    }

    // Мягко двигаем камеру при смене центра
    LaunchedEffect(filter.centerLat, filter.centerLng) {
        val lat = filter.centerLat
        val lng = filter.centerLng
        if (lat != null && lng != null) {
            cameraState.position = CameraPosition.fromLatLngZoom(
                LatLng(lat, lng),
                cameraState.position.zoom
            )
        }
    }

    // ---------------- LEFT PANEL (только по клику на маркер/кластер) ----------------
    var leftOpen by remember { mutableStateOf(false) }
    var leftEvents by remember { mutableStateOf<List<EventModel>>(emptyList()) }
    var leftTitle by remember { mutableStateOf("События") }

    val openWidth = 280.dp
    val closedWidth = 18.dp // “ручка”
    val panelWidth by animateDpAsState(
        targetValue = if (leftOpen) openWidth else closedWidth,
        label = "panelWidth"
    )

    fun openList(list: List<EventModel>, title: String) {
        leftEvents = list
        leftTitle = title
        leftOpen = true
    }

    fun closeList() {
        leftOpen = false
    }

     Box(Modifier.fillMaxSize()) {

         val lat = filter.centerLat
         val lng = filter.centerLng
         val radius = filter.radiusMeters


         // =================== MAP ===================
         GoogleMap(
             modifier = Modifier.fillMaxSize(),
             cameraPositionState = cameraState,
             onMapLongClick = { latLng ->
                 onCenterChange(latLng.latitude, latLng.longitude)
             }
         ) {
             // ✅ РАДИУС ДОЛЖЕН БЫТЬ ЗДЕСЬ (внутри GoogleMap)
             if (lat != null && lng != null) {
                 val center = LatLng(lat, lng)
                 val pin = rememberBitmapDescriptor(
                     resId = R.drawable.ic_radius_pin_background, // <-- появится, когда png реально подхватится
                     targetWidthPx = 72
                 )


                 val markerState = rememberMarkerState()
                 LaunchedEffect(center) { markerState.position = center }// ✅ метка центра (pin)
                 Marker(
                     state = rememberMarkerState(position = center),
                     title = "Центр радиуса",
                     icon = pin
                 )

                 // ✅ круг, если радиус задан
                 if (radius != null) {
                     Circle(
                         center = center,
                         radius = radius.toDouble(),
                         strokeWidth = 3f,
                         fillColor = Color(0x1A000000),
                         strokeColor = Color(0x66000000)
                     )
                 }
             }

             MapEventsLayer(
                 events = events,
                 filter = filter,
                 zoom = cameraState.position.zoom,

                 onEventClick = { event ->
                     openList(listOf(event), "Событие")
                 },

                 onClusterClick = { clusterEvents, position ->
                     val count = clusterEvents.size
                     when {
                         count <= 1 -> {
                             clusterEvents.firstOrNull()?.let { openList(listOf(it), "Событие") }
                         }
                         count in 2..10 -> {
                             openList(clusterEvents, "События: $count")
                         }
                         else -> {
                             val nextZoom = (cameraState.position.zoom + 2f).coerceAtMost(18f)
                             scope.launch {
                                 cameraState.animate(
                                     update = CameraUpdateFactory.newLatLngZoom(position, nextZoom),
                                     durationMs = 450
                                 )
                             }
                         }
                     }
                 }
             )
         }

         // =================== LEFT PANEL (минимальный, свайп) ===================
         Surface(
             tonalElevation = 3.dp,
             shadowElevation = 10.dp,
             shape = RoundedCornerShape(topEnd = 18.dp, bottomEnd = 18.dp),
             modifier = Modifier
                 .align(Alignment.CenterStart)
                 .width(panelWidth)
                 .fillMaxHeight()
                 .pointerInput(leftOpen) {
                     detectHorizontalDragGestures { _, dragAmount ->
                         if (dragAmount > 6) leftOpen = true
                         if (dragAmount < -6) leftOpen = false
                     }
                 }
         ){
            Box(Modifier.fillMaxSize()) {

                // “ручка” всегда видна
                Box(
                    modifier = Modifier
                        .width(18.dp)
                        .fillMaxHeight()
                        .clickable { leftOpen = !leftOpen },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(36.dp)
                            .background(
                                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f),
                                RoundedCornerShape(2.dp)
                            )
                    )
                }

                // контент панели
                if (leftOpen) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(start = 18.dp)
                            .padding(12.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(leftTitle, style = MaterialTheme.typography.titleMedium)
                            TextButton(onClick = { closeList() }) { Text("Закрыть") }
                        }

                        Spacer(Modifier.height(8.dp))

                        if (leftEvents.isEmpty()) {
                            Text(
                                "Ничего не выбрано",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                contentPadding = PaddingValues(bottom = 18.dp)
                            ) {
                                items(leftEvents) { e ->
                                    EventMiniCard(
                                        event = e,
                                        onClick = {
                                            val lat = e.latitude
                                            val lng = e.longitude
                                            if (lat != null && lng != null) {
                                                scope.launch {
                                                    cameraState.animate(
                                                        update = CameraUpdateFactory.newLatLngZoom(
                                                            LatLng(lat, lng),
                                                            15f
                                                        ),
                                                        durationMs = 450
                                                    )
                                                }
                                            }
                                            onEventOpen(e)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
@Composable
private fun rememberBitmapDescriptor(resId: Int, targetWidthPx: Int): BitmapDescriptor? {
    val context = LocalContext.current
    return remember(resId, targetWidthPx) {
        val drawable = ContextCompat.getDrawable(context, resId) as? BitmapDrawable ?: return@remember null
        val bmp = drawable.bitmap

        val ratio = bmp.height.toFloat() / bmp.width.toFloat()
        val w = targetWidthPx.coerceAtLeast(1)
        val h = (w * ratio).roundToInt().coerceAtLeast(1)

        val scaled: Bitmap = Bitmap.createScaledBitmap(bmp, w, h, true)
        BitmapDescriptorFactory.fromBitmap(scaled)
    }
}
@Composable
private fun EventMiniCard(
    event: EventModel,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(text = event.title, style = MaterialTheme.typography.titleSmall, maxLines = 2)
            Spacer(Modifier.height(6.dp))
            Text(
                text = event.locationName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}
