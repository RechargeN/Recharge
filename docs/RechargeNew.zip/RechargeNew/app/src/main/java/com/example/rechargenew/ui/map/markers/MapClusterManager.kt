// app/src/main/java/com/example/rechargenew/ui/map/markers/MapClusterManager.kt
package com.example.rechargenew.ui.map.markers

import com.example.rechargenew.ui.events.EventModel
import kotlin.math.*

/**
 * Очень простая кластеризация “по расстоянию”.
 * На старте хватит этого. При желании потом усложним.
 */
object MapClusterManager {

    /**
     * @param events список событий
     * @param zoom   текущий zoom карты (из CameraPosition)
     */
    fun clusterEvents(
        events: List<EventModel>,
        zoom: Float
    ): List<ClusterItem> {

        if (events.isEmpty()) return emptyList()

        // Чем меньше zoom – тем больше радиус объединения
        val distanceThresholdMeters = when {
            zoom < 7f  -> 50_000.0  // очень далеко – один кластер на город/регион
            zoom < 10f -> 10_000.0  // средний зум – по районам
            zoom < 13f -> 3_000.0   // ближе – кварталы
            zoom < 16f -> 800.0     // улицы
            else       -> 200.0     // почти не кластерим
        }

        val clusters = mutableListOf<MutableList<EventModel>>()
        val centers = mutableListOf<Pair<Double, Double>>() // lat, lng

        fun distanceMeters(
            lat1: Double, lng1: Double,
            lat2: Double, lng2: Double
        ): Double {
            val R = 6371000.0
            val dLat = Math.toRadians(lat2 - lat1)
            val dLng = Math.toRadians(lng2 - lng1)
            val a = sin(dLat/2).pow(2.0) +
                    cos(Math.toRadians(lat1)) *
                    cos(Math.toRadians(lat2)) *
                    sin(dLng/2).pow(2.0)
            val c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return R * c
        }

        events.forEach { e ->
            val lat = e.latitude ?: return@forEach
            val lng = e.longitude ?: return@forEach

            // Ищем кластер, центр которого близко к этому ивенту
            var added = false
            for (i in centers.indices) {
                val (clLat, clLng) = centers[i]
                val dist = distanceMeters(lat, lng, clLat, clLng)
                if (dist <= distanceThresholdMeters) {
                    clusters[i].add(e)
                    // обновляем центр кластера (простой средний)
                    val newSize = clusters[i].size.toDouble()
                    val newLat = (clLat * (newSize - 1) + lat) / newSize
                    val newLng = (clLng * (newSize - 1) + lng) / newSize
                    centers[i] = newLat to newLng
                    added = true
                    break
                }
            }

            if (!added) {
                clusters += mutableListOf(e)
                centers += lat to lng
            }
        }

        // преобразуем в ClusterItem
        val result = mutableListOf<ClusterItem>()
        for (i in clusters.indices) {
            val group = clusters[i]
            if (group.size == 1) {
                result += ClusterItem.Single(group.first())
            } else {
                val (lat, lng) = centers[i]
                result += ClusterItem.Cluster(
                    events = group,
                    lat = lat,
                    lng = lng
                )
            }
        }
        return result
    }
}
