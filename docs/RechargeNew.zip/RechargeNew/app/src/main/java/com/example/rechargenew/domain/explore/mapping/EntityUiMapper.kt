package com.example.rechargenew.domain.explore.mapping

import com.example.rechargenew.domain.explore.usecases.EntityPageDomain

/**
 * Маппер выделен, чтобы VM не раздувался.
 * Позже тут будет: domain -> EntityHeaderUi, actions, tabs etc.
 */
object EntityUiMapper {
    // пока пусто — будет использовано при подключении data
    fun normalizeTitle(title: String): String = title.trim()
    fun normalizeTags(tags: List<String>): List<String> =
        tags.map { it.trim() }.filter { it.isNotBlank() }.distinct()
}
