package com.example.rechargenew.domain.explore.policies

/**
 * Правила для VENUE_OWNER.
 * Позже: claim venue, подтверждение владения, модерация.
 */
object VenueOwnerPolicy {
    fun canEditVenue(isApproved: Boolean): Boolean = isApproved
}
