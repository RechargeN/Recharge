package com.example.rechargenew.data.explore.session

import com.example.rechargenew.domain.explore.model.UserRole

/**
 * MVP: локальный текущий пользователь.
 * Позже заменится на auth/session.
 */
object CurrentUserProvider {

    val userId: String = "user_me"

    val roles: Set<UserRole> = setOf(
        UserRole.USER,
        // раскомментируй для тестов:
        // UserRole.CONTRIBUTOR,
        // UserRole.CREATOR,
        // UserRole.VENUE_OWNER
    )
}
