package com.example.rechargenew.ui.features.explore.entity.blocks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rechargenew.ui.events.EventCard
import com.example.rechargenew.ui.events.EventModel

@Composable
fun EventsListBlock(
    events: List<EventModel>,
    onOpenEvent: (String) -> Unit,
    emptyText: String,
    modifier: Modifier = Modifier
) {
    if (events.isEmpty()) {
        EmptyStateBlock(emptyText)
        return
    }

    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(events, key = { it.id }) { e ->
            EventCard(
                event = e,
                onClick = { onOpenEvent(e.id) },
                onToggleFavorite = {}
            )
        }
    }
}
