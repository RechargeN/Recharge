package com.example.rechargenew.ui.events.create

import android.content.Context
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.rechargenew.data.events.EventLocation
import com.example.rechargenew.data.events.create.CreateEventRepository
import com.example.rechargenew.data.events.create.DefaultCreateEventRepository
import com.example.rechargenew.data.events.create.EventDraft
import com.example.rechargenew.model.EventCategory
import com.example.rechargenew.model.EventKind
import com.example.rechargenew.model.TimeOfDay
import kotlinx.coroutines.launch

data class CreateEventValidation(
    val titleError: String? = null,
    val descriptionError: String? = null,
    val categoryError: String? = null,
    val dateError: String? = null,
    val priceError: String? = null,
    val locationError: String? = null,
)

data class CreateEventUiState(
    val draft: EventDraft = EventDraft(),
    val validation: CreateEventValidation = CreateEventValidation(),
    val isSaving: Boolean = false,
    val isSaved: Boolean = false,
    val saveError: String? = null
)

class CreateEventViewModel(
    private val repository: CreateEventRepository = DefaultCreateEventRepository()
) : ViewModel() {

    private val _uiState = mutableStateOf(CreateEventUiState())
    val uiState: State<CreateEventUiState> = _uiState

    fun updateTitle(title: String) {
        _uiState.value = _uiState.value.copy(
            draft = _uiState.value.draft.copy(title = title),
            validation = _uiState.value.validation.copy(titleError = null)
        )
    }

    fun updateDescription(text: String) {
        _uiState.value = _uiState.value.copy(
            draft = _uiState.value.draft.copy(description = text),
            validation = _uiState.value.validation.copy(descriptionError = null)
        )
    }

    fun toggleCategory(category: EventCategory) {
        val current = _uiState.value.draft

        val newCategories = if (current.categories.contains(category)) {
            current.categories - category
        } else {
            current.categories + category
        }

        val newSubMap = current.subcategoryIdsByCategory.toMutableMap()
        if (!newCategories.contains(category)) {
            newSubMap.remove(category) // ✅ убрали категорию → убрали и её подкатегории
        }

        _uiState.value = _uiState.value.copy(
            draft = current.copy(
                categories = newCategories,
                subcategoryIdsByCategory = newSubMap
            ),
            validation = _uiState.value.validation.copy(categoryError = null)
        )
    }


    fun updateKind(kind: EventKind) {
        val current = _uiState.value
        _uiState.value = current.copy(draft = current.draft.copy(kind = kind))
    }

    fun toggleRecommendedTime(time: TimeOfDay) {
        val current = _uiState.value
        val draft = current.draft
        val newList = if (draft.recommendedTimes.contains(time)) {
            draft.recommendedTimes - time
        } else {
            draft.recommendedTimes + time
        }
        _uiState.value = current.copy(draft = draft.copy(recommendedTimes = newList))
    }

    fun toggleSubcategory(category: EventCategory, subId: String) {
        val current = _uiState.value.draft
        val currentForCat = current.subcategoryIdsByCategory[category].orEmpty()
        val newForCat = if (currentForCat.contains(subId)) {
            currentForCat - subId
        } else {
            currentForCat + subId
        }

        _uiState.value = _uiState.value.copy(
            draft = current.copy(
                subcategoryIdsByCategory = current.subcategoryIdsByCategory.toMutableMap()
                    .apply { put(category, newForCat) }
            )
        )
    }

    fun updateDateTime(millis: Long) {
        _uiState.value = _uiState.value.copy(
            draft = _uiState.value.draft.copy(dateTimeMillis = millis),
            validation = _uiState.value.validation.copy(dateError = null)
        )
    }

    fun updatePrice(text: String) {
        val price = text.toDoubleOrNull()
        _uiState.value = _uiState.value.copy(
            draft = _uiState.value.draft.copy(price = price),
            validation = _uiState.value.validation.copy(priceError = null)
        )
    }

    fun updateLocation(location: EventLocation) {
        _uiState.value = _uiState.value.copy(
            draft = _uiState.value.draft.copy(location = location),
            validation = _uiState.value.validation.copy(locationError = null)
        )
    }

    fun updatePhotos(uris: List<String>) {
        _uiState.value = _uiState.value.copy(
            draft = _uiState.value.draft.copy(
                photoUris = uris,
                photoUri = uris.firstOrNull()
            )
        )
    }

    fun useCurrentLocation() {
        // заглушка
    }

    fun resetSavedFlag() {
        _uiState.value = _uiState.value.copy(isSaved = false)
    }

    private fun validate(draft: EventDraft): CreateEventValidation {
        var titleError: String? = null
        var descriptionError: String? = null
        var categoryError: String? = null
        var dateError: String? = null
        var locationError: String? = null

        if (draft.title.isBlank())
            titleError = "Введите название"

        if (draft.description.isBlank())
            descriptionError = "Опишите событие"

        if (draft.categories.isEmpty())
            categoryError = "Выберите хотя бы одну категорию"

        if (draft.dateTimeMillis == null)
            dateError = "Выберите дату и время"

        // 🔥 ВОТ ЭТО — НУЖНО ИМЕННО ЗДЕСЬ
        if (draft.location?.latitude == null || draft.location.longitude == null) {
            locationError = "Нужны координаты (тап по карте или выбери подсказку)"
        }

        return CreateEventValidation(
            titleError = titleError,
            descriptionError = descriptionError,
            categoryError = categoryError,
            dateError = dateError,
            locationError = locationError
        )
    }

    /**
     * ✅ ВАЖНО: теперь нужен Context (чтобы репозиторий сохранил в storage и пушнул flow)
     */
    fun saveEvent(context: android.content.Context) {
        val state = _uiState.value
        val draft = state.draft

        val validation = validate(draft)
        if (
            validation.titleError != null ||
            validation.descriptionError != null ||
            validation.categoryError != null ||
            validation.dateError != null ||
            validation.locationError != null
        ) {
            _uiState.value = state.copy(validation = validation)
            return
        }

        _uiState.value = state.copy(isSaving = true, saveError = null)

        viewModelScope.launch {
            try {
                repository.createEvent(context, draft)
                _uiState.value = _uiState.value.copy(isSaving = false, isSaved = true)
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    saveError = e.message ?: "Ошибка при сохранении события"
                )
            }
        }
    }

}
