package com.example.rechargenew.model

/**
 * D — единица контента: событие / активность.
 *
 * Эта модель используется в:
 *  - репозитории событий
 *  - ленте (D)
 *  - деталке события
 *  - фильтрах A/B/C/DCBA
 */
data class Event(
    val id: String,                    // уникальный ID в системе

    val title: String,                 // название
    val shortDescription: String,      // короткое описание
    val fullDescription: String? = null,

    // ----- C: категории / подкатегории -----
    // одно событие может относиться к нескольким категориям
    val categories: List<EventCategory>,
    val subcategories: List<EventSubcategory> = emptyList(),

    // ----- B: карта / локация -----
    val latitude: Double? = null,
    val longitude: Double? = null,
    val address: String? = null,

    // ----- A / DCBA: время -----
    val startTimeMillis: Long? = null,
    val endTimeMillis: Long? = null,

    // ----- A / DCBA: бюджет -----
    val minPrice: Double? = null,
    val maxPrice: Double? = null,
    val isFree: Boolean = false,

    // ----- A / DCBA: количество людей -----
    val minPeople: Int? = null,
    val maxPeople: Int? = null,

    // ----- A / профиль: возраст -----
    val minAge: Int? = null,
    val maxAge: Int? = null,

    // ----- DG: избранное -----
    val isFavorite: Boolean = false,

    // ----- дополнительные поля для масштабирования -----
    val rating: Double? = null,        // средний рейтинг
    val ratingCount: Int = 0,          // кол-во оценок
    val popularity: Int = 0,           // условный "вес" для сортировки
    val createdAtMillis: Long? = null,
    val updatedAtMillis: Long? = null
)
