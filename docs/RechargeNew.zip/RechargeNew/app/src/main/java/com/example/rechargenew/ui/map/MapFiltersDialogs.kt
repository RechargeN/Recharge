package com.example.rechargenew.ui.map

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// Пока просто фиксированный список категорий для карты
private val allCategories = listOf(
    "Music", "Comedy", "Games", "Sport",
    "Party", "Cinema", "Concert", "Workshop"
)

@Composable
fun CategoriesFilterDialog(
    current: Set<String>,
    onApply: (Set<String>) -> Unit,
    onDismiss: () -> Unit
) {
    var selected by remember { mutableStateOf(current.toMutableSet()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Категории") },
        text = {
            Column {
                allCategories.forEach { cat ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                    ) {
                        Checkbox(
                            checked = cat in selected,
                            onCheckedChange = { checked ->
                                if (checked) selected.add(cat) else selected.remove(cat)
                            }
                        )
                        Text(cat, modifier = Modifier.padding(start = 4.dp))
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onApply(selected) }) {
                Text("Применить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

@Composable
fun PeopleFilterDialog(
    current: Int,
    onApply: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val options = listOf(1, 2, 3, 4, 5, 6)
    var selected by remember { mutableStateOf(current) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Количество людей") },
        text = {
            Column {
                options.forEach { count ->
                    TextButton(onClick = { selected = count }) {
                        Text(
                            if (selected == count) "✔ $count человек"
                            else "$count человек"
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onApply(selected) }) {
                Text("Применить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}
