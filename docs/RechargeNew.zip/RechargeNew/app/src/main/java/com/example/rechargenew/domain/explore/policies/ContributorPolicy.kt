package com.example.rechargenew.domain.explore.policies

/**
 * Правила для CONTRIBUTOR.
 * Например: доверие аккаунта, лимиты, минимальные требования.
 */
object ContributorPolicy {
    fun canCreatePlace(trustScore: Int): Boolean = trustScore >= 10
}
