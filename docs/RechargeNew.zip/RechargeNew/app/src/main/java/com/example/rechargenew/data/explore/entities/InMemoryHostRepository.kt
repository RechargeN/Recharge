package com.example.rechargenew.data.explore.entities

import com.example.rechargenew.data.explore.entities.model.HostEntity

class InMemoryHostRepository : HostRepository {

    private val store = mutableMapOf<String, HostEntity>()

    fun seedIfMissing(id: String, title: String) {
        store.putIfAbsent(
            id,
            HostEntity(
                id = id,
                title = title,
                about = "This is your creator page. Here you can show your events, photos and info.",
                tags = listOf("creator", "events")
            )
        )
    }

    override suspend fun getById(id: String): HostEntity? = store[id]
}
