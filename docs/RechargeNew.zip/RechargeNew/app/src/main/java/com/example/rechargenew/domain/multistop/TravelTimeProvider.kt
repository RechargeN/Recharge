package com.example.rechargenew.domain.multistop

enum class TravelMode { DRIVE, TRANSIT, WALK, BIKE }

interface TravelTimeProvider {
    /** Возвращает время в пути в минутах между A и B (в одну сторону). */
    suspend fun minutesBetween(a: GeoPoint, b: GeoPoint, mode: TravelMode): Int
}