package com.example.rechargenew.ui.screens.explore.create

import androidx.compose.runtime.Composable
import com.example.rechargenew.ui.events.create.CreateEventScreen

@Composable
fun ExploreCreateEventScreen(
    onBack: () -> Unit,
    onCreated: () -> Unit
) {
    CreateEventScreen(
        onBack = onBack,
        onCreated = onCreated
    )
}
