package com.example.rechargenew.data.explore.roles

import com.example.rechargenew.domain.explore.model.UserRole
import kotlinx.coroutines.flow.StateFlow

interface RoleRepository {
    val rolesFlow: StateFlow<Set<UserRole>>
    fun hasRole(role: UserRole): Boolean
    suspend fun addRole(role: UserRole)
}
