package com.example.rechargenew.domain.multistop

data class GeoPoint(val lat: Double, val lng: Double)

enum class ItineraryStatus { PRIMARY, NEAR }

data class ItineraryStop(
    val eventId: String,
    val title: String,
    val point: GeoPoint,
    val durationMinutes: Int,
    val costTotal: Double
)

data class Itinerary(
    val stops: List<ItineraryStop>,
    val travelMinutesTotal: Int,
    val activityMinutesTotal: Int,
    val bufferMinutes: Int,
    val totalMinutes: Int,
    val totalCost: Double,
    val status: ItineraryStatus,
    val explanation: String? = null
)