package com.example.rechargenew.ui.features.explore.entity.model

enum class EntityTypeUi(val label: String) {
    USER("User"),
    PLACE("Place"),
    HOST("Creator"),
    LOCATION("Location");

    companion object {
        fun from(raw: String): EntityTypeUi = when (raw.trim().lowercase()) {
            "user" -> USER
            "place" -> PLACE
            "host" -> HOST
            "location" -> LOCATION
            else -> USER
        }
    }
}
