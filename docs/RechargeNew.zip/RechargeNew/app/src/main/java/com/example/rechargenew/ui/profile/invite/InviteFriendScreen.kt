package com.example.rechargenew.ui.profile.invite

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InviteFriendScreen(
    inviteCode: String = "RECHARGE-NIKITA-123",
    onBack: () -> Unit = {},
    onCopyClick: (String) -> Unit = {},
    onShareClick: (String) -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Invite a friend") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Share Recharge with your friends",
                style = MaterialTheme.typography.titleMedium
            )

            Text(
                text = "Invite friends to discover activities together. " +
                        "They can use your code during sign up.",
                style = MaterialTheme.typography.bodyMedium
            )

            OutlinedTextField(
                value = inviteCode,
                onValueChange = {},
                readOnly = true,
                label = { Text("Your invite code") },
                trailingIcon = {
                    IconButton(onClick = { onCopyClick(inviteCode) }) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy invite code"
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { onShareClick(inviteCode) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Share code")
            }
        }
    }
}
