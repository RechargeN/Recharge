package com.example.rechargenew.ui.features.explore.entity.model

enum class EntityTabUi { UPCOMING, PAST, PHOTOS }
