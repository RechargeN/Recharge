package com.example.rechargenew.domain.explore.model

@JvmInline
value class EntityId(val value: String) {
    init {
        require(value.isNotBlank()) { "EntityId cannot be blank" }
    }
}
