package com.example.rechargenew.ui.profile.reviews

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class UserReview(
    val id: String,
    val title: String,     // "Stand-up night"
    val rating: Int,       // 1..5
    val date: String,      // "12 Oct 2025"
    val comment: String    // короткий текст
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyReviewsScreen(
    reviews: List<UserReview>,
    onBack: () -> Unit = {},
    onReviewClick: (UserReview) -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My reviews") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (reviews.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
            ) {
                Text("You haven't left any reviews yet.")
                Spacer(Modifier.height(4.dp))
                Text(
                    "After visiting activities, you can rate them and see your reviews here.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(reviews) { review ->
                    ReviewItem(
                        item = review,
                        onClick = { onReviewClick(review) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ReviewItem(
    item: UserReview,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(item.title, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(2.dp))
        Text(
            "${item.rating}/5 • ${item.date}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (item.comment.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                text = item.comment,
                style = MaterialTheme.typography.bodySmall
            )
        }
        Divider(Modifier.padding(top = 12.dp))
    }
}
