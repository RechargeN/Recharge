package com.example.rechargenew.domain.multistop

data class CandidateStop(
    val eventId: String,
    val title: String,
    val point: GeoPoint,
    val durationMinutes: Int,
    val costTotal: Double // уже для people (или просто total, как у тебя принято)
)