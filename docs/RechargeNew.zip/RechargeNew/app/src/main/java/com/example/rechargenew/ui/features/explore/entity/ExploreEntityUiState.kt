package com.example.rechargenew.ui.features.explore.entity

import com.example.rechargenew.ui.events.EventModel
import com.example.rechargenew.ui.features.explore.entity.model.EntityActionUi
import com.example.rechargenew.ui.features.explore.entity.model.EntityHeaderUi
import com.example.rechargenew.ui.features.explore.entity.model.EntityTabUi
import com.example.rechargenew.ui.features.explore.entity.model.EntityTypeUi

data class ExploreEntityUiState(
    val entityType: EntityTypeUi = EntityTypeUi.USER,
    val entityId: String = "",

    val header: EntityHeaderUi = EntityHeaderUi(),
    val activeTab: EntityTabUi = EntityTabUi.UPCOMING,

    val upcomingEvents: List<EventModel> = emptyList(),
    val pastEvents: List<EventModel> = emptyList(),
    val photoUrls: List<String> = emptyList(),

    val about: String = "",
    val tags: List<String> = emptyList(),

    // что показывать как действия (кнопки)
    val actions: List<EntityActionUi> = emptyList(),

    val isLoading: Boolean = false,
    val error: String? = null
)
