package com.example.rechargenew.ui.events.create

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rechargenew.data.categories.CategoriesRepository
import com.example.rechargenew.data.categories.CategoryData
import com.example.rechargenew.data.categories.SubcategoryData
import com.example.rechargenew.model.EventCategory
import com.example.rechargenew.ui.events.EventCard
import com.example.rechargenew.ui.events.EventModel
import java.util.Calendar
import com.example.rechargenew.model.EventKind
import com.example.rechargenew.model.TimeOfDay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateEventScreen(
    onBack: () -> Unit,
    onCreated: () -> Unit,
    viewModel: CreateEventViewModel = viewModel()
) {
    val uiState by viewModel.uiState
    val context = LocalContext.current
    Button(
        onClick = { viewModel.saveEvent(context) }, // ✅
        enabled = !uiState.isSaving
    ) {
        Text(if (uiState.isSaving) "Saving..." else "Create event")
    }
    var categories by remember { mutableStateOf<List<CategoryData>>(emptyList()) }
    var subcategories by remember { mutableStateOf<List<SubcategoryData>>(emptyList()) }

    var activeCategory by remember { mutableStateOf<EventCategory?>(null) }

    LaunchedEffect(Unit) {
        categories = CategoriesRepository.getCategories(context)
        subcategories = CategoriesRepository.getSubcategories(context)
    }

    LaunchedEffect(uiState.draft.categories) {
        if (activeCategory !in uiState.draft.categories) {
            activeCategory = uiState.draft.categories.firstOrNull()
        }
    }

    LaunchedEffect(uiState.isSaved) {
        if (uiState.isSaved) {
            Toast.makeText(context, "Event created 🎉", Toast.LENGTH_SHORT).show()
            viewModel.resetSavedFlag()
            onCreated()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Create event") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            OutlinedTextField(
                value = uiState.draft.title,
                onValueChange = viewModel::updateTitle,
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = uiState.validation.titleError != null
            )
            uiState.validation.titleError?.let { errorText ->
                Text(
                    text = errorText,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            OutlinedTextField(
                value = uiState.draft.description,
                onValueChange = viewModel::updateDescription,
                label = { Text("Description") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 100.dp),
                isError = uiState.validation.descriptionError != null
            )
            uiState.validation.descriptionError?.let { errorText ->
                Text(
                    text = errorText,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            TypeAndTimeSection(
                kind = uiState.draft.kind,
                recommendedTimes = uiState.draft.recommendedTimes,
                onKindChange = { kind -> viewModel.updateKind(kind) },
                onToggleTime = { t -> viewModel.toggleRecommendedTime(t) }
            )

            CategoriesSection(
                selectedCategories = uiState.draft.categories,
                activeCategory = activeCategory,
                selectedSubcategoryIdsByCategory = uiState.draft.subcategoryIdsByCategory,
                categories = categories,
                subcategories = subcategories,
                onCategoryClick = { category ->
                    viewModel.toggleCategory(category)
                    activeCategory = category
                },
                onSubcategoryClick = { subId ->
                    activeCategory?.let { cat ->
                        viewModel.toggleSubcategory(cat, subId)
                    }
                },
                error = uiState.validation.categoryError
            )

            DateTimeSection(
                dateTimeMillis = uiState.draft.dateTimeMillis,
                onPickDateClick = {
                    val cal = Calendar.getInstance().apply {
                        uiState.draft.dateTimeMillis?.let { timeInMillis = it }
                    }

                    DatePickerDialog(
                        context,
                        { _, year, month, dayOfMonth ->
                            val newCal = Calendar.getInstance().apply {
                                timeInMillis =
                                    uiState.draft.dateTimeMillis ?: System.currentTimeMillis()
                                set(Calendar.YEAR, year)
                                set(Calendar.MONTH, month)
                                set(Calendar.DAY_OF_MONTH, dayOfMonth)
                            }
                            viewModel.updateDateTime(newCal.timeInMillis)
                        },
                        cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                },
                onPickTimeClick = {
                    val cal = Calendar.getInstance().apply {
                        uiState.draft.dateTimeMillis?.let { timeInMillis = it }
                    }

                    TimePickerDialog(
                        context,
                        { _, hourOfDay, minute ->
                            val newCal = Calendar.getInstance().apply {
                                timeInMillis =
                                    uiState.draft.dateTimeMillis ?: System.currentTimeMillis()
                                set(Calendar.HOUR_OF_DAY, hourOfDay)
                                set(Calendar.MINUTE, minute)
                                set(Calendar.SECOND, 0)
                                set(Calendar.MILLISECOND, 0)
                            }
                            viewModel.updateDateTime(newCal.timeInMillis)
                        },
                        cal.get(Calendar.HOUR_OF_DAY),
                        cal.get(Calendar.MINUTE),
                        true
                    ).show()
                },
                error = uiState.validation.dateError
            )

            OutlinedTextField(
                value = uiState.draft.price?.toString().orEmpty(),
                onValueChange = viewModel::updatePrice,
                label = { Text("Price (optional)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = uiState.validation.priceError != null
            )
            uiState.validation.priceError?.let { errorText ->
                Text(
                    text = errorText,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            LocationSection(
                location = uiState.draft.location,
                onLocationChanged = viewModel::updateLocation,
                onUseCurrentLocationClick = viewModel::useCurrentLocation,
                error = uiState.validation.locationError
            )

            PhotoPicker(
                photoUris = uiState.draft.photoUris,
                onPhotosPicked = { uris -> viewModel.updatePhotos(uris) }
            )

            uiState.saveError?.let {
                Text(
                    text = it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            EventPreviewSection(uiState = uiState)

            Button(
                onClick = { viewModel.saveEvent(context) }, // ✅ ВОТ ЭТО И БЫЛО ГЛАВНОЕ
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                enabled = !uiState.isSaving
            ) {
                Text(if (uiState.isSaving) "Saving..." else "Create event")
            }
        }
    }
}

@Composable
private fun TypeAndTimeSection(
    kind: EventKind,
    recommendedTimes: List<TimeOfDay>,
    onKindChange: (EventKind) -> Unit,
    onToggleTime: (TimeOfDay) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(text = "Type", style = MaterialTheme.typography.titleMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = kind == EventKind.ONE_TIME,
                onClick = { onKindChange(EventKind.ONE_TIME) },
                label = { Text("One-time") }
            )
            FilterChip(
                selected = kind == EventKind.PLACE,
                onClick = { onKindChange(EventKind.PLACE) },
                label = { Text("Place / spot") }
            )
        }

        if (kind == EventKind.PLACE) {
            Spacer(Modifier.height(4.dp))

            Text(
                text = "Best time to visit",
                style = MaterialTheme.typography.bodyMedium
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TimeOfDayChip("Morning", TimeOfDay.MORNING, recommendedTimes.contains(TimeOfDay.MORNING), onToggleTime)
                TimeOfDayChip("Day", TimeOfDay.DAY, recommendedTimes.contains(TimeOfDay.DAY), onToggleTime)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TimeOfDayChip("Evening", TimeOfDay.EVENING, recommendedTimes.contains(TimeOfDay.EVENING), onToggleTime)
                TimeOfDayChip("Night", TimeOfDay.NIGHT, recommendedTimes.contains(TimeOfDay.NIGHT), onToggleTime)
            }
        }
    }
}

@Composable
private fun TimeOfDayChip(
    label: String,
    time: TimeOfDay,
    selected: Boolean,
    onToggle: (TimeOfDay) -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = { onToggle(time) },
        label = { Text(label) }
    )
}

@Composable
private fun EventPreviewSection(
    uiState: CreateEventUiState
) {
    val draft = uiState.draft
    val primaryCategory = draft.categories.firstOrNull()?.name ?: "OTHER"

    val locationName = draft.location?.address ?: "Location will be here"
    val isFree = draft.price == null || draft.price == 0.0

    val shortDescription = when {
        draft.description.isBlank() -> "Short description of your activity."
        draft.description.length <= 100 -> draft.description
        else -> draft.description.take(97) + "..."
    }

    val coverPhoto = draft.photoUris.firstOrNull() ?: draft.photoUri ?: ""

    val tags = buildList {
        draft.categories.forEach { add(it.name) }
        draft.subcategoryIdsByCategory.values.forEach { addAll(it) }
    }

    val previewEvent = EventModel(
        id = "preview",
        title = if (draft.title.isBlank()) "Your event title" else draft.title.trim(),
        category = primaryCategory,
        imageUrl = coverPhoto,
        dateTimeMillis = draft.dateTimeMillis ?: System.currentTimeMillis(),
        locationName = locationName,
        latitude = draft.location?.latitude,
        longitude = draft.location?.longitude,
        price = draft.price,
        isFree = isFree,
        maxParticipants = null,
        currentParticipants = null,
        isFavorite = false,
        tags = tags,
        shortDescription = shortDescription,
        fullDescription = draft.description
    )

    Spacer(Modifier.height(16.dp))
    Text(text = "Preview", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))

    EventCard(
        event = previewEvent,
        onClick = {},
        onToggleFavorite = {}
    )
}
