package com.example.rechargenew.ui.screens.explore.myevents

import androidx.lifecycle.ViewModel
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.ui.events.EventModel
import kotlinx.coroutines.flow.StateFlow

class ExploreMyEventsViewModel : ViewModel() {
    val events: StateFlow<List<EventModel>> = EventRepository.events
}
