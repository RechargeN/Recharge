package com.example.rechargenew.model

/**
 * Глобальные категории событий.
 * Используются в модели Event (D), фильтрах и логике рекомендаций.
 */
enum class EventCategory {
    MUSIC,              // концерты, фестивали
    NIGHTLIFE,          // клубы, вечеринки, бары
    COMEDY,             // стендап, импро
    THEATRE_SHOWS,      // театр, мюзиклы, шоу
    ART_CULTURE,        // музеи, выставки, галереи
    FILM_MEDIA,         // кино, показы, премьеры

    SPORTS_FITNESS,     // спорт, фитнес, йога, бег
    FOOD_DRINK,         // еда, дегустации, бары, гастро
    GAMES_ENTERTAINMENT,// настолки, квизы, турниры
    TRAVEL_OUTDOOR,     // прогулки, туры, походы

    BUSINESS_NETWORKING,// бизнес-встречи, networking
    SCIENCE_TECH,       // IT, наука, технологии
    WORKSHOPS_CLASSES,  // мастер-классы, обучение
    COMMUNITY_CHARITY,  // коммьюнити, благотворительность

    SPIRIT_WELLNESS,    // медитации, ретриты, ментальное здоровье
    FAMILY_KIDS,        // семья, дети
    FASHION_BEAUTY,     // мода, красота
    HEALTH_LIFESTYLE,   // ЗОЖ, привычки

    PETS_ANIMALS,       // мероприятия с животными
    FAITH_RELIGION,     // церковные/религиозные события
    GOV_POLITICS,       // государство, политика
    HOLIDAY_SEASONAL,   // Новый год, Хэллоуин и т.п.
    LGBTQ_PLUS,         // LGBTQ+ мероприятия
    LITERATURE,         // книги, поэзия
    AUTO_MOTO,          // авто/мото мероприятия
    HOME_HOBBY,         // дом, сад, DIY
    ADULT_18_PLUS       // 18+ (если будешь использовать)
}
