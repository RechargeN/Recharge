package com.example.rechargenew.data.categories

import android.content.Context
import android.util.Log
import com.example.rechargenew.model.EventCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

/**
 * Репозиторий категорий и подкатегорий.
 *
 * C:
 *  - категории храним в коде (enum EventCategory + defaultCategories()).
 *
 * C-sub:
 *  - подкатегории читаем из assets/subcategories.json
 *    (id: String, parentId: String, title: String).
 *
 * Так мы можем иметь 1000+ подкатегорий без изменения кода.
 */
object CategoriesRepository {

    private var categoriesCache: List<CategoryData>? = null
    private var subcategoriesCache: List<SubcategoryData>? = null

    // ---------- Публичное API ----------

    suspend fun getCategories(context: Context): List<CategoryData> =
        withContext(Dispatchers.IO) {
            categoriesCache ?: defaultCategories().also { categoriesCache = it }
        }

    suspend fun getSubcategories(context: Context): List<SubcategoryData> =
        withContext(Dispatchers.IO) {
            subcategoriesCache ?: loadSubcategoriesFromAssets(context).also {
                subcategoriesCache = it
            }
        }

    suspend fun getSubcategoriesFor(
        category: EventCategory,
        context: Context
    ): List<SubcategoryData> {
        val all = getSubcategories(context)
        return all.filter { it.parent == category }
    }

    // ---------- Локальные данные: список категорий (C) ----------

    private fun defaultCategories(): List<CategoryData> = listOf(
        CategoryData(
            id = EventCategory.MUSIC,
            title = "Music",
            subtitle = "Concerts & festivals",
            emoji = "🎵"
        ),
        CategoryData(
            id = EventCategory.NIGHTLIFE,
            title = "Nightlife",
            subtitle = "Clubs, bars & parties",
            emoji = "🍸"
        ),
        CategoryData(
            id = EventCategory.COMEDY,
            title = "Comedy",
            subtitle = "Stand-up & improv",
            emoji = "🎤"
        ),
        CategoryData(
            id = EventCategory.THEATRE_SHOWS,
            title = "Theatre & Shows",
            subtitle = "Plays, musicals, shows",
            emoji = "🎭"
        ),
        CategoryData(
            id = EventCategory.ART_CULTURE,
            title = "Art & Culture",
            subtitle = "Museums & exhibitions",
            emoji = "🖼️"
        ),
        CategoryData(
            id = EventCategory.FILM_MEDIA,
            title = "Film & Media",
            subtitle = "Cinema & screenings",
            emoji = "🎬"
        ),
        CategoryData(
            id = EventCategory.SPORTS_FITNESS,
            title = "Sports & Fitness",
            subtitle = "Running, gym, yoga",
            emoji = "🏃"
        ),
        CategoryData(
            id = EventCategory.FOOD_DRINK,
            title = "Food & Drink",
            subtitle = "Restaurants & tastings",
            emoji = "🍽️"
        ),
        CategoryData(
            id = EventCategory.GAMES_ENTERTAINMENT,
            title = "Games & Fun",
            subtitle = "Board games & quizzes",
            emoji = "🎲"
        ),
        CategoryData(
            id = EventCategory.TRAVEL_OUTDOOR,
            title = "Travel & Outdoor",
            subtitle = "Walks, hikes & trips",
            emoji = "🌿"
        ),
        CategoryData(
            id = EventCategory.BUSINESS_NETWORKING,
            title = "Business & Networking",
            subtitle = "Meetups & talks",
            emoji = "💼"
        ),
        CategoryData(
            id = EventCategory.SCIENCE_TECH,
            title = "Science & Tech",
            subtitle = "IT, science & gadgets",
            emoji = "💡"
        ),
        CategoryData(
            id = EventCategory.WORKSHOPS_CLASSES,
            title = "Workshops & Classes",
            subtitle = "Learn something new",
            emoji = "🧠"
        ),
        CategoryData(
            id = EventCategory.COMMUNITY_CHARITY,
            title = "Community & Charity",
            subtitle = "Meetups & volunteering",
            emoji = "🤝"
        ),
        CategoryData(
            id = EventCategory.SPIRIT_WELLNESS,
            title = "Mind & Wellness",
            subtitle = "Meditation, self-care",
            emoji = "🧘"
        ),
        CategoryData(
            id = EventCategory.FAMILY_KIDS,
            title = "Family & Kids",
            subtitle = "For kids & parents",
            emoji = "👨‍👩‍👧"
        ),
        CategoryData(
            id = EventCategory.FASHION_BEAUTY,
            title = "Fashion & Beauty",
            subtitle = "Style & self-care",
            emoji = "💄"
        ),
        CategoryData(
            id = EventCategory.HEALTH_LIFESTYLE,
            title = "Health & Lifestyle",
            subtitle = "Habits & wellbeing",
            emoji = "🌱"
        ),
        CategoryData(
            id = EventCategory.PETS_ANIMALS,
            title = "Pets & Animals",
            subtitle = "Dog meetups & more",
            emoji = "🐾"
        ),
        CategoryData(
            id = EventCategory.FAITH_RELIGION,
            title = "Faith & Religion",
            subtitle = "Spiritual gatherings",
            emoji = "⛪"
        ),
        CategoryData(
            id = EventCategory.GOV_POLITICS,
            title = "Gov & Politics",
            subtitle = "Talks & discussions",
            emoji = "🏛️"
        ),
        CategoryData(
            id = EventCategory.HOLIDAY_SEASONAL,
            title = "Holiday & Seasonal",
            subtitle = "NY, Halloween & more",
            emoji = "🎉"
        ),
        CategoryData(
            id = EventCategory.LITERATURE,
            title = "Books & Literature",
            subtitle = "Book clubs & talks",
            emoji = "📚"
        ),
        CategoryData(
            id = EventCategory.AUTO_MOTO,
            title = "Auto & Moto",
            subtitle = "Meets & shows",
            emoji = "🏎️"
        ),
        CategoryData(
            id = EventCategory.HOME_HOBBY,
            title = "Home & Hobby",
            subtitle = "DIY, garden & more",
            emoji = "🏡"
        ),
        CategoryData(
            id = EventCategory.ADULT_18_PLUS,
            title = "18+",
            subtitle = "Adult only",
            emoji = "🔞"
        )
    )

    // ---------- Подкатегории: читаем из assets/subcategories.json ----------

    private fun loadSubcategoriesFromAssets(context: Context): List<SubcategoryData> {
        return try {
            val jsonStr = context.assets.open("subcategories.json")
                .bufferedReader()
                .use { it.readText() }

            val jsonArray = JSONArray(jsonStr)
            val result = mutableListOf<SubcategoryData>()

            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)

                val id = obj.getString("id")              // "music_concerts"
                val parentId = obj.getString("parentId")  // "MUSIC"
                val title = obj.getString("title")        // "Concerts"

                val parentEnum = try {
                    EventCategory.valueOf(parentId)
                } catch (e: IllegalArgumentException) {
                    Log.w("CategoriesRepository", "Unknown parentId=$parentId in subcategories.json")
                    continue
                }

                result += SubcategoryData(
                    id = id,
                    parent = parentEnum,
                    title = title
                )
            }

            result
        } catch (e: Exception) {
            Log.e("CategoriesRepository", "Failed to load subcategories.json", e)
            emptyList()
        }
    }
}
