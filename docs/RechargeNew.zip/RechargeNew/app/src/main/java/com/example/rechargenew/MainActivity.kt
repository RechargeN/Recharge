package com.example.rechargenew

import com.example.rechargenew.ui.features.explore.navigation.exploreNavGraph
import com.example.rechargenew.data.explore.ExploreDI
import android.os.Bundle
import androidx.compose.runtime.LaunchedEffect
import com.example.rechargenew.ui.screens.settings.ProfileSettingsScreen
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rechargenew.ui.events.EventsViewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rechargenew.data.events.EventStorage
import com.example.rechargenew.ui.categories.CategoriesScreen
import com.example.rechargenew.ui.dcba.DCBAScreen
import com.example.rechargenew.ui.events.EventDetailsScreen
import com.example.rechargenew.ui.events.EventsFeedScreen
import com.example.rechargenew.ui.events.EventsDestinations
import com.example.rechargenew.ui.events.create.CreateEventScreen
import com.example.rechargenew.ui.favorites.FavoritesScreen
import com.example.rechargenew.ui.map.MapScreen
import com.example.rechargenew.ui.notifications.NotificationsScreen
import com.example.rechargenew.ui.profile.ProfileScreen
import com.example.rechargenew.ui.screens.hub.MainHubScreen
import com.example.rechargenew.ui.search.SearchScreen
import com.example.rechargenew.ui.theme.RechargeNewTheme
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.SideEffect
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.ui.screens.explore.exploreNavGraph
import com.example.rechargenew.ui.screens.explore.ExploreRoutes

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lifecycleScope.launch {
            EventRepository.init(applicationContext)
        }

        setContent {
            RechargeNewTheme {
                RechargeApp()
            }
        }
    }

}

@Composable
fun RechargeApp() {
    val navController = rememberNavController()

    // --- глобальная настройка системных баров ---
    val systemUi = rememberSystemUiController()
    val appGreen = Color(0xFF173f35)
    val bottomBarColor = Color(0xFFEAEAF0)   // как твой низ

    SideEffect {
        systemUi.setStatusBarColor(
            color = appGreen,
            darkIcons = false      // белые иконки
        )
        systemUi.setNavigationBarColor(
            color = bottomBarColor,
            darkIcons = true
        )
    }

    Scaffold(
        bottomBar = {
            BottomNavBar(navController = navController)
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(appGreen)    // фон по умолчанию для всех экранов
        ) {
            AppNavHost(navController = navController)
        }
    }
}

@Composable
fun AppNavHost(navController: NavHostController) {
    // 🔹 Один общий ViewModel для всех экранов с событиями
    val eventsViewModel: EventsViewModel = viewModel()

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {

        // АБЦД – главный хаб
        composable("home") {
            MainHubScreen(navController = navController)
        }

        // DG – избранное
        composable("favorites") {
            FavoritesScreen(
                onEventClick = { eventId ->
                    navController.navigate("event_details/$eventId")
                },
                onGoToSearchClick = {
                    navController.navigate(EventsDestinations.SEARCH) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }

        // DCBA – умный поиск
        composable("dcba") { DCBAScreen() }

        // U – уведомления
        composable("notifications") { NotificationsScreen() }

        // Profile (временно, позже заменим на MyRecharge)
        composable("profile") {
            val userId = com.example.rechargenew.data.explore.ExploreDI.session.userId

            androidx.compose.runtime.LaunchedEffect(userId) {
                navController.navigate(
                    com.example.rechargenew.ui.features.explore.navigation.ExploreRoutes.entity("user", userId)
                ) {
                    launchSingleTop = true
                    popUpTo("profile") { inclusive = true } // чтобы не оставался "profile" в стеке
                }
            }
        }


        // старый экран создания события (пока оставляем)
        composable("create_event") {
            CreateEventScreen(
                onBack = { navController.popBackStack() },
                onCreated = { navController.popBackStack() }
            )
        }
        composable("settings_profile") {
            com.example.rechargenew.ui.screens.settings.ProfileSettingsScreen(
                onBack = { navController.popBackStack() }
            )
        }


        // A – поиск
        composable(EventsDestinations.SEARCH) {
            SearchScreen(
                navController = navController,
                eventsViewModel = eventsViewModel
            )
        }

        // B – карта
        composable("map") {
            MapScreen(
                navController = navController,
                eventsViewModel = eventsViewModel
            )
        }

        // C – категории
        composable("categories") {
            CategoriesScreen()
        }

        // D – лента событий
        composable(EventsDestinations.FEED) {
            EventsFeedScreen(
                eventsViewModel = eventsViewModel,
                onEventClick = { eventId ->
                    navController.navigate("event_details/$eventId")
                }
            )
        }

        // D – деталка события
        composable(
            route = "event_details/{eventId}",
            arguments = listOf(
                navArgument("eventId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getString("eventId") ?: return@composable

            EventDetailsScreen(
                eventId = eventId,
                onBackClick = { navController.popBackStack() }
            )
        }

        // =====================================================
        // ✅ ШАГ 3 — ПОДКЛЮЧАЕМ EXPLORE (наш блок L)
        // =====================================================
        exploreNavGraph(
            navController = navController,
            startDestination = ExploreRoutes.ORGANIZER_HUB,
            eventDetailsRouteBuilder = { eventId ->
                "event_details/$eventId" // твой реальный route
            }
        )
        exploreNavGraph(
            navController = navController,
            startDestination = com.example.rechargenew.ui.features.explore.navigation.ExploreRoutes.ENTITY,
            eventDetailsRouteBuilder = { eventId -> "event_details/$eventId" },
            onOpenSettings = { val userId = com.example.rechargenew.data.explore.ExploreDI.session.userId
                navController.navigate(
                    com.example.rechargenew.ui.features.explore.navigation.ExploreRoutes.entity("user", userId)
                ) {
                    launchSingleTop = true
                    restoreState = true
                }
            }
        )
        exploreNavGraph(
            navController = navController,
            startDestination = ExploreRoutes.ENTITY,
            eventDetailsRouteBuilder = { eventId -> "event_details/$eventId" },
            onOpenSettings = { navController.navigate("settings_profile") }
        )

    }
}


// ---- Bottom Navigation ----

data class BottomNavItem(
    val route: String,
    val emoji: String,
    val label: String
)

private val bottomNavItems = listOf(
    BottomNavItem("home",         "🏠", "ABCD"),
    BottomNavItem("favorites",    "♥",  "DG"),
    BottomNavItem("dcba",         "💡", "DCBA"),
    BottomNavItem("notifications","🔔","U"),
    BottomNavItem("profile",      "👤", "E")
)

@Composable
fun BottomNavBar(navController: NavHostController) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar {

        // current destination
        val navBackStackEntry = navController.currentBackStackEntryAsState().value
        val currentDestination = navBackStackEntry?.destination

        // this is the route of the ABCD tab (🏠)
        val homeRoute = bottomNavItems.first { it.label == "ABCD" }.route
        // if your labels are different, you can use emoji instead:
        // val homeRoute = bottomNavItems.first { it.emoji == "🏠" }.route

        bottomNavItems.forEach { item ->

            val selected = currentDestination?.route == item.route

            NavigationBarItem(
                selected = selected,
                onClick = {
                    if (item.route == homeRoute) {
                        // 🏠 ABCD – always go to main screen
                        navController.navigate(homeRoute) {
                            // remove everything above main from the back stack
                            popUpTo(homeRoute) {
                                inclusive = false
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    } else {
                        // other tabs – normal navigation
                        navController.navigate(item.route) {
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = { Text(text = item.emoji) },
                label = { Text(text = item.label) }
            )
        }
    }

}
