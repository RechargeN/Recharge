package com.example.rechargenew.domain.multistop

import com.example.rechargenew.data.filters.FilterState
import com.example.rechargenew.ui.events.EventModel

fun FilterState.toTravelMode(): TravelMode = when (travelMode.uppercase()) {
    "TRANSIT" -> TravelMode.TRANSIT
    "WALK" -> TravelMode.WALK
    "BIKE" -> TravelMode.BIKE
    else -> TravelMode.DRIVE
}

fun defaultDurationByCategory(category: String): Int {
    val c = category.lowercase()
    return when {
        c.contains("museum") -> 120
        c.contains("cinema") || c.contains("movie") -> 150
        c.contains("bowling") -> 90
        c.contains("billiard") || c.contains("pool") -> 90
        c.contains("restaurant") || c.contains("cafe") -> 90
        c.contains("park") -> 90
        c.contains("sport") || c.contains("tennis") || c.contains("gym") -> 90
        c.contains("spa") || c.contains("sauna") -> 180
        else -> 90
    }
}

fun computeTotalCostForPeople(event: EventModel, peopleCount: Int): Double {
    if (event.isFree) return 0.0
    val price = event.price ?: 0.0
    return price * peopleCount.coerceAtLeast(1)
}

fun EventModel.toCandidateStopOrNull(peopleCount: Int): CandidateStop? {
    val lat = latitude ?: return null
    val lng = longitude ?: return null
    val duration = defaultDurationByCategory(category)
    val cost = computeTotalCostForPeople(this, peopleCount)

    return CandidateStop(
        eventId = id,
        title = title,
        point = GeoPoint(lat, lng),
        durationMinutes = duration,
        costTotal = cost
    )
}