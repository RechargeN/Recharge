package com.example.rechargenew.ui.search

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.rechargenew.ui.events.EventCard
import com.example.rechargenew.ui.events.EventModel
import com.example.rechargenew.ui.events.EventsViewModel

@Composable
fun SearchScreen(
    navController: NavHostController,
    eventsViewModel: EventsViewModel
) {
    val uiState by eventsViewModel.uiState.collectAsState()

    SearchContent(
        events = uiState.events,
        onEventClick = { id ->
            // Пока просто заглушка, потом сделаем переход к деталям
            // navController.navigate("event_details/$id")
        }
    )
}

@Composable
private fun SearchContent(
    events: List<EventModel>,
    onEventClick: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(events, key = { it.id }) { event ->
            EventCard(
                event = event,
                onClick = { onEventClick(event.id) },
                onToggleFavorite = { /* избранное позже прикрутим */ }
            )
        }
    }
}
