package com.example.rechargenew.ui.profile.bookings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Booking(
    val id: String,
    val title: String,
    val date: String,       // "12 Oct, 19:00"
    val location: String,   // "Amsterdam"
    val status: String      // "Confirmed", "Pending", "Canceled"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyBookingsScreen(
    bookings: List<Booking>,
    onBack: () -> Unit = {},
    onBookingClick: (Booking) -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My bookings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (bookings.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
            ) {
                Text("You don't have bookings yet.")
                Spacer(Modifier.height(4.dp))
                Text(
                    "When you join activities, they will appear here.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(bookings) { booking ->
                    BookingItem(
                        item = booking,
                        onClick = { onBookingClick(booking) }
                    )
                }
            }
        }
    }
}

@Composable
private fun BookingItem(
    item: Booking,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(item.title, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(2.dp))
        Text(
            "${item.date} • ${item.location}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(2.dp))
        Text(
            "Status: ${item.status}",
            style = MaterialTheme.typography.bodySmall
        )
        Divider(Modifier.padding(top = 12.dp))
    }
}
