package com.example.rechargenew.data.events

import com.example.rechargenew.ui.events.EventModel

/**
 * Генератор мок-событий для тестирования карты и ленты.
 * Все события имеют координаты вокруг нескольких базовых точек.
 */
object MockEventsGenerator {

    // Базовые точки (например, центр города и рядом)
    private val baseLocations = listOf(
        52.3740 to 4.8897,   // центр
        52.3720 to 4.8950,
        52.3765 to 4.8820,
        52.3780 to 4.9000,
    )

    private val categories = listOf(
        "Comedy", "Games", "Sport", "Walk",
        "Party", "Concert", "Workshop", "Cinema"
    )

    /**
     * Генерирует [count] событий.
     */
    fun generate(count: Int = 2000): List<EventModel> {
        val now = System.currentTimeMillis()
        val list = mutableListOf<EventModel>()

        repeat(count) { index ->
            // 1) Координаты вокруг одной из базовых точек
            val (baseLat, baseLng) = baseLocations.random()

            // лёгкий разброс вокруг базовой точки (~1 км)
            val lat = baseLat + (-0.01..0.01).randomDouble()
            val lng = baseLng + (-0.01..0.01).randomDouble()

            // 2) Остальные поля события
            val category = categories.random()
            val title = "$category Event #$index"

            // время в ближайшие 30 часов
            val timeOffsetHours = (index % 30)
            val dateTimeMillis = now + timeOffsetHours * 60 * 60 * 1000L

            val priceOptions = listOf<Double?>(null, 0.0, 5.0, 10.0, 15.0)
            val price = priceOptions.random()
            val isFree = price == null || price == 0.0

            val locationName = "Mock location #${index % 15}"

            val shortDescription = "Short description for $title"
            val fullDescription =
                "Full description for $title. This is a mock event generated for testing the map and feed."

            val tags = buildList {
                add(category)
                add("mock")
                if (isFree) add("free") else add("paid")
            }

            val event = EventModel(
                id = "mock_$index",
                title = title,
                category = category,
                imageUrl = "",
                dateTimeMillis = dateTimeMillis,
                locationName = locationName,
                latitude = lat,
                longitude = lng,
                price = price,
                isFree = isFree,
                tags = tags,
                shortDescription = shortDescription,
                fullDescription = fullDescription
            )

            list += event
        }

        return list
    }

    // маленькое расширение для random Double в диапазоне
    private fun ClosedFloatingPointRange<Double>.randomDouble(): Double {
        val from = this.start
        val to = this.endInclusive
        return Math.random() * (to - from) + from
    }
}
