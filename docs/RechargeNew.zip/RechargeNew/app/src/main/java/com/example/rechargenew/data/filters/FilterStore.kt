package com.example.rechargenew.data.filters

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.example.rechargenew.data.filters.FilterState


object FilterStore {
    private val _state = MutableStateFlow(FilterState())
    val state: StateFlow<FilterState> = _state.asStateFlow()

    fun set(newState: FilterState) {
        _state.value = newState
    }

    fun update(block: (FilterState) -> FilterState) {
        _state.value = block(_state.value)
    }

    fun clear() {
        _state.value = FilterState()
    }
}
