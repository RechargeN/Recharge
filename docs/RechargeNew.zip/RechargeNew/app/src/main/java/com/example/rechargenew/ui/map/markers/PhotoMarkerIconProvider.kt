package com.example.rechargenew.ui.map.markers

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.BitmapDrawable
import androidx.collection.LruCache
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import coil.ImageLoader
import coil.request.ImageRequest
import coil.size.Size
import com.example.rechargenew.ui.events.EventModel
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory

class PhotoMarkerIconProvider {

    private val cache = LruCache<String, BitmapDescriptor>(200)

    fun iconFor(event: EventModel): BitmapDescriptor {
        val key = event.imageUrl.ifBlank { event.id }

        cache.get(key)?.let { return it }

        // Если фото пустое — отдаём плейсхолдер
        if (event.imageUrl.isBlank()) {
            return MarkerIconFactory.photoPlaceholderIcon()
        }

        // Пока фото ещё не готово — отдаём плейсхолдер.
        // Реальную загрузку сделаем лениво по месту, ниже через preload().
        return MarkerIconFactory.photoPlaceholderIcon()
    }

    suspend fun preload(context: Context, event: EventModel, sizePx: Int = 96) {
        val key = event.imageUrl.ifBlank { event.id }
        if (cache.get(key) != null) return
        if (event.imageUrl.isBlank()) return

        val loader = ImageLoader(context)
        val req = ImageRequest.Builder(context)
            .data(event.imageUrl)
            .size(Size(sizePx, sizePx))
            .allowHardware(false)
            .build()

        val drawable = loader.execute(req).drawable ?: return
        val bmp = (drawable as? BitmapDrawable)?.bitmap ?: return

        val rounded = makeRoundedBitmap(bmp, sizePx)
        val desc = BitmapDescriptorFactory.fromBitmap(rounded)
        cache.put(key, desc)
    }

    private fun makeRoundedBitmap(src: Bitmap, sizePx: Int): Bitmap {
        val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = RectF(0f, 0f, sizePx.toFloat(), sizePx.toFloat())
        val radius = sizePx / 2f

        // фон
        paint.color = Color(0xFFFFFFFF).toArgb()
        canvas.drawCircle(radius, radius, radius, paint)

        // клип под круг
        val clipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.save()
        canvas.clipRect(rect)
        canvas.drawCircle(radius, radius, radius * 0.92f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color(0xFFFFFFFF).toArgb()
        })
        canvas.restore()

        // рисуем картинку внутри круга
        val dst = RectF(sizePx * 0.06f, sizePx * 0.06f, sizePx * 0.94f, sizePx * 0.94f)
        canvas.drawBitmap(src, null, dst, Paint(Paint.ANTI_ALIAS_FLAG))

        // белая обводка
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color(0xFFFFFFFF).toArgb()
            style = Paint.Style.STROKE
            strokeWidth = sizePx * 0.06f
        }
        canvas.drawCircle(radius, radius, radius * 0.92f, stroke)

        return out
    }
}
