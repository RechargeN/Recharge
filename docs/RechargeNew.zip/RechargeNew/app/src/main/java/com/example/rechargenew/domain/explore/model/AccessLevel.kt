package com.example.rechargenew.domain.explore.model

/**
 * Уровень доступа пользователя к конкретной entity.
 * VIEWER — просто смотрит
 * CONTRIBUTOR — может дополнять (контент), если разрешено
 * EDITOR — может редактировать инфо
 * OWNER — владелец/держатель
 */
enum class AccessLevel {
    VIEWER,
    CONTRIBUTOR,
    EDITOR,
    OWNER
}
