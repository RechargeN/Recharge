package com.example.rechargenew.data.explore.session

import com.example.rechargenew.data.explore.roles.RoleRepository
import com.example.rechargenew.domain.explore.model.UserRole
import kotlinx.coroutines.flow.StateFlow

class DefaultSessionRepository(
    private val roleRepository: RoleRepository,
    override val userId: String = "user_me"
) : SessionRepository {
    override val rolesFlow: StateFlow<Set<UserRole>> = roleRepository.rolesFlow
}
