package com.example.rechargenew.ui.profile.history

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class VisitedEvent(
    val id: String,
    val title: String,
    val date: String,       // "12 Oct 2025"
    val location: String,   // "Rotterdam"
    val rating: Int? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    events: List<VisitedEvent>,
    onBack: () -> Unit = {},
    onEventClick: (VisitedEvent) -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Visited & history") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        if (events.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
            ) {
                Text("You haven't visited any activities yet.")
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "After joining activities, they will appear here.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(events) { visited ->
                    HistoryItem(
                        item = visited,
                        onClick = { onEventClick(visited) }
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryItem(
    item: VisitedEvent,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = item.title,
            style = MaterialTheme.typography.bodyLarge
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = "${item.date} • ${item.location}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (item.rating != null) {
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Your rating: ${item.rating}/5",
                style = MaterialTheme.typography.bodySmall
            )
        }

        Divider(modifier = Modifier.padding(top = 12.dp))
    }
}
