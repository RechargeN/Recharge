package com.example.rechargenew.ui.map

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Tune



enum class MapLocationMode { Current, PickOnMap, EnterCity }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapTopPanel(
    // state
    radiusMeters: Int?,
    locationLabel: String, // например: "Текущая" или "Groningen"
    isPickingCenter: Boolean,

    // actions
    onOpenLocationSheet: () -> Unit,
    onOpenRadiusSheet: () -> Unit,
    onOpenFiltersSheet: () -> Unit,
    onRequestMyLocation: () -> Unit,

    // chips actions (второй уровень)
    categoriesLabel: String,
    onCategoriesClick: () -> Unit,

    peopleLabel: String,
    onPeopleClick: () -> Unit,

    budgetLabel: String,
    isBudgetActive: Boolean,
    onBudgetClick: () -> Unit,

    isFreeOnly: Boolean,
    onToggleFree: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        tonalElevation = 2.dp,
        shadowElevation = 8.dp,
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
        modifier = Modifier
            .statusBarsPadding()
            .padding(12.dp)
            .fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ===== Row 1: Локация / Радиус / Иконки =====
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AssistChip(
                    onClick = onOpenLocationSheet,
                    label = { Text(locationLabel) }
                )

                val radiusText = if (radiusMeters == null) {
                    "Без радиуса"
                } else {
                    val km = (radiusMeters / 1000.0)
                    val pretty = if (km < 10) String.format("%.1f", km) else km.roundToInt().toString()
                    "Радиус: $pretty км"
                }

                AssistChip(
                    onClick = onOpenRadiusSheet,
                    label = { Text(radiusText) }
                )

                Spacer(Modifier.weight(1f))

                IconButton(onClick = onOpenFiltersSheet) {
                    Icon(Icons.Outlined.Tune, contentDescription = "Фильтры")
                }
                IconButton(onClick = onRequestMyLocation) {
                    Icon(Icons.Outlined.LocationOn, contentDescription = "Моё местоположение")
                }
            }

            // подсказка при выборе точки на карте
            if (isPickingCenter) {
                Text(
                    text = "Нажми на карту, чтобы выбрать центр поиска",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // ===== Row 2: Горизонтальные чипы (скролл) =====
            val chipItems = listOf(
                ChipItem(
                    key = "categories",
                    text = categoriesLabel,
                    selected = categoriesLabel != "Категории",
                    onClick = onCategoriesClick
                ),
                ChipItem(
                    key = "people",
                    text = peopleLabel,
                    selected = true,
                    onClick = onPeopleClick
                ),
                ChipItem(
                    key = "budget",
                    text = budgetLabel,
                    selected = isBudgetActive,
                    onClick = onBudgetClick
                ),
                ChipItem(
                    key = "free",
                    text = "Free",
                    selected = isFreeOnly,
                    onClick = onToggleFree
                )
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(end = 6.dp)
            ) {
                items(chipItems, key = { it.key }) { chip ->
                    FilterChip(
                        selected = chip.selected,
                        onClick = chip.onClick,
                        label = { Text(chip.text) }
                    )
                }
            }
        }
    }
}

private data class ChipItem(
    val key: String,
    val text: String,
    val selected: Boolean,
    val onClick: () -> Unit
)
