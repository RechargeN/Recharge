package com.example.rechargenew.ui.events

import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.data.filters.FilterState
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.min
import com.example.rechargenew.domain.multistop.GeoPoint
import com.example.rechargenew.domain.multistop.MultiStopRequest
import com.example.rechargenew.domain.multistop.CandidateStop
import com.example.rechargenew.domain.multistop.TravelMode
import com.example.rechargenew.domain.multistop.*

class EventsViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val PAGE_SIZE = 50
    }

    private val _uiState = MutableStateFlow(EventUiState())
    val uiState: StateFlow<EventUiState> = _uiState

    private var allEventsCache: List<EventModel> = emptyList()
    private var loadJob: Job? = null

    // ВАЖНО: эти зависимости должны быть объявлены ДО init,
    // иначе applyPaging() может вызваться раньше их инициализации.
    private val travelTimeProvider = LocalTravelTimeProvider()
    private val planner = MultiStopPlanner(travelTimeProvider)
    private val alternativesEngine = GuidedAlternativesEngine()

    init {
        viewModelScope.launch {
            EventRepository.events.collect { list ->
                allEventsCache = list
                val filtered = filterEvents(allEventsCache, _uiState.value.filter)
                applyPaging(filtered, _uiState.value.filter, resetPage = true)
            }
        }

        refresh(resetFilter = false)
    }

    fun refresh(resetFilter: Boolean = false) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isLoading = true,
                    isRefreshing = !resetFilter,
                    errorMessage = null,
                    filter = if (resetFilter) FilterState() else it.filter
                )
            }

            try {
                EventRepository.loadFromStorage(getApplication<Application>().applicationContext)
                _uiState.update { it.copy(isLoading = false, isRefreshing = false) }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        isRefreshing = false,
                        errorMessage = e.message ?: "Unknown error"
                    )
                }
            }
        }
    }

    fun updateFilter(transform: (FilterState) -> FilterState) {
        val oldFilter = _uiState.value.filter
        val newFilter = transform(oldFilter)
        if (newFilter == oldFilter) return

        viewModelScope.launch {
            val filtered = filterEvents(allEventsCache, newFilter)
            applyPaging(filtered, newFilter, resetPage = true)
        }
    }

    fun loadNextPage() {
        val current = _uiState.value
        if (!current.canLoadMore || current.isLoading) return

        viewModelScope.launch {
            val filtered = filterEvents(allEventsCache, current.filter)
            applyPaging(filtered, current.filter, resetPage = false)
        }
    }

    private suspend fun estimateMinRequiredMinutes(
        filter: FilterState,
        candidates: List<EventModel>,
        origin: GeoPoint,
        mode: TravelMode
    ): Int? {
        val stopsToTake = filter.maxStops.coerceIn(2, 4)

        val candidateStops = candidates.mapNotNull { event ->
            val lat = event.latitude ?: return@mapNotNull null
            val lng = event.longitude ?: return@mapNotNull null

            val duration = defaultDurationByCategory(event.category)
            val point = GeoPoint(lat, lng)
            val travelFromOrigin = travelTimeProvider.minutesBetween(origin, point, mode)

            Triple(point, duration, travelFromOrigin)
        }

        if (candidateStops.size < stopsToTake) return null

        val best = candidateStops
            .sortedBy { it.third + it.second }
            .take(stopsToTake)

        val travel = best.sumOf { it.third } + if (filter.includeReturnTrip) best.last().third else 0
        val activity = best.sumOf { it.second }
        val buffer = maxOf(10, (travel * 0.15).toInt())

        return travel + activity + buffer
    }

    private suspend fun applyPaging(
        filtered: List<EventModel>,
        newFilter: FilterState,
        resetPage: Boolean
    ) {
        val currentPage = if (resetPage) 0 else _uiState.value.page + 1

        val from = currentPage * PAGE_SIZE
        val to = min(from + PAGE_SIZE, filtered.size)

        val pageItems = if (from < filtered.size) {
            filtered.subList(from, to)
        } else {
            emptyList()
        }

        val origin = newFilter.centerLat?.let { lat ->
            newFilter.centerLng?.let { lng ->
                GeoPoint(lat, lng)
            }
        }

        val itineraries = if (origin != null) {
            buildItinerariesIfNeeded(
                filter = newFilter,
                candidates = filtered,
                origin = origin
            )
        } else {
            emptyList()
        }

        val people = newFilter.peopleCount.coerceAtLeast(1)

        val cheapestSingleOptionTotal = filtered
            .map { computeTotalCostForPeople(it, people) }
            .minOrNull()

        val mode = when (newFilter.travelMode.uppercase()) {
            "TRANSIT" -> TravelMode.TRANSIT
            "WALK" -> TravelMode.WALK
            "BIKE" -> TravelMode.BIKE
            else -> TravelMode.DRIVE
        }

        val shortestTravelMinutes = if (origin != null) {
            filtered.mapNotNull { event ->
                val lat = event.latitude ?: return@mapNotNull null
                val lng = event.longitude ?: return@mapNotNull null
                travelTimeProvider.minutesBetween(
                    origin,
                    GeoPoint(lat, lng),
                    mode
                )
            }.minOrNull()
        } else {
            null
        }

        val minRequiredMinutesForPlan = if (
            newFilter.multiStopEnabled &&
            origin != null &&
            filtered.isNotEmpty()
        ) {
            estimateMinRequiredMinutes(
                filter = newFilter,
                candidates = filtered,
                origin = origin,
                mode = mode
            )
        } else {
            null
        }

        val exactMatchesCount = if (newFilter.multiStopEnabled) {
            0
        } else {
            filtered.size
        }

        val alternativesResult = alternativesEngine.build(
            filter = newFilter,
            exactMatchesCount = exactMatchesCount,
            itinerariesCount = itineraries.size,
            cheapestSingleOptionTotal = cheapestSingleOptionTotal,
            shortestTravelMinutes = shortestTravelMinutes,
            minRequiredMinutesForPlan = minRequiredMinutesForPlan
        )

        _uiState.update {
            it.copy(
                filter = newFilter,
                filteredAll = filtered,
                events = if (resetPage) pageItems else it.events + pageItems,
                itineraries = itineraries,
                failureReasons = alternativesResult.failureReasons,
                suggestedAlternatives = alternativesResult.suggestedAlternatives,
                page = currentPage,
                totalCount = filtered.size,
                canLoadMore = to < filtered.size,
                isLoading = false,
                isRefreshing = false,
                errorMessage = null
            )
        }
    }

    private fun filterEvents(source: List<EventModel>, filter: FilterState): List<EventModel> {
        val qLower = filter.query.trim().lowercase()

        val hasBackendCats = filter.categories.isNotEmpty()
        val hasUiCats = filter.selectedCategoryIds.isNotEmpty()

        return source.asSequence()

            // A: текстовый поиск
            .filter { event ->
                if (qLower.isBlank()) {
                    true
                } else {
                    val hay = buildString {
                        append(event.title)
                        append(" ")
                        append(event.locationName)
                        append(" ")
                        append(event.category.toString())
                        append(" ")
                        append(event.tags.joinToString(" "))
                        append(" ")
                        append(event.shortDescription)
                    }.lowercase()
                    hay.contains(qLower)
                }
            }

            // C: категории
            .filter { event ->
                when {
                    hasBackendCats -> filter.categories.any { it.name == event.category }
                    hasUiCats -> filter.selectedCategoryIds.contains(event.category)
                    else -> true
                }
            }

            // C: сабкатегории
            .filter { true }

            // onlyFree
            .filter { event ->
                if (!filter.onlyFree) {
                    true
                } else {
                    event.isFree || (event.price != null && event.price == 0.0)
                }
            }

            // цена min/max
            .filter { event ->
                val minP = filter.minPrice
                val maxP = filter.maxPrice

                if (minP == null && maxP == null) {
                    true
                } else {
                    val price = event.price ?: 0.0
                    val okMin = minP?.let { price >= it } ?: true
                    val okMax = maxP?.let { price <= it } ?: true
                    okMin && okMax
                }
            }

            // люди min/max
            .filter { event ->
                val minPeople = filter.minPeople
                val maxPeople = filter.maxPeople
                val capacity = event.maxParticipants

                val okMin = minPeople?.let { capacity?.let { cap -> cap >= it } ?: true } ?: true
                val okMax = maxPeople?.let { capacity?.let { cap -> cap <= it } ?: true } ?: true
                okMin && okMax
            }

            // favorites
            .filter { event ->
                if (!filter.onlyFavorites) true else event.isFavorite
            }

            // дата
            .filter { event ->
                val from = filter.dateFromMillis
                val to = filter.dateToMillis
                val t = event.dateTimeMillis

                val okFrom = from?.let { t >= it } ?: true
                val okTo = to?.let { t <= it } ?: true
                okFrom && okTo
            }

            // B: радиус
            .filter { event ->
                val cLat = filter.centerLat
                val cLng = filter.centerLng
                val r = filter.radiusMeters

                if (cLat == null || cLng == null || r == null) {
                    true
                } else {
                    val eLat = event.latitude
                    val eLng = event.longitude

                    if (eLat == null || eLng == null) {
                        false
                    } else {
                        distanceMeters(cLat, cLng, eLat, eLng) <= r.toFloat()
                    }
                }
            }

            .toList()
    }

    private fun distanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Float {
        val out = FloatArray(1)
        Location.distanceBetween(lat1, lng1, lat2, lng2, out)
        return out[0]
    }

    private suspend fun buildItinerariesIfNeeded(
        filter: FilterState,
        candidates: List<EventModel>,
        origin: GeoPoint
    ): List<Itinerary> {
        if (!filter.multiStopEnabled) return emptyList()

        val free = filter.freeTimeMinutes ?: return emptyList()
        val budgetTotal =
            (filter.maxPrice ?: filter.budgetMaxInput?.toDouble()) ?: return emptyList()

        val people = filter.peopleCount.coerceAtLeast(1)
        val maxStops = filter.maxStops.coerceIn(2, 4)

        val candidateStops = candidates.mapNotNull { e ->
            val lat = e.latitude ?: return@mapNotNull null
            val lng = e.longitude ?: return@mapNotNull null

            val duration = defaultDurationByCategory(e.category)
            val cost = computeTotalCostForPeople(e, people)

            CandidateStop(
                eventId = e.id,
                title = e.title,
                point = GeoPoint(lat, lng),
                durationMinutes = duration,
                costTotal = cost
            )
        }

        val mode = when (filter.travelMode.uppercase()) {
            "TRANSIT" -> TravelMode.TRANSIT
            "WALK" -> TravelMode.WALK
            "BIKE" -> TravelMode.BIKE
            else -> TravelMode.DRIVE
        }

        val req = MultiStopRequest(
            origin = origin,
            freeTimeMinutes = free,
            budgetTotal = budgetTotal,
            mode = mode,
            includeReturnTrip = filter.includeReturnTrip,
            maxStops = maxStops
        )

        return planner.plan(req, candidateStops)
    }
}