package com.example.rechargenew.ui.map

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun RadiusPickerPanel(
    currentPreviewMeters: Int?,
    onPreviewKm: (Int) -> Unit,
    onPreviewUnlimited: () -> Unit,
    onApply: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val unlimited = currentPreviewMeters == null
    var sliderKm by remember(currentPreviewMeters) {
        mutableFloatStateOf(((currentPreviewMeters ?: 5000) / 1000f).coerceIn(1f, 50f))
    }

    Surface(
        tonalElevation = 2.dp,
        shape = MaterialTheme.shapes.extraLarge,
        modifier = modifier
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Радиус", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onClose) { Text("Закрыть") }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Без ограничения", style = MaterialTheme.typography.bodyMedium)
                Switch(
                    checked = unlimited,
                    onCheckedChange = { checked ->
                        if (checked) onPreviewUnlimited()
                        else onPreviewKm(sliderKm.roundToInt().coerceIn(1, 50))
                    }
                )
            }

            Spacer(Modifier.height(10.dp))

            if (!unlimited) {
                Text("Выбрано: ${sliderKm.roundToInt()} км", style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = sliderKm,
                    onValueChange = {
                        sliderKm = it
                        onPreviewKm(it.roundToInt().coerceIn(1, 50))
                    },
                    valueRange = 1f..50f
                )

                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 3, 5, 10, 25).forEach { km ->
                        AssistChip(
                            onClick = {
                                sliderKm = km.toFloat()
                                onPreviewKm(km)
                            },
                            label = { Text("$km") }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Button(
                onClick = onApply,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Применить")
            }
        }
    }
}
