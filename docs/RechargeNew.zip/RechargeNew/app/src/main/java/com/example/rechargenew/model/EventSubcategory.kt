package com.example.rechargenew.model

/**
 * Полный глобальный список подкатегорий Recharge.
 *
 * parent = EventCategory — принадлежность к основной категории.
 */

enum class EventSubcategory(val parent: EventCategory) {

    // ==========================
    // MUSIC
    // ==========================
    MUSIC_CONCERTS(EventCategory.MUSIC),
    MUSIC_FESTIVALS(EventCategory.MUSIC),
    MUSIC_OPEN_AIR(EventCategory.MUSIC),
    MUSIC_DJ_SETS(EventCategory.MUSIC),
    MUSIC_LIVE_BANDS(EventCategory.MUSIC),
    MUSIC_JAZZ(EventCategory.MUSIC),
    MUSIC_ROCK(EventCategory.MUSIC),
    MUSIC_METAL(EventCategory.MUSIC),
    MUSIC_CLASSICAL(EventCategory.MUSIC),
    MUSIC_OPERA(EventCategory.MUSIC),
    MUSIC_INSTRUMENTAL(EventCategory.MUSIC),
    MUSIC_RNB(EventCategory.MUSIC),
    MUSIC_KPOP(EventCategory.MUSIC),
    MUSIC_POP(EventCategory.MUSIC),
    MUSIC_ELECTRONIC(EventCategory.MUSIC),
    MUSIC_HOUSE(EventCategory.MUSIC),
    MUSIC_TECHNO(EventCategory.MUSIC),
    MUSIC_HIPHOP(EventCategory.MUSIC),


    // ==========================
    // NIGHTLIFE
    // ==========================
    NIGHTLIFE_CLUBS(EventCategory.NIGHTLIFE),
    NIGHTLIFE_BAR_PARTIES(EventCategory.NIGHTLIFE),
    NIGHTLIFE_LATIN(EventCategory.NIGHTLIFE),
    NIGHTLIFE_THEME_PARTIES(EventCategory.NIGHTLIFE),
    NIGHTLIFE_KARAOKE(EventCategory.NIGHTLIFE),
    NIGHTLIFE_AFTERPARTY(EventCategory.NIGHTLIFE),
    NIGHTLIFE_LOUNGE(EventCategory.NIGHTLIFE),
    NIGHTLIFE_HOOKAH(EventCategory.NIGHTLIFE),
    NIGHTLIFE_COCKTAIL(EventCategory.NIGHTLIFE),


    // ==========================
    // COMEDY
    // ==========================
    COMEDY_STANDUP(EventCategory.COMEDY),
    COMEDY_IMPROV(EventCategory.COMEDY),
    COMEDY_OPEN_MIC(EventCategory.COMEDY),
    COMEDY_COMEDY_SHOW(EventCategory.COMEDY),


    // ==========================
    // THEATRE & SHOWS
    // ==========================
    THEATRE_PLAYS(EventCategory.THEATRE_SHOWS),
    THEATRE_MUSICAL(EventCategory.THEATRE_SHOWS),
    THEATRE_CIRCUS(EventCategory.THEATRE_SHOWS),
    THEATRE_OPERA(EventCategory.THEATRE_SHOWS),
    THEATRE_MAGIC(EventCategory.THEATRE_SHOWS),
    THEATRE_EXPERIMENTAL(EventCategory.THEATRE_SHOWS),


    // ==========================
    // ART & CULTURE
    // ==========================
    ART_EXHIBITION(EventCategory.ART_CULTURE),
    ART_GALLERY(EventCategory.ART_CULTURE),
    ART_MUSEUM(EventCategory.ART_CULTURE),
    ART_MODERN(EventCategory.ART_CULTURE),
    ART_TOUR(EventCategory.ART_CULTURE),
    ART_PHOTO(EventCategory.ART_CULTURE),
    ART_ARCHITECTURE(EventCategory.ART_CULTURE),


    // ==========================
    // FILM & MEDIA
    // ==========================
    FILM_MOVIE(EventCategory.FILM_MEDIA),
    FILM_OUTDOOR(EventCategory.FILM_MEDIA),
    FILM_PREMIERE(EventCategory.FILM_MEDIA),
    FILM_DOCUMENTARY(EventCategory.FILM_MEDIA),
    FILM_SHORTS(EventCategory.FILM_MEDIA),
    FILM_FESTIVAL(EventCategory.FILM_MEDIA),


    // ==========================
    // SPORTS & FITNESS
    // ==========================
    SPORT_RUN(EventCategory.SPORTS_FITNESS),
    SPORT_YOGA(EventCategory.SPORTS_FITNESS),
    SPORT_GYM(EventCategory.SPORTS_FITNESS),
    SPORT_CALISTHENICS(EventCategory.SPORTS_FITNESS),
    SPORT_SWIMMING(EventCategory.SPORTS_FITNESS),
    SPORT_CYCLING(EventCategory.SPORTS_FITNESS),
    SPORT_BOXING(EventCategory.SPORTS_FITNESS),
    SPORT_MARTIAL(EventCategory.SPORTS_FITNESS),
    SPORT_FOOTBALL(EventCategory.SPORTS_FITNESS),
    SPORT_BASKETBALL(EventCategory.SPORTS_FITNESS),
    SPORT_VOLLEYBALL(EventCategory.SPORTS_FITNESS),
    SPORT_TENNIS(EventCategory.SPORTS_FITNESS),
    SPORT_CLIMBING(EventCategory.SPORTS_FITNESS),
    SPORT_DANCE(EventCategory.SPORTS_FITNESS),
    SPORT_STRETCHING(EventCategory.SPORTS_FITNESS),
    SPORT_PILATES(EventCategory.SPORTS_FITNESS),


    // ==========================
    // FOOD & DRINK
    // ==========================
    FOOD_RESTAURANT(EventCategory.FOOD_DRINK),
    FOOD_TASTING(EventCategory.FOOD_DRINK),
    FOOD_WINE(EventCategory.FOOD_DRINK),
    FOOD_BEER(EventCategory.FOOD_DRINK),
    FOOD_STREET_FOOD(EventCategory.FOOD_DRINK),
    FOOD_COOKING_CLASS(EventCategory.FOOD_DRINK),
    FOOD_BAR_CRAWL(EventCategory.FOOD_DRINK),
    FOOD_COFFEE(EventCategory.FOOD_DRINK),
    FOOD_BAKERY(EventCategory.FOOD_DRINK),


    // ==========================
    // GAMES & ENTERTAINMENT
    // ==========================
    GAMES_BOARD(EventCategory.GAMES_ENTERTAINMENT),
    GAMES_QUIZ(EventCategory.GAMES_ENTERTAINMENT),
    GAMES_POKER(EventCategory.GAMES_ENTERTAINMENT),
    GAMES_MAFIA(EventCategory.GAMES_ENTERTAINMENT),
    GAMES_QUEST(EventCategory.GAMES_ENTERTAINMENT),
    GAMES_KARAOKE(EventCategory.GAMES_ENTERTAINMENT),
    GAMES_TRIVIA(EventCategory.GAMES_ENTERTAINMENT),
    GAMES_VR(EventCategory.GAMES_ENTERTAINMENT),
    GAMES_ESPORT(EventCategory.GAMES_ENTERTAINMENT),


    // ==========================
    // TRAVEL & OUTDOOR
    // ==========================
    OUTDOOR_WALK(EventCategory.TRAVEL_OUTDOOR),
    OUTDOOR_CITY_TOUR(EventCategory.TRAVEL_OUTDOOR),
    OUTDOOR_HIKE(EventCategory.TRAVEL_OUTDOOR),
    OUTDOOR_BIKE_TOUR(EventCategory.TRAVEL_OUTDOOR),
    OUTDOOR_PHOTO_WALK(EventCategory.TRAVEL_OUTDOOR),
    OUTDOOR_CAMP(EventCategory.TRAVEL_OUTDOOR),
    OUTDOOR_BOAT(EventCategory.TRAVEL_OUTDOOR),
    OUTDOOR_TRIP(EventCategory.TRAVEL_OUTDOOR),


    // ==========================
    // BUSINESS & NETWORKING
    // ==========================
    BUSINESS_MEETUP(EventCategory.BUSINESS_NETWORKING),
    BUSINESS_TALK(EventCategory.BUSINESS_NETWORKING),
    BUSINESS_PITCH(EventCategory.BUSINESS_NETWORKING),
    BUSINESS_STARTUP(EventCategory.BUSINESS_NETWORKING),
    BUSINESS_INVEST(EventCategory.BUSINESS_NETWORKING),


    // ==========================
    // SCIENCE & TECH
    // ==========================
    TECH_CONFERENCE(EventCategory.SCIENCE_TECH),
    TECH_HACKATHON(EventCategory.SCIENCE_TECH),
    TECH_MEETUP(EventCategory.SCIENCE_TECH),
    TECH_ROBOTICS(EventCategory.SCIENCE_TECH),
    TECH_AI(EventCategory.SCIENCE_TECH),
    TECH_PROGRAMMING(EventCategory.SCIENCE_TECH),
    TECH_GADGETS(EventCategory.SCIENCE_TECH),


    // ==========================
    // WORKSHOPS & CLASSES
    // ==========================
    CLASS_ART(EventCategory.WORKSHOPS_CLASSES),
    CLASS_PHOTO(EventCategory.WORKSHOPS_CLASSES),
    CLASS_PAINTING(EventCategory.WORKSHOPS_CLASSES),
    CLASS_CERAMICS(EventCategory.WORKSHOPS_CLASSES),
    CLASS_DANCE(EventCategory.WORKSHOPS_CLASSES),
    CLASS_LANGUAGE(EventCategory.WORKSHOPS_CLASSES),
    CLASS_TECH(EventCategory.WORKSHOPS_CLASSES),
    CLASS_FINANCE(EventCategory.WORKSHOPS_CLASSES),
    CLASS_BUSINESS(EventCategory.WORKSHOPS_CLASSES),
    CLASS_MUSIC(EventCategory.WORKSHOPS_CLASSES),


    // ==========================
    // COMMUNITY & CHARITY
    // ==========================
    COMMUNITY_MEETUP(EventCategory.COMMUNITY_CHARITY),
    COMMUNITY_TALK(EventCategory.COMMUNITY_CHARITY),
    COMMUNITY_VOLUNTEER(EventCategory.COMMUNITY_CHARITY),
    COMMUNITY_CLEANUP(EventCategory.COMMUNITY_CHARITY),
    COMMUNITY_SOCIAL(EventCategory.COMMUNITY_CHARITY),


    // ==========================
    // MIND & WELLNESS
    // ==========================
    WELLNESS_MEDITATION(EventCategory.SPIRIT_WELLNESS),
    WELLNESS_BREATHWORK(EventCategory.SPIRIT_WELLNESS),
    WELLNESS_SPA(EventCategory.SPIRIT_WELLNESS),
    WELLNESS_SOUND_HEALING(EventCategory.SPIRIT_WELLNESS),
    WELLNESS_RELAX(EventCategory.SPIRIT_WELLNESS),
    WELLNESS_THERAPY(EventCategory.SPIRIT_WELLNESS),


    // ==========================
    // FAMILY & KIDS
    // ==========================
    KIDS_SHOW(EventCategory.FAMILY_KIDS),
    KIDS_WORKSHOP(EventCategory.FAMILY_KIDS),
    KIDS_PLAYGROUND(EventCategory.FAMILY_KIDS),
    KIDS_EDUCATION(EventCategory.FAMILY_KIDS),
    KIDS_ENTERTAINMENT(EventCategory.FAMILY_KIDS),


    // ==========================
    // FASHION & BEAUTY
    // ==========================
    BEAUTY_MAKEUP(EventCategory.FASHION_BEAUTY),
    BEAUTY_STYLE(EventCategory.FASHION_BEAUTY),
    BEAUTY_HAIRCUT(EventCategory.FASHION_BEAUTY),
    BEAUTY_PHOTO(EventCategory.FASHION_BEAUTY),


    // ==========================
    // HEALTH & LIFESTYLE
    // ==========================
    LIFESTYLE_HABITS(EventCategory.HEALTH_LIFESTYLE),
    LIFESTYLE_SLEEP(EventCategory.HEALTH_LIFESTYLE),
    LIFESTYLE_DIET(EventCategory.HEALTH_LIFESTYLE),
    LIFESTYLE_BIOHACK(EventCategory.HEALTH_LIFESTYLE),


    // ==========================
    // PETS & ANIMALS
    // ==========================
    PETS_DOG_MEETUP(EventCategory.PETS_ANIMALS),
    PETS_CAT_MEETUP(EventCategory.PETS_ANIMALS),
    PETS_ADOPTION(EventCategory.PETS_ANIMALS),
    PETS_TRAINING(EventCategory.PETS_ANIMALS),


    // ==========================
    // FAITH & RELIGION
    // ==========================
    FAITH_MASS(EventCategory.FAITH_RELIGION),
    FAITH_MEETING(EventCategory.FAITH_RELIGION),
    FAITH_STUDY(EventCategory.FAITH_RELIGION),


    // ==========================
    // GOVERNMENT & POLITICS
    // ==========================
    POLITICS_TALK(EventCategory.GOV_POLITICS),
    POLITICS_MEETING(EventCategory.GOV_POLITICS),
    POLITICS_DISCUSSION(EventCategory.GOV_POLITICS),


    // ==========================
    // HOLIDAY & SEASONAL
    // ==========================
    HOLIDAY_CHRISTMAS(EventCategory.HOLIDAY_SEASONAL),
    HOLIDAY_HALLOWEEN(EventCategory.HOLIDAY_SEASONAL),
    HOLIDAY_NEWYEAR(EventCategory.HOLIDAY_SEASONAL),
    HOLIDAY_EASTER(EventCategory.HOLIDAY_SEASONAL),
    HOLIDAY_VALENTINE(EventCategory.HOLIDAY_SEASONAL),


    // ==========================
    // LITERATURE
    // ==========================
    LIT_BOOK_CLUB(EventCategory.LITERATURE),
    LIT_AUTHOR(EventCategory.LITERATURE),
    LIT_POETRY(EventCategory.LITERATURE),
    LIT_READING(EventCategory.LITERATURE),


    // ==========================
    // AUTO & MOTO
    // ==========================
    AUTO_MEET(EventCategory.AUTO_MOTO),
    AUTO_EXPO(EventCategory.AUTO_MOTO),
    AUTO_RACE(EventCategory.AUTO_MOTO),
    MOTO_RIDE(EventCategory.AUTO_MOTO),


    // ==========================
    // HOME & HOBBY
    // ==========================
    HOBBY_HANDMADE(EventCategory.HOME_HOBBY),
    HOBBY_GARDEN(EventCategory.HOME_HOBBY),
    HOBBY_INTERIOR(EventCategory.HOME_HOBBY),
    HOBBY_COLLECTING(EventCategory.HOME_HOBBY),


    // ==========================
    // ADULT (18+)
    // ==========================
    ADULT_PARTY(EventCategory.ADULT_18_PLUS),
    ADULT_EXPO(EventCategory.ADULT_18_PLUS),
    ADULT_SHOW(EventCategory.ADULT_18_PLUS),
}
