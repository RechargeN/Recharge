package com.example.rechargenew.domain.explore.capabilities

/**
 * Единый ответ: что пользователь может делать на данной странице (entity).
 */
data class EntityPageCapabilities(
    val canCreateEvent: Boolean = false,
    val canCreatePlace: Boolean = false,
    val canEditEntity: Boolean = false,

    val canManageEvents: Boolean = false,
    val canManageLocation: Boolean = false,

    val canComment: Boolean = true,
    val canRateEvents: Boolean = true,

    // “показать апгрейд”
    val canRequestUpgrade: Boolean = false
)
