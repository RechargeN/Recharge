package com.example.rechargenew.data.explore

import com.example.rechargenew.data.explore.links.LinkRepository
import com.example.rechargenew.data.explore.roles.InMemoryRoleRepository
import com.example.rechargenew.data.explore.roles.RoleRepository
import com.example.rechargenew.data.explore.session.DefaultSessionRepository
import com.example.rechargenew.data.explore.session.SessionRepository
import com.example.rechargenew.domain.explore.model.UserRole
import com.example.rechargenew.data.explore.entities.InMemoryMyEntitiesRepository
import com.example.rechargenew.data.explore.entities.MyEntitiesRepository
import com.example.rechargenew.data.explore.entities.InMemoryHostRepository
import com.example.rechargenew.data.explore.entities.InMemoryLocationRepository
import com.example.rechargenew.data.explore.entities.InMemoryPlaceRepository

// ... остальное как у тебя уже есть


object ExploreDI {

    // роли по умолчанию
    private val roleRepo: RoleRepository = InMemoryRoleRepository(
        initial = setOf(
            UserRole.USER,
            UserRole.CONTRIBUTOR,
            UserRole.CREATOR,
            UserRole.VENUE_OWNER
        )
    )
    val myEntities: MyEntitiesRepository = InMemoryMyEntitiesRepository()
    val roles: RoleRepository = roleRepo
    val session: SessionRepository = DefaultSessionRepository(roleRepo, userId = "user_me")
    val links: LinkRepository = LinkRepository()
    val hostRepo = InMemoryHostRepository()
    val locationRepo = InMemoryLocationRepository()
    val placeRepo = InMemoryPlaceRepository()
}
