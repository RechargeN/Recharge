package com.example.rechargenew.ui.features.explore.entity.blocks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rechargenew.ui.features.explore.entity.model.EntityTabUi

@Composable
fun TabsBlock(active: EntityTabUi, onSelect: (EntityTabUi) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(
            selected = active == EntityTabUi.UPCOMING,
            onClick = { onSelect(EntityTabUi.UPCOMING) },
            label = { Text("Upcoming") }
        )
        FilterChip(
            selected = active == EntityTabUi.PAST,
            onClick = { onSelect(EntityTabUi.PAST) },
            label = { Text("Past") }
        )
        FilterChip(
            selected = active == EntityTabUi.PHOTOS,
            onClick = { onSelect(EntityTabUi.PHOTOS) },
            label = { Text("Photos") }
        )
    }
}
