package com.example.rechargenew.ui.features.explore.entity.variants

import com.example.rechargenew.domain.explore.model.UserRole
import com.example.rechargenew.ui.features.explore.entity.ExploreEntityUiState
import com.example.rechargenew.ui.features.explore.entity.model.EntityActionUi

class UserPageComposer : EntityPageComposer {

    override fun compose(
        state: ExploreEntityUiState,
        roles: Set<UserRole>
    ): ExploreEntityUiState {
        val isContributor = UserRole.CONTRIBUTOR in roles
        val isCreator = UserRole.CREATOR in roles
        val isVenueOwner = UserRole.VENUE_OWNER in roles

        val hasExtraRoles = isContributor || isCreator || isVenueOwner

        val composedHeader = state.header.copy(
            title = state.header.title.ifBlank { "Unknown user" },
            subtitle = state.header.subtitle.ifBlank { "Explorer" },
            badges = buildBadges(
                isContributor = isContributor,
                isCreator = isCreator,
                isVenueOwner = isVenueOwner
            )
        )

        val composedActions = buildList {
            if (!hasExtraRoles) {
                add(
                    EntityActionUi(
                        id = "upgrade_profile",
                        title = "Upgrade profile",
                        kind = EntityActionUi.Kind.PRIMARY
                    )
                )
            } else {
                add(
                    EntityActionUi(
                        id = "my_pages",
                        title = "My pages",
                        kind = EntityActionUi.Kind.PRIMARY
                    )
                )

                if (isContributor) {
                    add(
                        EntityActionUi(
                            id = "add_place",
                            title = "Add place"
                        )
                    )
                }

                if (isCreator) {
                    add(
                        EntityActionUi(
                            id = "create_event",
                            title = "Create event"
                        )
                    )
                }

                if (isVenueOwner) {
                    add(
                        EntityActionUi(
                            id = "manage_venue",
                            title = "Manage venue"
                        )
                    )
                }
            }
        }

        val composedAbout = state.about.ifBlank {
            when {
                isCreator -> "Creates local events"
                isContributor -> "Creates public places (parks, walks)"
                isVenueOwner -> "Manages a venue page"
                else -> ""
            }
        }

        return state.copy(
            header = composedHeader,
            actions = composedActions,
            about = composedAbout
        )
    }

    private fun buildBadges(
        isContributor: Boolean,
        isCreator: Boolean,
        isVenueOwner: Boolean
    ): List<String> {
        return buildList {
            add("User")
            if (isContributor) add("Contributor")
            if (isCreator) add("Creator")
            if (isVenueOwner) add("Venue owner")
        }
    }
}