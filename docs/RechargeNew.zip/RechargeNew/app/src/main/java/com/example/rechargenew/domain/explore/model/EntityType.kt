package com.example.rechargenew.domain.explore.model

enum class EntityType {
    USER, PLACE, HOST, LOCATION;

    companion object {
        fun from(raw: String): EntityType = when (raw.trim().lowercase()) {
            "user" -> USER
            "place" -> PLACE
            "host" -> HOST
            "location" -> LOCATION
            else -> USER
        }
    }
}
