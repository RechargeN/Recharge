package com.example.rechargenew.ui.features.explore.upgrade

import com.example.rechargenew.domain.explore.model.UserRole
import com.example.rechargenew.ui.features.explore.upgrade.model.UpgradeRoleUi

data class UpgradeUiState(
    val roles: List<UpgradeRoleUi> = UpgradeRoleUi.default(),
    val isUpgrading: Boolean = false,
    val upgradedRole: UserRole? = null,
    val error: String? = null
)
