package com.example.rechargenew.ui.events.create

import android.location.Geocoder
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import com.google.android.gms.maps.CameraUpdateFactory
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.rechargenew.data.events.EventLocation
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@Composable
fun LocationSection(
    location: EventLocation?,
    onLocationChanged: (EventLocation) -> Unit,
    onUseCurrentLocationClick: () -> Unit,
    error: String?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // --- 1. Базовая точка ---
    val defaultLatLng = LatLng(52.3702, 4.8952) // Amsterdam

    var markerPosition by remember(location?.latitude, location?.longitude) {
        mutableStateOf(
            if (location?.latitude != null && location.longitude != null) {
                LatLng(location.latitude, location.longitude)
            } else {
                defaultLatLng
            }
        )
    }

    // ✅ markerState создаём ОДИН раз
    val markerState = rememberMarkerState(position = markerPosition)

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(markerPosition, 13f)
    }

    // жесты карты — ВКЛЮЧЕНЫ
    val mapUiSettings = remember {
        MapUiSettings(
            zoomControlsEnabled = false,
            zoomGesturesEnabled = true,
            scrollGesturesEnabled = true,
            rotationGesturesEnabled = false,
            tiltGesturesEnabled = false
        )
    }

    // --- 2. Поиск + автоподсказки ---
    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<SearchSuggestion>>(emptyList()) }
    var isSearching by remember { mutableStateOf(false) }
    var searchStatus by remember { mutableStateOf<String?>(null) }

    // --- 3. Ручной адрес и авто-город ---
    var addressText by remember(location?.address) {
        mutableStateOf(location?.address.orEmpty())
    }
    var cityText by remember { mutableStateOf("") }

    // ✅ Синхронизируем markerState с markerPosition (когда позиция меняется из поиска/клика)
    LaunchedEffect(markerPosition) {
        if (markerState.position != markerPosition) {
            markerState.position = markerPosition
        }
    }

    // ✅ Когда пользователь перетащил маркер — обновляем состояние + адрес
    LaunchedEffect(markerState.position) {
        val latLng = markerState.position
        if (markerPosition != latLng) {
            markerPosition = latLng
        }

        // адрес по координатам
        scope.launch {
            val geocoder = Geocoder(context, Locale.getDefault())
            val addr = withContext(Dispatchers.IO) {
                try {
                    geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
                        ?.firstOrNull()
                } catch (_: Exception) {
                    null
                }
            }

            val line = addr?.getAddressLine(0) ?: addressText
            val city = addr?.locality ?: addr?.subAdminArea ?: cityText

            addressText = line
            cityText = city

            onLocationChanged(
                EventLocation(
                    address = line,
                    latitude = latLng.latitude,
                    longitude = latLng.longitude
                )
            )
        }
    }

    Column(modifier = Modifier.fillMaxWidth()) {

        Text(text = "Location", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        // ----- ПОИСК ПО АДРЕСУ -----
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Search by address") },
            textStyle = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(4.dp))

        // 🔥 Автопоиск без кнопки
        LaunchedEffect(searchQuery) {
            val q = searchQuery.trim()

            if (q.length < 3) {
                searchResults = emptyList()
                searchStatus = null
                return@LaunchedEffect
            }

            isSearching = true
            searchStatus = null

            delay(600)

            if (q != searchQuery.trim()) {
                isSearching = false
                return@LaunchedEffect
            }

            val geocoder = Geocoder(context, Locale.getDefault())
            val list = withContext(Dispatchers.IO) {
                try {
                    geocoder.getFromLocationName(q, 5)
                } catch (_: Exception) {
                    null
                }
            }
            isSearching = false

            val suggestions = list
                ?.filterNotNull()
                ?.map {
                    SearchSuggestion(
                        title = it.getAddressLine(0) ?: q,
                        city = it.locality ?: it.subAdminArea ?: "",
                        latLng = LatLng(it.latitude, it.longitude)
                    )
                }
                .orEmpty()

            searchResults = suggestions

            searchStatus = when {
                list == null -> "Поиск недоступен на этом устройстве (Geocoder)."
                suggestions.isEmpty() -> "Ничего не найдено по запросу."
                else -> null
            }

            // ✅ авто-прыжок к первому результату
            if (suggestions.isNotEmpty()) {
                val first = suggestions.first()
                markerPosition = first.latLng
                markerState.position = first.latLng

                cameraPositionState.position =
                    CameraPosition.fromLatLngZoom(first.latLng, 14f)

                addressText = first.title
                cityText = first.city

                onLocationChanged(
                    EventLocation(
                        address = first.title,
                        latitude = first.latLng.latitude,
                        longitude = first.latLng.longitude
                    )
                )
            }
        }

        // список подсказок (максимум 5)
        searchResults.take(5).forEach { suggestion ->
            Text(
                text = suggestion.title,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable {
                        markerPosition = suggestion.latLng
                        markerState.position = suggestion.latLng

                        cameraPositionState.position =
                            CameraPosition.fromLatLngZoom(suggestion.latLng, 14f)

                        addressText = suggestion.title
                        cityText = suggestion.city

                        onLocationChanged(
                            EventLocation(
                                address = suggestion.title,
                                latitude = suggestion.latLng.latitude,
                                longitude = suggestion.latLng.longitude
                            )
                        )

                        searchResults = emptyList()
                        searchQuery = suggestion.title
                    }
            )
        }

        Spacer(Modifier.height(8.dp))

        // ----- КАРТА -----
        GoogleMap(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp),
            cameraPositionState = cameraPositionState,
            uiSettings = mapUiSettings,
            onMapClick = { latLng ->
                markerPosition = latLng
                markerState.position = latLng

                cameraPositionState.position =
                    CameraPosition.fromLatLngZoom(
                        latLng,
                        cameraPositionState.position.zoom
                    )

                scope.launch {
                    val geocoder = Geocoder(context, Locale.getDefault())
                    val addr = withContext(Dispatchers.IO) {
                        try {
                            geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
                                ?.firstOrNull()
                        } catch (_: Exception) {
                            null
                        }
                    }

                    val line = addr?.getAddressLine(0) ?: addressText
                    val city = addr?.locality ?: addr?.subAdminArea ?: cityText

                    addressText = line
                    cityText = city

                    onLocationChanged(
                        EventLocation(
                            address = line,
                            latitude = latLng.latitude,
                            longitude = latLng.longitude
                        )
                    )
                }
            }
        ) {
            Marker(
                state = markerState,
                title = "Event location",
                draggable = true
            )
        }

        Spacer(Modifier.height(8.dp))

        // ----- РУЧНОЙ АДРЕС -----
        OutlinedTextField(
            value = addressText,
            onValueChange = { newText ->
                addressText = newText
                val lat = markerPosition.latitude
                val lng = markerPosition.longitude
                onLocationChanged(
                    EventLocation(
                        address = newText.ifBlank { null },
                        latitude = lat,
                        longitude = lng
                    )
                )
            },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Address (you can edit)") },
            textStyle = MaterialTheme.typography.bodySmall,
            maxLines = 3
        )

        Spacer(Modifier.height(8.dp))

        // ----- КАРТОЧКА ВЫБРАННОГО МЕСТА -----
        val hasCoords = (markerPosition != defaultLatLng) || addressText.isNotBlank()

        if (hasCoords) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        text = "Selected location",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (addressText.isNotBlank()) {
                        Text(
                            text = addressText,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (cityText.isNotBlank()) {
                        Text(
                            text = "City: $cityText",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Text(
                        text = "Lat: %.5f, Lng: %.5f".format(
                            markerPosition.latitude,
                            markerPosition.longitude
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            Text(
                text = "Tap on the map or use search to choose a place.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (error != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = error,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private data class SearchSuggestion(
    val title: String,
    val city: String,
    val latLng: LatLng
)
