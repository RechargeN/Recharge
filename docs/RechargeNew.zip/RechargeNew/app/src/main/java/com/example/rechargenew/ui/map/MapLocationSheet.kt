package com.example.rechargenew.ui.map

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import android.location.Geocoder
import androidx.compose.ui.platform.LocalContext
import android.os.Build
import java.util.Locale


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapLocationSheet(
    onLocationResolved: (Double, Double) -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }

    Column(Modifier.padding(16.dp)) {5
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Город или адрес") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                val geocoder = Geocoder(context)
                val result = geocoder.getFromLocationName(query, 1)
                val location = result?.firstOrNull()
                if (location != null) {
                    onLocationResolved(location.latitude, location.longitude)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Показать на карте")
        }
    }
}


@Composable
private fun LocationRadioRow(
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title)
        RadioButton(selected = selected, onClick = onClick)
    }
}
