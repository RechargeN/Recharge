package com.example.rechargenew.ui.events

import com.example.rechargenew.model.EventCategory

/**
 * Фильтрация D по выбору в блоке C.
 *
 * selectedSubcategoryIds – множество id подкатегорий из subcategories.json
 * (например "music_concerts"). Эти id должны лежать в EventModel.tags.
 */
fun filterEventsByCategoryAndSubcategory(
    allEvents: List<EventModel>,
    selectedCategories: Set<EventCategory>,
    selectedSubcategoryIds: Set<String>
): List<EventModel> {

    val selectedCategoryNames = selectedCategories
        .map { it.name.uppercase() }
        .toSet()

    val selectedSubsUpper = selectedSubcategoryIds
        .map { it.uppercase() }
        .toSet()

    return allEvents.filter { event ->
        val eventCategory = event.category.uppercase()
        val tagsUpper = event.tags.map { it.uppercase() }.toSet()

        // Категории: хотя бы одна совпадает
        val matchCategory =
            if (selectedCategoryNames.isNotEmpty())
                eventCategory in selectedCategoryNames ||
                        tagsUpper.any { it in selectedCategoryNames }
            else
                true

        // Субкатегории: если выбраны – в тегах должна быть хотя бы одна
        val matchSub =
            if (selectedSubsUpper.isNotEmpty())
                tagsUpper.any { it in selectedSubsUpper }
            else
                true

        matchCategory && matchSub
    }
}
