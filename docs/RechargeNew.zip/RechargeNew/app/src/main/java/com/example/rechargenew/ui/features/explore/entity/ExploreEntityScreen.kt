package com.example.rechargenew.ui.features.explore.entity

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rechargenew.ui.features.explore.entity.model.EntityTypeUi
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rechargenew.ui.features.explore.entity.blocks.AboutBlock
import com.example.rechargenew.ui.features.explore.entity.blocks.ActionsBlock
import com.example.rechargenew.ui.features.explore.entity.blocks.EventsListBlock
import com.example.rechargenew.ui.features.explore.entity.blocks.HeaderBlock
import com.example.rechargenew.ui.features.explore.entity.blocks.PhotosGridBlock
import com.example.rechargenew.ui.features.explore.entity.blocks.TabsBlock
import com.example.rechargenew.ui.features.explore.entity.model.EntityTabUi

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreEntityScreen(
    entityType: String,
    entityId: String,
    onBack: () -> Unit,
    onOpenEvent: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenUpgrade: () -> Unit,
    onOpenMyEntities: () -> Unit,
    vm: ExploreEntityViewModel = viewModel()
) {
    val ui by vm.uiState.collectAsState()

    LaunchedEffect(entityType, entityId) {
        vm.load(entityType, entityId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Outlined.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding)
        ) {
            HeaderBlock(
                header = ui.header,
                showUpgradeRole = ui.entityType == EntityTypeUi.USER,
                onUpgradeRoleClick = onOpenUpgrade
            )

            ActionsBlock(
                actions = ui.actions,
                onAction = { action ->
                    when (action.id) {
                        "upgrade_profile" -> onOpenUpgrade()
                        "my_pages" -> onOpenMyEntities()
                        else -> vm.onIntent(
                            ExploreEntityIntent.OnActionClick(action.id)
                        )
                    }
                }
            )

            TabsBlock(
                active = ui.activeTab,
                onSelect = {
                    vm.onIntent(ExploreEntityIntent.SelectTab(it))
                }
            )

            Spacer(Modifier.height(10.dp))

            when (ui.activeTab) {
                EntityTabUi.UPCOMING -> EventsListBlock(
                    events = ui.upcomingEvents,
                    onOpenEvent = onOpenEvent,
                    emptyText = "No upcoming events"
                )

                EntityTabUi.PAST -> EventsListBlock(
                    events = ui.pastEvents,
                    onOpenEvent = onOpenEvent,
                    emptyText = "No past events"
                )

                EntityTabUi.PHOTOS -> PhotosGridBlock(
                    urls = ui.photoUrls,
                    emptyText = "No photos yet"
                )
            }

            AboutBlock(
                about = ui.about,
                tags = ui.tags
            )
        }
    }
}