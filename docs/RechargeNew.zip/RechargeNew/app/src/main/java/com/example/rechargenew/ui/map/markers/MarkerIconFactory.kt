package com.example.rechargenew.ui.map.markers

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import kotlin.math.roundToInt

object MarkerIconFactory {

    fun clusterIcon(count: Int, sizePx: Int = 96): BitmapDescriptor {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color(0xFF1E88E5).toArgb()
            style = Paint.Style.FILL
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color(0xFFFFFFFF).toArgb()
            style = Paint.Style.STROKE
            strokeWidth = (sizePx * 0.06f)
        }

        val r = sizePx / 2f
        canvas.drawCircle(r, r, r * 0.92f, fill)
        canvas.drawCircle(r, r, r * 0.92f, stroke)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color(0xFFFFFFFF).toArgb()
            textSize = sizePx * 0.40f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        val text = count.toString()
        val bounds = Rect()
        textPaint.getTextBounds(text, 0, text.length, bounds)
        val y = r + bounds.height() / 2f

        canvas.drawText(text, r, y, textPaint)

        return BitmapDescriptorFactory.fromBitmap(bmp)
    }

    // Заглушка под фото-маркер: маленький “кружок”
    fun photoPlaceholderIcon(sizePx: Int = 84): BitmapDescriptor {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color(0xFF2E7D32).toArgb()
            style = Paint.Style.FILL
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color(0xFFFFFFFF).toArgb()
            style = Paint.Style.STROKE
            strokeWidth = (sizePx * 0.06f)
        }

        val r = sizePx / 2f
        canvas.drawCircle(r, r, r * 0.92f, fill)
        canvas.drawCircle(r, r, r * 0.92f, stroke)

        return BitmapDescriptorFactory.fromBitmap(bmp)
    }
}
