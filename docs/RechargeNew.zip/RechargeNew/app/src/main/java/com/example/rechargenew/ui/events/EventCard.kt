package com.example.rechargenew.ui.events

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun EventCard(
    modifier: Modifier = Modifier,
    event: EventModel,
    onClick: (String) -> Unit,
    onToggleFavorite: (EventModel) -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick(event.id) },
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column {
            // Верхняя часть — фото (заглушка) + избранное
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(Color(0xFFE6F0EB)),
                contentAlignment = Alignment.TopEnd
            ) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0x14000000)
                                )
                            )
                        )
                )

                IconButton(
                    onClick = { onToggleFavorite(event) },
                    modifier = Modifier
                        .padding(10.dp)
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0x66000000))
                ) {
                    Icon(
                        imageVector = if (event.isFavorite)
                            Icons.Filled.Favorite
                        else
                            Icons.Filled.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = Color.White
                    )
                }
            }

            // Нижняя часть — текст и инфо
            Column(
                modifier = Modifier
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (event.shortDescription.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = event.shortDescription,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(Modifier.height(10.dp))

                InfoRow(
                    icon = null,
                    text = formatEventDateTime(event.dateTimeMillis)
                )
                InfoRow(
                    icon = Icons.Filled.LocationOn,
                    text = event.locationName
                )

                Spacer(Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PriceChip(event)
                    Spacer(Modifier.width(8.dp))
                    if (event.category.isNotBlank()) {
                        SimpleChip(label = event.category)
                    }
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = peopleText(event),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.weight(1f))
                    StatusBadge(event)
                }
            }
        }
    }
}

@Composable
private fun InfoRow(
    icon: ImageVector?,
    text: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 2.dp)
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(6.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun SimpleChip(label: String) {
    Surface(
        shape = RoundedCornerShape(50),
        border = ButtonDefaults.outlinedButtonBorder,
        color = Color.Transparent
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun PriceChip(event: EventModel) {
    val text = when {
        event.isFree -> "Free"
        event.price != null -> "${event.price} €"
        else -> "Price TBA"
    }
    SimpleChip(label = text)
}

@Composable
private fun StatusBadge(event: EventModel) {
    val (label, color) = when {
        event.isSoldOut -> "Sold out" to Color(0xFFB00020)
        event.isAlmostFull -> "Almost full" to MaterialTheme.colorScheme.primary
        else -> null to null
    }

    if (label != null && color != null) {
        Surface(
            color = color,
            shape = RoundedCornerShape(50)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(color = Color.White),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
    }
}

private fun formatEventDateTime(millis: Long): String {
    val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
    return sdf.format(Date(millis))
}

private fun peopleText(event: EventModel): String {
    return if (event.maxParticipants != null && event.currentParticipants != null) {
        "${event.currentParticipants} / ${event.maxParticipants} places"
    } else {
        "Places info"
    }
}
