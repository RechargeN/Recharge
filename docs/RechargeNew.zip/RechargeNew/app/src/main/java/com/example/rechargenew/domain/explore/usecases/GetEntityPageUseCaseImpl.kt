package com.example.rechargenew.domain.explore.usecases

import com.example.rechargenew.data.explore.entities.InMemoryHostRepository
import com.example.rechargenew.data.explore.entities.InMemoryLocationRepository
import com.example.rechargenew.data.explore.entities.InMemoryPlaceRepository
import com.example.rechargenew.data.explore.links.LinkRepository
import com.example.rechargenew.data.explore.session.SessionRepository
import com.example.rechargenew.domain.explore.capabilities.EntityCapabilitiesResolver
import com.example.rechargenew.domain.explore.model.EntityType
import kotlinx.coroutines.flow.first

class GetEntityPageUseCaseImpl(
    private val session: SessionRepository,
    private val linkRepository: LinkRepository,
    private val hostRepo: InMemoryHostRepository,
    private val locationRepo: InMemoryLocationRepository,
    private val placeRepo: InMemoryPlaceRepository
) : GetEntityPageUseCase {

    override suspend fun execute(input: EntityPageInput): ExploreResult<EntityPageDomain> {
        return try {
            val roles = session.rolesFlow.first()
            val access = linkRepository.getAccessLevel(session.userId, input.id.value)

            val capabilities = EntityCapabilitiesResolver.resolve(
                entityType = input.type,
                roles = roles,
                access = access
            )

            val (title, subtitle, about, tags) = when (input.type) {
                EntityType.USER -> {
                    val t = if (input.id.value == session.userId) "My profile" else "User"
                    Quad(t, "user", "Personal page. Activity and roles will be shown here.", emptyList())
                }
                EntityType.HOST -> {
                    hostRepo.seedIfMissing(input.id.value, "My creator page")
                    val e = hostRepo.getById(input.id.value)
                    Quad(
                        e?.title ?: "Creator",
                        "host",
                        e?.about ?: "",
                        e?.tags ?: emptyList()
                    )
                }
                EntityType.LOCATION -> {
                    locationRepo.seedIfMissing(input.id.value, "My venue")
                    val e = locationRepo.getById(input.id.value)
                    Quad(
                        e?.title ?: "Venue",
                        "location",
                        e?.about ?: "",
                        e?.tags ?: emptyList()
                    )
                }
                EntityType.PLACE -> {
                    placeRepo.seedIfMissing(input.id.value, "My public place")
                    val e = placeRepo.getById(input.id.value)
                    Quad(
                        e?.title ?: "Place",
                        "place",
                        e?.about ?: "",
                        e?.tags ?: emptyList()
                    )
                }
            }

            ExploreResult.Success(
                EntityPageDomain(
                    title = title,
                    subtitle = subtitle,
                    about = about,
                    tags = tags,
                    capabilities = capabilities
                )
            )
        } catch (e: Exception) {
            ExploreResult.Error(e.message ?: "Failed to load entity page", e)
        }
    }

    // маленький локальный хелпер, чтобы не тащить Pair/Triple
    private data class Quad(
        val title: String,
        val subtitle: String,
        val about: String,
        val tags: List<String>
    )
}
