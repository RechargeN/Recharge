package com.example.rechargenew.ui.features.explore.entity.blocks

import androidx.compose.runtime.Composable

@Composable
fun RoleBadgesBlock() {
    // позже: бейджи ролей пользователя
}
