package com.example.rechargenew.ui.features.explore.common

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun ErrorBlock(message: String) {
    Text(message)
}
