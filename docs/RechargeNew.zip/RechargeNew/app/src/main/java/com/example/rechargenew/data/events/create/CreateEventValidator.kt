package com.example.rechargenew.data.events.create

data class ValidationResult(
    val titleError: String? = null,
    val descriptionError: String? = null,
    val dateError: String? = null,
    val priceError: String? = null,
    val locationError: String? = null,
    val categoryError: String? = null
) {
    val isValid: Boolean
        get() = titleError == null &&
                descriptionError == null &&
                dateError == null &&
                priceError == null &&
                locationError == null &&
                categoryError == null
}

object CreateEventValidator {

    fun validate(draft: EventDraft): ValidationResult {
        val titleError = when {
            draft.title.isBlank() -> "Title is required"
            draft.title.length < 3 -> "Title is too short"
            else -> null
        }

        val descriptionError = when {
            draft.description.isBlank() -> "Description is required"
            draft.description.length < 10 -> "Description is too short"
            else -> null
        }

        val dateError = if (draft.dateTimeMillis == null) {
            "Date and time are required"
        } else null

        val priceError = if (draft.price != null && draft.price < 0.0) {
            "Price can't be negative"
        } else null

        val locationError =
            if (draft.location == null ||
                (draft.location.address.isNullOrBlank()
                        && draft.location.latitude == null
                        && draft.location.longitude == null)
            ) {
                "Location is required"
            } else null

        val categoryError =
            if (draft.categories.isEmpty()) {
                "Select at least one category"
            } else null

        return ValidationResult(
            titleError = titleError,
            descriptionError = descriptionError,
            dateError = dateError,
            priceError = priceError,
            locationError = locationError,
            categoryError = categoryError
        )
    }
}
