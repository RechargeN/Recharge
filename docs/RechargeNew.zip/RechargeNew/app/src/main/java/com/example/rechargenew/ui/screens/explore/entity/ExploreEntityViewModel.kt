package com.example.rechargenew.ui.screens.explore.entity

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.ui.events.EventModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class ExploreEntityViewModel : ViewModel() {

    fun state(entityType: String, entityId: String): StateFlow<ExploreEntityUiState> {
        val type = entityType.trim().lowercase()
        val id = entityId.trim()

        return EventRepository.events
            .map { all ->
                val now = System.currentTimeMillis()

                // Временная привязка событий к сущности:
                // - Location: match по locationName ИЛИ по tags
                // - Host/Place: match по tags
                val matched = all.filter { e -> matchesEntity(e, type, id) }

                val upcoming = matched
                    .filter { (it.dateTimeMillis ?: 0L) >= now }
                    .sortedBy { it.dateTimeMillis ?: Long.MAX_VALUE }

                val past = matched
                    .filter { (it.dateTimeMillis ?: 0L) < now }
                    .sortedByDescending { it.dateTimeMillis ?: 0L }

                val photos = matched
                    .mapNotNull { it.imageUrl.takeIf { url -> url.isNotBlank() } }
                    .distinct()
                    .take(24)

                ExploreEntityUiState(
                    header = ExploreEntityHeader(
                        title = id.ifBlank { "Entity" },
                        subtitle = when (type) {
                            "location" -> "Location"
                            "host" -> "Host"
                            "place" -> "Place"
                            else -> "Entity"
                        }
                    ),
                    upcoming = upcoming,
                    past = past,
                    photoUrls = photos,
                    about = defaultAbout(type),
                    tags = matched.flatMap { it.tags }.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(12)
                )
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ExploreEntityUiState())
    }

    private fun matchesEntity(e: EventModel, type: String, entityId: String): Boolean {
        val idLc = entityId.lowercase()
        val tagsLc = e.tags.map { it.lowercase() }
        val locLc = e.locationName.lowercase()

        return when (type) {
            "location" -> locLc.contains(idLc) || tagsLc.any { it.contains(idLc) }
            "host" -> tagsLc.any { it.contains(idLc) }
            "place" -> tagsLc.any { it.contains(idLc) }
            else -> false
        }
    }

    private fun defaultAbout(type: String): String = when (type) {
        "location" -> "Place where events happen. Check upcoming, past events and photos."
        "host" -> "Organizer profile. Events may happen in different locations."
        "place" -> "Walk spot / park. Explore history and photos."
        else -> ""
    }
}
