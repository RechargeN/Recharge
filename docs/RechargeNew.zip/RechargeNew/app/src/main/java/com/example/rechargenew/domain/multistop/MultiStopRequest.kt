package com.example.rechargenew.domain.multistop

data class MultiStopRequest(
    val origin: GeoPoint,
    val freeTimeMinutes: Int,
    val budgetTotal: Double,
    val mode: TravelMode,
    val includeReturnTrip: Boolean,
    val maxStops: Int,
    val nearOverflowMinutes: Int = 15,
    val maxPlans: Int = 15,
    val maxCandidates: Int = 60
)