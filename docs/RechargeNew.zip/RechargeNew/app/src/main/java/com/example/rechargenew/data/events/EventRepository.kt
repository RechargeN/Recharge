package com.example.rechargenew.data.events

import android.content.Context
import com.example.rechargenew.ui.events.EventModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

object EventRepository {

    private val _events = MutableStateFlow<List<EventModel>>(emptyList())
    val events: StateFlow<List<EventModel>> = _events.asStateFlow()

    suspend fun init(context: Context) {
        EventStorage.init(context)
        loadFromStorage(context)
    }

    suspend fun loadFromStorage(context: Context) {
        val loaded = withContext(Dispatchers.IO) {
            EventStorage.loadUserEvents()
        }
        _events.value = loaded
    }

    fun getAllEvents(): List<EventModel> = _events.value

    fun getEventById(id: String): EventModel? =
        _events.value.firstOrNull { it.id == id }
    fun getFavoriteEvents(): List<EventModel> =
        _events.value.filter { it.isFavorite }

    suspend fun addEvent(context: Context, event: EventModel) {
        withContext(Dispatchers.IO) {
            EventStorage.appendUserEvent(event)
        }
        _events.value = listOf(event) + _events.value
    }

    suspend fun updateEvent(context: Context, event: EventModel) {
        val updatedList = _events.value.map { old ->
            if (old.id == event.id) event else old
        }

        withContext(Dispatchers.IO) {
            EventStorage.saveUserEvents(updatedList)
        }

        _events.value = updatedList
    }
}
