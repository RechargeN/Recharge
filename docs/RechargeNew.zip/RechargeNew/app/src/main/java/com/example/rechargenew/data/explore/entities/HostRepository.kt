package com.example.rechargenew.data.explore.entities

import com.example.rechargenew.data.explore.entities.model.HostEntity

interface HostRepository {
    suspend fun getById(id: String): HostEntity?
}
