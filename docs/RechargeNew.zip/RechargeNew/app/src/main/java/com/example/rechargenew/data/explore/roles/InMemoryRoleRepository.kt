package com.example.rechargenew.data.explore.roles

import com.example.rechargenew.domain.explore.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * MVP: хранение ролей в памяти. После перезапуска — сброс.
 * Позже заменим на DataStore/DB/Server.
 */
class InMemoryRoleRepository(
    initial: Set<UserRole> = setOf(UserRole.USER)
) : RoleRepository {

    private val _roles = MutableStateFlow(initial)
    override val rolesFlow: StateFlow<Set<UserRole>> = _roles.asStateFlow()

    override fun hasRole(role: UserRole): Boolean = _roles.value.contains(role)

    override suspend fun addRole(role: UserRole) {
        _roles.value = _roles.value + role
    }
}
