package com.example.rechargenew.ui.screens.explore.entity

import com.example.rechargenew.ui.events.EventModel

enum class ExploreEntityTab { UPCOMING, PAST, PHOTOS }

data class ExploreEntityHeader(
    val title: String = "",
    val subtitle: String = "",   // например: "Location • Amsterdam"
)

data class ExploreEntityUiState(
    val header: ExploreEntityHeader = ExploreEntityHeader(),
    val tab: ExploreEntityTab = ExploreEntityTab.UPCOMING,

    val upcoming: List<EventModel> = emptyList(),
    val past: List<EventModel> = emptyList(),
    val photoUrls: List<String> = emptyList(),

    val about: String = "",
    val tags: List<String> = emptyList()
)
