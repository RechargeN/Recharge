package com.example.rechargenew.domain.multistop

enum class AlternativeType {
    INCREASE_BUDGET,
    INCREASE_TRAVEL_TIME,
    REDUCE_STOPS,
    DISABLE_RETURN_TRIP,
    SHORTER_ACTIVITY,
    RELAX_CATEGORY
}

enum class FailureReasonType {
    BUDGET_TOO_LOW,
    TRAVEL_TIME_TOO_SHORT,
    FREE_TIME_TOO_SHORT,
    TOO_MANY_STOPS,
    CATEGORY_TOO_STRICT,
    PEOPLE_LIMIT_NOT_MATCHED,
    NO_MATCHES_FOUND
}

data class FailureReason(
    val type: FailureReasonType,
    val message: String
)

data class SuggestedAdjustment(
    val type: AlternativeType,
    val title: String,
    val description: String,
    val newBudgetTotal: Double? = null,
    val newMaxTravelTimeMinutes: Int? = null,
    val newMaxStops: Int? = null,
    val newIncludeReturnTrip: Boolean? = null,
    val relaxedCategoryId: String? = null
)

data class GuidedAlternativesResult(
    val originalRequestSupported: Boolean,
    val failureReasons: List<FailureReason> = emptyList(),
    val suggestedAlternatives: List<SuggestedAdjustment> = emptyList()
)