package com.example.rechargenew.data.events

import com.example.rechargenew.ui.events.EventModel
import kotlin.math.*

/**
 * Локальный мок-"сервер".
 * Работает по заранее сгенерированному списку событий.
 */
class LocalMockApi(
    initialEvents: List<EventModel>
) : EventApi {

    // теперь mutable, чтобы можно было добавлять новые события
    private val events: MutableList<EventModel> = initialEvents.toMutableList()

    override suspend fun getAllEvents(): List<EventModel> = events

    override suspend fun searchEvents(
        query: String?,
        category: String?,
        minPrice: Double?,
        maxPrice: Double?
    ): List<EventModel> {

        return events.filter { event ->

            val matchesQuery = query.isNullOrBlank() ||
                    event.title.contains(query!!, ignoreCase = true) ||
                    event.shortDescription.contains(query, ignoreCase = true) ||
                    event.locationName.contains(query, ignoreCase = true)

            val matchesCategory = category.isNullOrBlank() ||
                    event.category.equals(category, ignoreCase = true)

            val price = event.price ?: 0.0
            val matchesPrice =
                (minPrice == null || price >= minPrice) &&
                        (maxPrice == null || price <= maxPrice)

            matchesQuery && matchesCategory && matchesPrice
        }
    }

    override suspend fun getNearbyEvents(
        lat: Double,
        lon: Double,
        radiusKm: Double,
        category: String?
    ): List<EventModel> {

        fun distanceKm(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
            val R = 6371.0
            val dLat = Math.toRadians(bLat - aLat)
            val dLon = Math.toRadians(bLon - aLon)
            val aa = sin(dLat / 2).pow(2.0) +
                    cos(Math.toRadians(aLat)) *
                    cos(Math.toRadians(bLat)) *
                    sin(dLon / 2).pow(2.0)
            val c = 2 * atan2(sqrt(aa), sqrt(1 - aa))
            return R * c
        }

        return events.filter { event ->
            val dist = distanceKm(lat, lon, event.latitude ?: 0.0, event.longitude ?: 0.0)
            val matchesCategory = category.isNullOrBlank() ||
                    event.category.equals(category, ignoreCase = true)

            dist <= radiusKm && matchesCategory
        }
    }

    override suspend fun getEventById(id: String): EventModel? =
        events.find { it.id == id }

    /**
     * Организатор добавляет событие.
     */
    override suspend fun addEvent(event: EventModel) {
        events.add(event)
    }

}
