package com.example.rechargenew.domain.multistop

import kotlin.math.roundToInt
import com.example.rechargenew.domain.multistop.Itinerary



class MultiStopPlanner(
    private val travelTimeProvider: TravelTimeProvider
) {
    suspend fun plan(request: MultiStopRequest, candidatesInput: List<CandidateStop>): List<Itinerary> {
        val maxStops = request.maxStops.coerceIn(2, 4)

        val candidates = candidatesInput
            .filter { it.durationMinutes > 0 }
            .take(request.maxCandidates)

        if (candidates.size < 2) return emptyList()

        val results = ArrayList<Itinerary>(request.maxPlans * 2)

        for (k in 2..maxStops) {
            buildPlansK(k, request, candidates, results)
            if (results.count { it.status == ItineraryStatus.PRIMARY } >= request.maxPlans) break
        }

        return results
            .sortedWith(
                compareBy<Itinerary> { it.status != ItineraryStatus.PRIMARY }
                    .thenBy { it.totalMinutes }
                    .thenBy { it.totalCost }
            )
            .take(request.maxPlans)
    }

    private suspend fun buildPlansK(
        k: Int,
        request: MultiStopRequest,
        candidates: List<CandidateStop>,
        results: MutableList<Itinerary>
    ) {
        val current = ArrayList<CandidateStop>(k)
        val used = BooleanArray(candidates.size)

        suspend fun dfs(startIndex: Int) {
            if (results.size >= request.maxPlans * 3) return

            if (current.size == k) {
                val itin = evaluate(request, current)
                if (itin != null) results.add(itin)
                return
            }

            for (i in startIndex until candidates.size) {
                if (used[i]) continue
                used[i] = true
                current.add(candidates[i])

                val activityOnly = current.sumOf { it.durationMinutes }
                if (activityOnly <= request.freeTimeMinutes) {
                    dfs(i + 1)
                }

                current.removeAt(current.lastIndex)
                used[i] = false
            }
        }

        dfs(0)
    }

    private suspend fun evaluate(request: MultiStopRequest, stops: List<CandidateStop>): Itinerary? {
        val totalCost = stops.sumOf { it.costTotal }
        if (totalCost > request.budgetTotal) return null

        val activityMinutes = stops.sumOf { it.durationMinutes }

        var travelMinutes = 0
        var prev = request.origin
        for (s in stops) {
            travelMinutes += travelTimeProvider.minutesBetween(prev, s.point, request.mode)
            prev = s.point
        }
        if (request.includeReturnTrip) {
            travelMinutes += travelTimeProvider.minutesBetween(prev, request.origin, request.mode)
        }

        val bufferMinutes = computeBufferMinutes(travelMinutes)
        val totalMinutes = travelMinutes + activityMinutes + bufferMinutes
        val overflow = totalMinutes - request.freeTimeMinutes

        return when {
            overflow <= 0 -> Itinerary(
                stops = stops.map { it.toItineraryStop() },
                travelMinutesTotal = travelMinutes,
                activityMinutesTotal = activityMinutes,
                bufferMinutes = bufferMinutes,
                totalMinutes = totalMinutes,
                totalCost = totalCost,
                status = ItineraryStatus.PRIMARY
            )

            overflow in 1..request.nearOverflowMinutes -> Itinerary(
                stops = stops.map { it.toItineraryStop() },
                travelMinutesTotal = travelMinutes,
                activityMinutesTotal = activityMinutes,
                bufferMinutes = bufferMinutes,
                totalMinutes = totalMinutes,
                totalCost = totalCost,
                status = ItineraryStatus.NEAR,
                explanation = "Не укладывается по времени: нужно ещё +$overflow мин."
            )

            else -> null
        }
    }

    private fun computeBufferMinutes(travelMinutes: Int): Int {
        val byPercent = (travelMinutes * 0.15).roundToInt()
        return maxOf(10, byPercent)
    }

    private fun CandidateStop.toItineraryStop(): ItineraryStop =
        ItineraryStop(eventId, title, point, durationMinutes, costTotal)
}