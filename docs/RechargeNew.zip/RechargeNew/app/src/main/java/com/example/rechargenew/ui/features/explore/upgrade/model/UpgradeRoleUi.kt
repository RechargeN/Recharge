package com.example.rechargenew.ui.features.explore.upgrade.model

data class UpgradeRoleUi(
    val id: String,
    val title: String,
    val description: String
) {
    companion object {
        fun default(): List<UpgradeRoleUi> = listOf(
            UpgradeRoleUi("contributor", "Contributor", "Create public places (parks, walks, spots)."),
            UpgradeRoleUi("creator", "Creator", "Create local events (one-time or repeated)."),
            UpgradeRoleUi("venue_owner", "Venue owner", "Manage a venue where events happen.")
        )
    }
}
