package com.example.rechargenew.ui.screens.hub

import com.example.rechargenew.ui.screens.hub.HubEventCard
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.filters.FeedPresetType
import com.example.rechargenew.ui.events.EventCard
import com.example.rechargenew.ui.events.EventModel

@Composable
fun MainHubScreen(
    navController: NavHostController
) {
    val context = LocalContext.current

    val bgColor = Color(0xFF173f35)
    val cardColor = Color.White
    val textOnGreen = Color.White

    // ✅ главное: подписались на единый источник правды
    val allEvents by EventRepository.events.collectAsState()

    var selectedCategoryId by remember { mutableStateOf<String?>(null) }

    // ✅ главное: один раз подгружаем из storage в репозиторий
    LaunchedEffect(Unit) {
        EventRepository.loadFromStorage(context)
    }

    fun List<EventModel>.filterByCategory(categoryId: String?): List<EventModel> =
        if (categoryId == null) this else this.filter { it.category == categoryId }

    val nearlyEvents = remember(allEvents, selectedCategoryId) {
        allEvents.sortedBy { it.dateTimeMillis }.filterByCategory(selectedCategoryId)
    }
    val popularEvents = remember(allEvents, selectedCategoryId) {
        allEvents.sortedByDescending { it.currentParticipants ?: 0 }.filterByCategory(selectedCategoryId)
    }
    val forYouEvents = remember(allEvents, selectedCategoryId) {
        allEvents.let { list -> list.filter { it.isFavorite }.ifEmpty { list } }.filterByCategory(selectedCategoryId)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 20.dp)
        ) {

            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "RECHARGE",
                        color = textOnGreen,
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "VACATION  APP",
                        color = textOnGreen.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.labelMedium,
                        letterSpacing = 2.sp,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PillButton(
                        label = "🔍  Search",
                        textColor = bgColor,
                        background = cardColor
                    ) { navController.navigate("search") }

                    PillButton(
                        label = "🗺️  Map",
                        textColor = bgColor,
                        background = cardColor
                    ) { navController.navigate("map") }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Categories", style = MaterialTheme.typography.titleMedium, color = textOnGreen)
                    Text(
                        text = "View all",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        modifier = Modifier.clickable { navController.navigate("categories") }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val categories = listOf(
                    HomeCategoryCircle(null, "All"),
                    HomeCategoryCircle("Sport", "Sport"),
                    HomeCategoryCircle("Walk", "Walks"),
                    HomeCategoryCircle("Games", "Games"),
                    HomeCategoryCircle("Comedy", "Standup")
                )

                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(categories) { cat ->
                        val isSelected = selectedCategoryId == cat.id
                        CategoryCircle(
                            label = cat.title,
                            isSelected = isSelected,
                            onClick = { selectedCategoryId = if (isSelected) null else cat.id }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            item {
                HomeEventsSection(
                    title = "Nearly",
                    events = nearlyEvents,
                    onViewAllClick = { navController.navigate("events_feed/${FeedPresetType.NEARBY.name}") }
                )
            }
            item {
                HomeEventsSection(
                    title = "Popular",
                    events = popularEvents,
                    onViewAllClick = { navController.navigate("events_feed/${FeedPresetType.POPULAR.name}") }
                )
            }
            item {
                HomeEventsSection(
                    title = "For you",
                    events = forYouEvents,
                    onViewAllClick = { navController.navigate("events_feed/${FeedPresetType.FOR_YOU.name}") }
                )
            }
        }
    }
}

private data class HomeCategoryCircle(val id: String?, val title: String)

@Composable
private fun RowScope.PillButton(
    label: String,
    textColor: Color,
    background: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.weight(1f).clickable(onClick = onClick),
        shape = RoundedCornerShape(999.dp),
        color = background,
        tonalElevation = 4.dp
    ) {
        Box(Modifier.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
            Text(text = label, color = textColor)
        }
    }
}

@Composable
private fun CategoryCircle(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(if (isSelected) Color.White else Color.White.copy(alpha = 0.15f))
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, color = Color.White, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun HomeEventsSection(
    title: String,
    events: List<EventModel>,
    onViewAllClick: () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text("View all", style = MaterialTheme.typography.labelLarge, color = Color.White, modifier = Modifier.clickable(onClick = onViewAllClick))
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (events.isEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth().height(110.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                repeat(2) {
                    Card(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {}
                }
            }
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(events.take(10), key = { it.id }) { event ->
                    // ✅ без внешнего Card (иначе EventCard “режется” по высоте)
                    Box(Modifier.width(280.dp)) {
                        HubEventCard(
                            event = event,
                            onClick = { /* переход в детали */ }
                        )

                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
    }
}
