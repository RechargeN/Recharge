package com.example.rechargenew.ui.features.explore.manage.model

data class MyEntityItemUi(
    val type: String,   // "host" / "location" / "place"
    val id: String,
    val title: String
)
