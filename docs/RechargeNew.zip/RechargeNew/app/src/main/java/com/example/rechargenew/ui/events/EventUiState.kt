package com.example.rechargenew.ui.events

import com.example.rechargenew.data.filters.FilterState
import com.example.rechargenew.domain.multistop.FailureReason
import com.example.rechargenew.domain.multistop.Itinerary
import com.example.rechargenew.domain.multistop.SuggestedAdjustment

data class EventUiState(
    val filter: FilterState = FilterState(),

    // Текущая "страница" событий для показа в UI
    val events: List<EventModel> = emptyList(),

    // ПОЛНЫЙ список после фильтрации (для карты/кластеров/радиуса)
    val filteredAll: List<EventModel> = emptyList(),

    // Multi-stop планы
    val itineraries: List<Itinerary> = emptyList(),

    // Guided Alternatives
    val failureReasons: List<FailureReason> = emptyList(),
    val suggestedAlternatives: List<SuggestedAdjustment> = emptyList(),

    // Текущий номер страницы (0,1,2...)
    val page: Int = 0,

    // Можно ли подгрузить ещё страницы
    val canLoadMore: Boolean = true,

    // Общее количество событий после фильтрации
    val totalCount: Int = 0,

    // Состояния загрузки
    val isLoading: Boolean = false,
    val isRefreshing: Boolean = false,

    val errorMessage: String? = null
)