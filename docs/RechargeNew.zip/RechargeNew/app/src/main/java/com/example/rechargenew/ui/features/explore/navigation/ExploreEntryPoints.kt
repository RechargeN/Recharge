package com.example.rechargenew.ui.features.explore.navigation

import androidx.navigation.NavHostController

object ExploreEntryPoints {

    fun openUserPage(navController: NavHostController, userId: String) {
        navController.navigate(ExploreRoutes.entity("user", userId))
    }

    fun openEntityPage(navController: NavHostController, type: String, id: String) {
        navController.navigate(ExploreRoutes.entity(type, id))
    }

    fun openUpgrade(navController: NavHostController) {
        navController.navigate(ExploreRoutes.UPGRADE)
    }

    fun openMyEntities(navController: NavHostController) {
        navController.navigate(ExploreRoutes.MY_ENTITIES)
    }
}
