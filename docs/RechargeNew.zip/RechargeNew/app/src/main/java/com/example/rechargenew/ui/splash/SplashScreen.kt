package com.example.rechargenew.ui.splash

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SplashScreen() {
    // зелёный как на скрине (можешь потом подкорректировать оттенок)
    val green = Color(0xFF108A4A)
    val white = Color.White

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(green),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Большая буква R
            Text(
                text = "R",
                fontSize = 72.sp,
                fontWeight = FontWeight.ExtraBold,
                color = white
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Текст RECHARGE
            Text(
                text = "RECHARGE",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = white,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Линии + VACATION APP (имитация как на макете)
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(40.dp)
                        .height(1.dp)
                        .background(white)
                )

                Text(
                    text = "  VACATION APP  ",
                    fontSize = 10.sp,
                    color = white,
                    textAlign = TextAlign.Center
                )

                Box(
                    modifier = Modifier
                        .width(40.dp)
                        .height(1.dp)
                        .background(white)
                )
            }
        }
    }
}
