// app/src/main/java/com/example/rechargenew/ui/map/markers/ClusterItem.kt
package com.example.rechargenew.ui.map.markers

import com.example.rechargenew.ui.events.EventModel

/**
 * То, что в итоге рисуем на карте:
 *  - либо один ивент (Single),
 *  - либо кластер из нескольких ивентов (Cluster).
 */
sealed class ClusterItem {

    data class Single(
        val event: EventModel
    ) : ClusterItem()

    data class Cluster(
        val events: List<EventModel>,
        val lat: Double,
        val lng: Double
    ) : ClusterItem() {
        val count: Int get() = events.size
    }
}
