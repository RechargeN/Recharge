package com.example.rechargenew.domain.explore.usecases

import com.example.rechargenew.domain.explore.capabilities.EntityPageCapabilities

/**
 * Domain-модель страницы (без UI).
 * UI потом замапит в header/about/tabs/actions.
 */
data class EntityPageDomain(
    val title: String,
    val subtitle: String,
    val about: String,
    val tags: List<String>,
    val capabilities: EntityPageCapabilities
)
