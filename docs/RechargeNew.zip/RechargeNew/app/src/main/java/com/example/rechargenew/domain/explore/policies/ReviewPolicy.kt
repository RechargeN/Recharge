package com.example.rechargenew.domain.explore.policies

/**
 * Анти-накрутка отзывов/оценок.
 */
object ReviewPolicy {
    fun canLeaveReview(isBanned: Boolean): Boolean = !isBanned
}
