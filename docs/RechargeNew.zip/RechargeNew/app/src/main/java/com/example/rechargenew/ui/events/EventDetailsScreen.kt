package com.example.rechargenew.ui.events

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.rechargenew.data.events.EventRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EventDetailsScreen(
    eventId: String,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    var event by remember { mutableStateOf<EventModel?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(eventId) {
        isLoading = true
        event = EventRepository.getEventById(eventId)
        isLoading = false
    }

    if (isLoading) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    val e = event
    if (e == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("Event not found")
        }
        return
    }

    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .background(Color(0xFFE6F0EB)),
                contentAlignment = Alignment.BottomStart
            ) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0x80000000),
                                    Color.Transparent,
                                    Color(0x80000000)
                                )
                            )
                        )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0x66000000))
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = {
                            scope.launch {
                                val updated = e.copy(isFavorite = !e.isFavorite)
                                // ✅ ВОТ ЭТО КЛЮЧЕВО
                                EventRepository.updateEvent(context, updated)
                                event = updated
                            }
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0x66000000))
                    ) {
                        Icon(
                            imageVector = if (e.isFavorite)
                                Icons.Filled.Favorite
                            else
                                Icons.Filled.FavoriteBorder,
                            contentDescription = "Favorite",
                            tint = Color.White
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(20.dp)
                ) {
                    Text(
                        text = e.title,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "${formatDateTime(e.dateTimeMillis)} · ${e.locationName}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = Color(0xFFEFEFEF)
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                if (e.shortDescription.isNotBlank()) {
                    Text(
                        text = e.shortDescription,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(Modifier.height(12.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (e.category.isNotBlank()) DetailChip(text = e.category)
                    e.tags.take(3).forEach { tag -> DetailChip(text = tag) }
                }

                Spacer(Modifier.height(16.dp))

                Text(
                    text = "Информация",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(Modifier.height(8.dp))

                InfoRowDetail(label = "Когда", value = formatFullDateTime(e.dateTimeMillis))
                InfoRowDetail(label = "Где", value = e.locationName)
                InfoRowDetail(
                    label = "Цена",
                    value = when {
                        e.isFree -> "Бесплатно"
                        e.price != null -> "${e.price} €"
                        else -> "Уточняется"
                    }
                )

                if (e.maxParticipants != null) {
                    InfoRowDetail(
                        label = "Участники",
                        value = "${e.currentParticipants ?: 0} / ${e.maxParticipants}"
                    )
                }

                Spacer(Modifier.height(16.dp))

                val (statusLabel, statusColor) = when {
                    e.isSoldOut -> "Мест нет" to Color(0xFFB00020)
                    e.isAlmostFull -> "Почти нет мест" to MaterialTheme.colorScheme.primary
                    else -> null to null
                }
                if (statusLabel != null && statusColor != null) {
                    Surface(color = statusColor, shape = RoundedCornerShape(50)) {
                        Text(
                            text = statusLabel,
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.White),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                }

                if (e.fullDescription.isNotBlank()) {
                    Text(
                        text = "Описание",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(text = e.fullDescription, style = MaterialTheme.typography.bodyMedium)
                }

                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

/* helpers */

@Composable
private fun DetailChip(text: String) {
    Surface(
        shape = RoundedCornerShape(50),
        border = ButtonDefaults.outlinedButtonBorder,
        color = Color.Transparent
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun InfoRowDetail(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
        )
        Spacer(Modifier.width(12.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f),
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private fun formatDateTime(millis: Long): String {
    val sdf = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault())
    return sdf.format(Date(millis))
}

private fun formatFullDateTime(millis: Long): String {
    val sdf = SimpleDateFormat("EEEE, dd MMMM yyyy · HH:mm", Locale.getDefault())
    return sdf.format(Date(millis))
}
