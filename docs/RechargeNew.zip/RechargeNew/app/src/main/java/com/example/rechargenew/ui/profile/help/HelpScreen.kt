package com.example.rechargenew.ui.profile.help

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(
    onBack: () -> Unit = {},
    onContactSupportClick: () -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Help & info") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("How can we help?", style = MaterialTheme.typography.titleMedium)

            Text(
                "• How to find activities\n" +
                        "• How bookings work\n" +
                        "• How to create routes\n" +
                        "• Privacy and data\n",
                style = MaterialTheme.typography.bodyMedium
            )

            Button(
                onClick = onContactSupportClick,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Contact support")
            }

            Spacer(Modifier.height(8.dp))

            Text(
                text = "Recharge v1.0.0",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
