package com.example.rechargenew.ui.map

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun MapRadiusChipSelector(
    radiusMeters: Int?,
    onRadiusMetersChange: (Int?) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val km = radiusMeters?.let { (it / 1000.0).roundToInt() }
    val chipText = when {
        radiusMeters == null -> "Без радиуса"
        km != null -> "Радиус: $km км"
        else -> "Радиус"
    }

    Column(
        modifier = Modifier
            .statusBarsPadding()
            .padding(start = 12.dp, top = 12.dp)
    ) {
        AssistChip(
            onClick = { expanded = !expanded },
            label = { Text(chipText) }
        )

        AnimatedVisibility(visible = expanded) {
            Card(
                modifier = Modifier.padding(top = 8.dp).widthIn(max = 320.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {

                    val currentKm = ((radiusMeters ?: 5000) / 1000f).coerceIn(1f, 50f)
                    var sliderKm by remember(radiusMeters) { mutableStateOf(currentKm) }

                    Text("Радиус", style = MaterialTheme.typography.titleMedium)

                    Slider(
                        value = sliderKm,
                        onValueChange = { sliderKm = it },
                        valueRange = 1f..50f,
                        onValueChangeFinished = {
                            onRadiusMetersChange((sliderKm * 1000).roundToInt())
                        }
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickKmButton(1) { onRadiusMetersChange(1000) }
                        QuickKmButton(3) { onRadiusMetersChange(3000) }
                        QuickKmButton(5) { onRadiusMetersChange(5000) }
                        QuickKmButton(10) { onRadiusMetersChange(10000) }
                        QuickKmButton(25) { onRadiusMetersChange(25000) }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Без ограничения")
                        Switch(
                            checked = radiusMeters == null,
                            onCheckedChange = { v ->
                                if (v) onRadiusMetersChange(null) else onRadiusMetersChange(5000)
                            }
                        )
                    }

                    TextButton(onClick = { expanded = false }) { Text("Готово") }
                }
            }
        }
    }
}

@Composable
private fun QuickKmButton(km: Int, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
    ) { Text("$km") }
}
