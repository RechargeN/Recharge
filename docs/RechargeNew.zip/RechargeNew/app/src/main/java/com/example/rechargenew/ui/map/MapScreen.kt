package com.example.rechargenew.ui.map

import android.Manifest
import android.annotation.SuppressLint
import android.location.Geocoder
import android.location.Location
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.rechargenew.ui.events.EventsViewModel
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    navController: NavHostController,
    eventsViewModel: EventsViewModel
) {
    val uiState by eventsViewModel.uiState.collectAsState()
    val filter = uiState.filter

    val context = LocalContext.current
    val fusedClient = remember { LocationServices.getFusedLocationProviderClient(context) }

    // dialogs
    var showCategoriesDialog by remember { mutableStateOf(false) }
    var showPeopleDialog by remember { mutableStateOf(false) }

    // filters sheet
    val filtersSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showFiltersSheet by remember { mutableStateOf(false) }

    // radius sheet (single source)
    var showRadiusSheet by remember { mutableStateOf(false) }
    var radiusDraft by remember { mutableStateOf<Int?>(null) }
    var radiusBeforeOpen by remember { mutableStateOf<Int?>(null) }

    // location mode
    var showLocationMenu by remember { mutableStateOf(false) }
    var showLocationSheet by remember { mutableStateOf(false) }
    var locationMode by remember { mutableStateOf(MapLocationMode.Current) }
    var isPickingCenter by remember { mutableStateOf(false) } // keep

    val locationLabel = remember(locationMode) {
        when (locationMode) {
            MapLocationMode.Current -> "Текущая"
            MapLocationMode.PickOnMap -> "Точка на карте"
            MapLocationMode.EnterCity -> "Город/адрес"
        }
    }

    val applyCenter: (Double, Double) -> Unit = { lat, lng ->
        eventsViewModel.updateFilter { old -> old.copy(centerLat = lat, centerLng = lng) }
    }

    // permissions
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted =
            (result[Manifest.permission.ACCESS_FINE_LOCATION] == true) ||
                    (result[Manifest.permission.ACCESS_COARSE_LOCATION] == true)
        if (granted) requestCurrentLocation(fusedClient, eventsViewModel)
    }

    // center by first event (если центр ещё не выбран)
    LaunchedEffect(uiState.filteredAll) {
        val first = uiState.filteredAll.firstOrNull { it.latitude != null && it.longitude != null }
            ?: return@LaunchedEffect

        eventsViewModel.updateFilter { old ->
            if (old.centerLat != null && old.centerLng != null) old
            else old.copy(centerLat = first.latitude!!, centerLng = first.longitude!!)
        }
    }

    Box(Modifier.fillMaxSize()) {

        // MAP
        MapContent(
            events = uiState.filteredAll,
            filter = filter,
            onCenterChange = { lat, lng ->
                // менять центр только в режиме "Точка на карте"
                if (!isPickingCenter) return@MapContent

                val radiusWasNull = filter.radiusMeters == null
                val newRadius = filter.radiusMeters ?: 5000

                // подготовка к открытию sheet
                radiusBeforeOpen = filter.radiusMeters
                radiusDraft = newRadius

                eventsViewModel.updateFilter { old ->
                    old.copy(
                        centerLat = lat,
                        centerLng = lng,
                        radiusMeters = newRadius
                    )
                }

                // sheet показываем только когда радиус был null (первичная настройка)
                if (radiusWasNull) showRadiusSheet = true
            },
            onEventOpen = { event ->
                // TODO: navController.navigate("eventDetails/${event.id}")
            }
        )

        // TOP PANEL
        Surface(
            shape = RoundedCornerShape(18.dp),
            tonalElevation = 2.dp,
            shadowElevation = 8.dp,
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
            modifier = Modifier
                .statusBarsPadding()
                .padding(12.dp)
                .fillMaxWidth()
                .align(Alignment.TopCenter)
        ) {
            Column(Modifier.padding(10.dp)) {

                // Row 1
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadiusChip(
                        radiusMeters = filter.radiusMeters,
                        onClick = {
                            radiusBeforeOpen = filter.radiusMeters
                            radiusDraft = filter.radiusMeters
                            showRadiusSheet = true
                        },
                        modifier = Modifier.weight(1f)
                    )

                    IconButton(onClick = { showFiltersSheet = true }) {
                        Icon(Icons.Outlined.Tune, contentDescription = "Фильтры")
                    }

                    AssistChip(
                        onClick = { showLocationMenu = true },
                        label = { Text(locationLabel) },
                        leadingIcon = { Icon(Icons.Outlined.LocationOn, contentDescription = null) }
                    )

                    DropdownMenu(
                        expanded = showLocationMenu,
                        onDismissRequest = { showLocationMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Текущая") },
                            onClick = {
                                locationMode = MapLocationMode.Current
                                isPickingCenter = false
                                showLocationMenu = false
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Точка на карте") },
                            onClick = {
                                locationMode = MapLocationMode.PickOnMap
                                isPickingCenter = true
                                showLocationMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Город/адрес") },
                            onClick = {
                                locationMode = MapLocationMode.EnterCity
                                isPickingCenter = false
                                showLocationMenu = false
                                showLocationSheet = true
                            }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Row 2
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = filter.selectedCategoryIds.isNotEmpty(),
                        onClick = { showCategoriesDialog = true },
                        label = {
                            Text(
                                if (filter.selectedCategoryIds.isEmpty()) "Категории"
                                else "Категории: ${filter.selectedCategoryIds.size}"
                            )
                        }
                    )

                    FilterChip(
                        selected = true,
                        onClick = { showPeopleDialog = true },
                        label = { Text("Люди: ${filter.peopleCount}") }
                    )

                    FilterChip(
                        selected = (filter.budgetMinInput != null || filter.budgetMaxInput != null),
                        onClick = { showFiltersSheet = true },
                        label = { Text("Бюджет") }
                    )

                    FilterChip(
                        selected = filter.onlyFree,
                        onClick = { eventsViewModel.updateFilter { it.copy(onlyFree = !it.onlyFree) } },
                        label = { Text("Free") }
                    )
                }
            }
        }
    }

    // RADIUS SHEET (single)
    if (showRadiusSheet) {
        MapRadiusSheet(
            currentRadiusMeters = radiusDraft,
            onDismiss = {
                // cancel -> revert
                eventsViewModel.updateFilter { it.copy(radiusMeters = radiusBeforeOpen) }
                radiusDraft = radiusBeforeOpen
                showRadiusSheet = false
            },
            onPreview = { meters ->
                // preview -> live update (circle + filtering)
                radiusDraft = meters
                eventsViewModel.updateFilter { it.copy(radiusMeters = meters) }
            },
            onCommit = { meters ->
                // commit -> remember and close
                radiusBeforeOpen = meters
                radiusDraft = meters
                eventsViewModel.updateFilter { it.copy(radiusMeters = meters) }
                showRadiusSheet = false
            }
        )
    }

    // LOCATION SHEET
    if (showLocationSheet) {
        LocationSearchSheet(
            onDismiss = { showLocationSheet = false },
            onSelect = { lat, lng ->
                applyCenter(lat, lng)
                showLocationSheet = false
            }
        )
    }

    // FILTERS SHEET
    if (showFiltersSheet) {
        var minBudgetText by remember(filter.budgetMinInput) {
            mutableStateOf(filter.budgetMinInput?.toString().orEmpty())
        }
        var maxBudgetText by remember(filter.budgetMaxInput) {
            mutableStateOf(filter.budgetMaxInput?.toString().orEmpty())
        }

        ModalBottomSheet(
            onDismissRequest = { showFiltersSheet = false },
            sheetState = filtersSheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Фильтры", style = MaterialTheme.typography.titleLarge)

                Text("Бюджет", style = MaterialTheme.typography.titleMedium)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = minBudgetText,
                        onValueChange = { minBudgetText = it.filter(Char::isDigit) },
                        label = { Text("Min") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = maxBudgetText,
                        onValueChange = { maxBudgetText = it.filter(Char::isDigit) },
                        label = { Text("Max") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = {
                        val min = minBudgetText.toIntOrNull()
                        val max = maxBudgetText.toIntOrNull()
                        eventsViewModel.updateFilter {
                            it.copy(
                                budgetMinInput = min,
                                budgetMaxInput = max,
                                minPrice = min?.toDouble(),
                                maxPrice = max?.toDouble()
                            )
                        }
                        showFiltersSheet = false
                    }) { Text("Применить") }
                }

                HorizontalDivider()

                TextButton(onClick = {
                    eventsViewModel.updateFilter {
                        it.copy(
                            budgetMinInput = null,
                            budgetMaxInput = null,
                            minPrice = null,
                            maxPrice = null,
                            onlyFree = false
                        )
                    }
                    minBudgetText = ""
                    maxBudgetText = ""
                }) {
                    Text("Сбросить бюджет/Free")
                }

                Spacer(Modifier.height(24.dp))
            }
        }
    }

    // DIALOGS
    if (showCategoriesDialog) {
        CategoriesFilterDialog(
            current = filter.selectedCategoryIds,
            onApply = { newSet ->
                eventsViewModel.updateFilter { it.copy(selectedCategoryIds = newSet) }
                showCategoriesDialog = false
            },
            onDismiss = { showCategoriesDialog = false }
        )
    }

    if (showPeopleDialog) {
        PeopleFilterDialog(
            current = filter.peopleCount,
            onApply = { newCount ->
                eventsViewModel.updateFilter { it.copy(peopleCount = (newCount ?: 1)) }
                showPeopleDialog = false
            },
            onDismiss = { showPeopleDialog = false }
        )
    }
}

@Composable
private fun RadiusChip(
    radiusMeters: Int?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val text = if (radiusMeters == null) {
        "Радиус: без"
    } else {
        val km = (radiusMeters / 1000).coerceAtLeast(1)
        "Радиус: ${km}км"
    }

    AssistChip(
        onClick = onClick,
        label = { Text(text) },
        modifier = modifier
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LocationSearchSheet(
    onDismiss: () -> Unit,
    onSelect: (Double, Double) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val geocoder = remember { Geocoder(context, Locale.getDefault()) }

    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<LocationResult>>(emptyList()) }

    fun runSearch(text: String) {
        scope.launch {
            if (text.length < 3) {
                results = emptyList()
                return@launch
            }
            loading = true
            delay(300)
            val q = text
            val found = withContext(Dispatchers.IO) {
                runCatching {
                    @Suppress("DEPRECATION")
                    geocoder.getFromLocationName(q, 10)
                        ?.mapNotNull { a ->
                            val line = a.getAddressLine(0) ?: return@mapNotNull null
                            LocationResult(
                                title = line,
                                lat = a.latitude,
                                lng = a.longitude
                            )
                        } ?: emptyList()
                }.getOrDefault(emptyList())
            }
            if (q == query) results = found
            loading = false
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text("Город / адрес", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(10.dp))

            OutlinedTextField(
                value = query,
                onValueChange = {
                    query = it
                    runSearch(it)
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Введите город или адрес") }
            )

            Spacer(Modifier.height(10.dp))

            if (loading) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
            }

            LazyColumn {
                items(results) { item ->
                    ListItem(
                        headlineContent = { Text(item.title) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(item.lat, item.lng) }
                    )
                    HorizontalDivider()
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}

private data class LocationResult(
    val title: String,
    val lat: Double,
    val lng: Double
)

@SuppressLint("MissingPermission")
private fun requestCurrentLocation(
    fusedClient: FusedLocationProviderClient,
    eventsViewModel: EventsViewModel
) {
    fusedClient.lastLocation.addOnSuccessListener { loc: Location? ->
        if (loc != null) {
            eventsViewModel.updateFilter { old ->
                old.copy(centerLat = loc.latitude, centerLng = loc.longitude)
            }
        }
    }
}