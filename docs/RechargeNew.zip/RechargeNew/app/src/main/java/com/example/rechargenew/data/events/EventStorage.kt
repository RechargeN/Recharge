package com.example.rechargenew.data.events

import android.content.Context
import android.content.SharedPreferences
import com.example.rechargenew.ui.events.EventModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Простое локальное хранилище только для СОЗДАННЫХ пользователем событий.
 */
object EventStorage {

    private const val PREFS_NAME = "recharge_events_prefs"
    private const val KEY_USER_EVENTS = "user_events"

    private lateinit var prefs: SharedPreferences
    private val gson = Gson()

    fun init(context: Context) {
        if (EventStorage::prefs.isInitialized) return
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun loadUserEvents(): List<EventModel> {
        if (!EventStorage::prefs.isInitialized) return emptyList()
        val json = prefs.getString(KEY_USER_EVENTS, null) ?: return emptyList()

        return try {
            val type = object : TypeToken<List<EventModel>>() {}.type
            gson.fromJson<List<EventModel>>(json, type) ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveUserEvents(events: List<EventModel>) {
        if (!EventStorage::prefs.isInitialized) return
        val json = gson.toJson(events)
        prefs.edit().putString(KEY_USER_EVENTS, json).apply()
    }

    fun appendUserEvent(event: EventModel) {
        val current = loadUserEvents().toMutableList()
        current.add(event)
        saveUserEvents(current)
    }
}
