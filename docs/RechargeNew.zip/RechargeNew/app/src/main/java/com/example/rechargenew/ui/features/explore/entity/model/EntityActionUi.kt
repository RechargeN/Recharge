package com.example.rechargenew.ui.features.explore.entity.model

data class EntityActionUi(
    val id: String,
    val title: String,
    val enabled: Boolean = true,
    val kind: Kind = Kind.SECONDARY
) {
    enum class Kind { PRIMARY, SECONDARY, DANGER }
}
