package com.example.rechargenew.ui.profile.privacy

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(
    onBack: () -> Unit = {},
    onDeleteAccount: () -> Unit = {}
) {
    var shareLocation by remember { mutableStateOf(true) }
    var personalizedRecommendations by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Privacy preferences") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Control how we use your data", style = MaterialTheme.typography.titleMedium)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Share location")
                    Text(
                        "Allow Recharge to use your location for nearby activities.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = shareLocation, onCheckedChange = { shareLocation = it })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Personalized recommendations")
                    Text(
                        "Use your history and favourites to personalize suggestions.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(
                    checked = personalizedRecommendations,
                    onCheckedChange = { personalizedRecommendations = it }
                )
            }

            Spacer(Modifier.height(24.dp))

            Text(
                text = "Danger zone",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.error
            )

            OutlinedButton(
                onClick = onDeleteAccount,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MaterialTheme.colorScheme.error
                )
            ) {
                Text("Delete account")
            }
        }
    }
}
