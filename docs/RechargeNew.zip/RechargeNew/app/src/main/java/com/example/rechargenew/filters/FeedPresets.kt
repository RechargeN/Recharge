package com.example.rechargenew.filters

import java.util.Calendar
import java.util.Calendar.HOUR_OF_DAY
import java.util.Calendar.MINUTE
import java.util.Calendar.SECOND
import java.util.Calendar.MILLISECOND
import com.example.rechargenew.data.filters.FilterState


/**
 * Типы "умных" режимов ленты D.
 *
 * Это НЕ категории интересов (Music / Comedy),
 * а пресеты фильтра: "Сегодня", "Рядом", "Популярное" и т.п.
 */
enum class FeedPresetType {
    TODAY,
    NEARBY,
    POPULAR,
    FOR_YOU,
    VIBES,
    FREE,
    LAST_MINUTE,
    NEW
}

/**
 * UI-модель пресета для главного экрана.
 */
data class FeedPreset(
    val type: FeedPresetType,
    val title: String,
    val subtitle: String,
    val emoji: String
)

/**
 * Набор всех пресетов, которые можно показать на главном экране
 * в виде карточек / чипов: Today, Local, Popular, For you, Vibes и т.д.
 */
object FeedPresets {

    val all: List<FeedPreset> = listOf(
        FeedPreset(
            type = FeedPresetType.TODAY,
            title = "Today",
            subtitle = "What’s happening right now",
            emoji = "📅"
        ),
        FeedPreset(
            type = FeedPresetType.NEARBY,
            title = "Local",
            subtitle = "Close to you",
            emoji = "📍"
        ),
        FeedPreset(
            type = FeedPresetType.POPULAR,
            title = "Popular",
            subtitle = "Most booked",
            emoji = "🔥"
        ),
        FeedPreset(
            type = FeedPresetType.FOR_YOU,
            title = "For you",
            subtitle = "Based on your favourites",
            emoji = "✨"
        ),
        FeedPreset(
            type = FeedPresetType.VIBES,
            title = "Vibes",
            subtitle = "Chill, party, deep talk",
            emoji = "🌈"
        ),
        FeedPreset(
            type = FeedPresetType.FREE,
            title = "Free",
            subtitle = "0 € activities",
            emoji = "🆓"
        ),
        FeedPreset(
            type = FeedPresetType.LAST_MINUTE,
            title = "Last minute",
            subtitle = "Starting soon",
            emoji = "⏰"
        ),
        FeedPreset(
            type = FeedPresetType.NEW,
            title = "New",
            subtitle = "Freshly added",
            emoji = "🆕"
        )
    )
}

/**
 * Применить пресет к текущему FilterState.
 *
 * ВАЖНО: пока используем ТОЛЬКО поля, которые уже есть в FilterState:
 *  - dateFromMillis / dateToMillis
 *  - centerLatitude / centerLongitude / radiusKm
 *  - maxPrice / onlyFree
 */
fun FeedPresetType.applyTo(
    base: FilterState,
    nowMillis: Long,
    userLat: Double?,
    userLon: Double?
): Any {
    return when (this) {
        FeedPresetType.TODAY -> {
            base.copy(
                dateFromMillis = startOfDay(nowMillis),
                dateToMillis = endOfDay(nowMillis)
            )
        }

        FeedPresetType.NEARBY -> {
            if (userLat != null && userLon != null) {
                base.copy(
                    centerLat = userLat,
                    centerLng = userLon,
                    radiusMeters = 5_000
                )
            } else base
        }

        FeedPresetType.FREE -> {
            base.copy(
                maxPrice = 0.0,
                onlyFree = true
            )
        }

        FeedPresetType.LAST_MINUTE -> {
            // ближайшие 3 часа
            val threeHoursMs = 3 * 60 * 60 * 1000L
            base.copy(
                dateFromMillis = nowMillis,
                dateToMillis = nowMillis + threeHoursMs
            )
        }

        // Эти пока только "имена" – реальную логику
        // (популярность, персонализация, vibes-теги)
        // можно добавить позже, не ломая API.
        FeedPresetType.POPULAR,
        FeedPresetType.FOR_YOU,
        FeedPresetType.VIBES,
        FeedPresetType.NEW -> base
    }
}

// ---------- Вспомогательные функции для "сегодня" ----------

private fun startOfDay(millis: Long): Long {
    val cal = Calendar.getInstance().apply {
        timeInMillis = millis
        set(HOUR_OF_DAY, 0)
        set(MINUTE, 0)
        set(SECOND, 0)
        set(MILLISECOND, 0)
    }
    return cal.timeInMillis
}

private fun endOfDay(millis: Long): Long {
    val cal = Calendar.getInstance().apply {
        timeInMillis = millis
        set(HOUR_OF_DAY, 23)
        set(MINUTE, 59)
        set(SECOND, 59)
        set(MILLISECOND, 999)
    }
    return cal.timeInMillis
}
