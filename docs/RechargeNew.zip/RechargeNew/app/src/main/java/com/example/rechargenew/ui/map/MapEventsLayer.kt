package com.example.rechargenew.ui.map

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.rechargenew.data.filters.FilterState
import com.example.rechargenew.ui.events.EventModel
import com.example.rechargenew.ui.map.markers.EventClusterItem
import com.example.rechargenew.ui.map.markers.PhotoMarkerIconProvider
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.clustering.Cluster
import com.google.maps.android.compose.Circle
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.clustering.Clustering
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

private const val PHOTO_ZOOM = 14f

@Composable
fun MapEventsLayer(
    events: List<EventModel>,
    filter: FilterState,
    zoom: Float,
    onEventClick: (EventModel) -> Unit,
    onClusterClick: (clusterEvents: List<EventModel>, position: LatLng) -> Unit
) {
    val centerLat = filter.centerLat
    val centerLng = filter.centerLng
    val radiusMeters = filter.radiusMeters?.let { it * 1000.0 } // Double meters

    // ✅ Центр и круг радиуса
    if (centerLat != null && centerLng != null) {
        val center = LatLng(centerLat, centerLng)

        Marker(
            state = MarkerState(position = center),
            title = "Центр радиуса",
            snippet = "Тап по карте — перенос"
        )

        if (radiusMeters != null) {
            Circle(
                center = center,
                radius = radiusMeters.toDouble(),
                strokeColor = Color(0xFF2E6BFF),
                strokeWidth = 2f,
                fillColor = Color(0xFF2E6BFF).copy(alpha = 0.12f)
            )
        }
    }

    // Только события с координатами
    val withCoords = events.filter { it.latitude != null && it.longitude != null }

    // Если включён радиус — отсекаем
    val filtered = if (centerLat != null && centerLng != null && radiusMeters != null) {
        withCoords.filter { e ->
            distanceMeters(centerLat, centerLng, e.latitude!!, e.longitude!!) <= radiusMeters
        }
    } else withCoords


    val items: List<EventClusterItem> = remember(filtered) {
        filtered.map { EventClusterItem(it) }
    }

    // Прогрев (оставляем, пусть будет)
    val context = LocalContext.current
    val photoProvider = remember { PhotoMarkerIconProvider() }
    LaunchedEffect(zoom, filtered.size) {
        if (zoom >= PHOTO_ZOOM) {
            filtered.take(80).forEach { e ->
                photoProvider.preload(context, e)
            }
        }
    }

    Clustering(
        items = items,

        // ✅ Кластер: стильный bubble
        clusterContent = { cluster: Cluster<EventClusterItem> ->
            ClusterBubble(text = cluster.size.toString())
        },

        // ✅ Элемент: ВСЕГДА фиксированный размер (анти-crash)
        clusterItemContent = { item ->
            val title = item.event.title.orEmpty()
            val letter = title.trim().firstOrNull()?.uppercaseChar()?.toString() ?: ""

            if (zoom >= PHOTO_ZOOM) {
                PhotoPinModern(letter = letter)
            } else {
                EventDotModern(letter = letter)
            }
        },

        onClusterClick = { cluster ->
            val clusterEvents = cluster.items.map { it.event }
            onClusterClick(clusterEvents, cluster.position)
            true
        },

        onClusterItemClick = { item ->
            onEventClick(item.event)
            true
        }
    )
}

/** ===== UI ===== */

@Composable
private fun ClusterBubble(text: String) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .background(Color(0xFF2E6BFF), CircleShape)
            .border(2.dp, Color.White.copy(alpha = 0.9f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun EventDotModern(letter: String) {
    Box(
        modifier = Modifier
            .size(36.dp) // ✅ фикс. размер
            .background(Color(0xFF111827), CircleShape)
            .border(1.dp, Color.White.copy(alpha = 0.18f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = letter,
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelLarge
        )
    }
}

@Composable
private fun PhotoPinModern(letter: String) {
    // “Фото-пин” без реального фото, но выглядит как современный thumbnail-pin
    Box(
        modifier = Modifier
            .size(42.dp) // ✅ фикс. размер
            .background(Color(0xFF0B1220), CircleShape)
            .border(2.dp, Color.White.copy(alpha = 0.22f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .background(Color(0xFF2E6BFF), CircleShape)
                .border(2.dp, Color.White.copy(alpha = 0.9f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = letter,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

/** ===== GEO ===== */

private fun distanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Int {
    val R = 6371000.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLng = Math.toRadians(lng2 - lng1)
    val a = sin(dLat / 2).pow(2.0) +
            cos(Math.toRadians(lat1)) *
            cos(Math.toRadians(lat2)) *
            sin(dLng / 2).pow(2.0)
    val c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return (R * c).roundToInt()
}
