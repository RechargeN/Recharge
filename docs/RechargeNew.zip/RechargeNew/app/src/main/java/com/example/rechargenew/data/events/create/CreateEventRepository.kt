package com.example.rechargenew.data.events.create

import android.content.Context
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.ui.events.EventModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

interface CreateEventRepository {
    suspend fun createEvent(context: Context, draft: EventDraft): EventModel
}

class DefaultCreateEventRepository(
    private val eventRepository: EventRepository = EventRepository
) : CreateEventRepository {

    override suspend fun createEvent(context: Context, draft: EventDraft): EventModel =
        withContext(Dispatchers.IO) {

            val dateTime = draft.dateTimeMillis ?: System.currentTimeMillis()
            val id = UUID.randomUUID().toString()

            val primaryCategory = draft.categories.firstOrNull()
            val primaryCategoryString = primaryCategory?.name ?: "OTHER"

            val locationName = draft.location?.address ?: "Unknown location"
            val isFree = draft.price == null || draft.price == 0.0

            val shortDescription = if (draft.description.length <= 120) {
                draft.description
            } else {
                draft.description.take(117) + "..."
            }

            val timeTags = draft.recommendedTimes.map { "TIME_${it.name}" }

            val tags = buildList {
                draft.categories.forEach { add(it.name) }
                draft.subcategoryIdsByCategory.values.forEach { addAll(it) }
                addAll(timeTags)
            }

            val coverPhoto = draft.photoUris.firstOrNull() ?: draft.photoUri

            val event = EventModel(
                id = id,
                title = draft.title.trim(),
                category = primaryCategoryString,
                imageUrl = coverPhoto ?: "",
                dateTimeMillis = dateTime,
                locationName = locationName,
                latitude = draft.location?.latitude,
                longitude = draft.location?.longitude,
                price = draft.price,
                isFree = isFree,
                maxParticipants = null,
                currentParticipants = null,
                isFavorite = false,
                tags = tags,
                shortDescription = shortDescription,
                fullDescription = draft.description
            )

            // ✅ ВАЖНО: сохраняем + пушим в flow
            eventRepository.addEvent(context, event)

            event
        }
}
