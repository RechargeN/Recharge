package com.example.rechargenew.ui.features.explore.navigation

object ExploreRoutes {
    const val ROOT = ExploreNavConstants.ROOT

    const val ENTITY = "explore/entity/{${ExploreNavConstants.ARG_ENTITY_TYPE}}/{${ExploreNavConstants.ARG_ENTITY_ID}}"
    const val UPGRADE = "explore/upgrade"
    const val MY_ENTITIES = "explore/my_entities"

    fun entity(entityType: String, entityId: String): String =
        "explore/entity/$entityType/$entityId"
}
