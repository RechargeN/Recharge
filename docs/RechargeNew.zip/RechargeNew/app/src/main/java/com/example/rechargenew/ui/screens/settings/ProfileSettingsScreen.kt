package com.example.rechargenew.ui.screens.settings

import androidx.compose.runtime.Composable
import com.example.rechargenew.ui.profile.ProfileScreen

@Composable
fun ProfileSettingsScreen(
    onBack: () -> Unit = {},
    onCreateEventClick: () -> Unit = {}
) {
    ProfileScreen(
        onCreateEventClick = onCreateEventClick
    )
}