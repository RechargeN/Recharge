package com.example.rechargenew.ui.screens.explore.entity

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ExploreEntityTabs(
    tab: ExploreEntityTab,
    onTab: (ExploreEntityTab) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FilterChip(
            selected = tab == ExploreEntityTab.UPCOMING,
            onClick = { onTab(ExploreEntityTab.UPCOMING) },
            label = { Text("Upcoming") }
        )
        FilterChip(
            selected = tab == ExploreEntityTab.PAST,
            onClick = { onTab(ExploreEntityTab.PAST) },
            label = { Text("Past") }
        )
        FilterChip(
            selected = tab == ExploreEntityTab.PHOTOS,
            onClick = { onTab(ExploreEntityTab.PHOTOS) },
            label = { Text("Photos") }
        )
    }
}

@Composable
fun ExploreEntityAboutBlock(
    about: String,
    tags: List<String>
) {
    if (about.isBlank() && tags.isEmpty()) return

    Text(
        text = "About",
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
    )

    if (about.isNotBlank()) {
        Text(
            text = about,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
    }

    if (tags.isNotEmpty()) {
        Text(
            text = tags.joinToString("  •  "),
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
        )
    }
}
