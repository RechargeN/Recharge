package com.example.rechargenew.ui.map.markers

import com.example.rechargenew.ui.events.EventModel
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.clustering.ClusterItem

data class EventClusterItem(
    val event: EventModel
) : com.google.maps.android.clustering.ClusterItem {

    override fun getPosition(): LatLng {
        val lat = event.latitude ?: 0.0
        val lng = event.longitude ?: 0.0
        return LatLng(lat, lng)
    }

    override fun getZIndex(): Float? = null
    override fun getTitle(): String = event.title
    override fun getSnippet(): String = event.locationName

    // ВАЖНО: в твоей версии интерфейс требует Float? 0f
}
