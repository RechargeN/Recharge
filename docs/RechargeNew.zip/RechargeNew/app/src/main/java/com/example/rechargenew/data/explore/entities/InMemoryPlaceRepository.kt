package com.example.rechargenew.data.explore.entities

import com.example.rechargenew.data.explore.entities.model.PlaceEntity

class InMemoryPlaceRepository : PlaceRepository {

    private val store = mutableMapOf<String, PlaceEntity>()

    fun seedIfMissing(id: String, title: String) {
        store.putIfAbsent(
            id,
            PlaceEntity(
                id = id,
                title = title,
                about = "This is a public place page (park/spot). People can add photos and tips (with moderation).",
                tags = listOf("public", "spot")
            )
        )
    }

    override suspend fun getById(id: String): PlaceEntity? = store[id]
}
