package com.example.rechargenew.ui.features.explore.entity.model

data class EntityPageCapabilitiesUi(
    val canEdit: Boolean = false,
    val canCreateEvent: Boolean = false,
    val canCreatePlace: Boolean = false
)
