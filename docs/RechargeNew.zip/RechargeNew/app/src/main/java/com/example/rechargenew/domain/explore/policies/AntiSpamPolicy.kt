package com.example.rechargenew.domain.explore.policies

/**
 * Политика анти-мусора (особенно для contributor).
 * Здесь будут лимиты и проверки.
 */
object AntiSpamPolicy {
    // MVP значения — позже можно вынести в remote config
    const val MAX_PLACES_PER_DAY = 3
    const val MAX_REPORTS_PER_DAY = 10
}
