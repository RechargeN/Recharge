package com.example.rechargenew.ui.profile.saved

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// Модель сохранённого поиска
data class SavedSearch(
    val id: String,
    val title: String,      // "Stand-up tonight"
    val location: String,   // "Amsterdam, 5 km"
    val timeRange: String,  // "Today evening"
    val filters: String     // "Comedy • 2–4 people • €€"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedSearchesScreen(
    items: List<SavedSearch>,
    onBack: () -> Unit = {},
    onSearchClick: (SavedSearch) -> Unit = {},
    onDeleteClick: (SavedSearch) -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Saved searches") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        if (items.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
            ) {
                Text("You don't have saved searches yet.")
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Use filters in search and tap 'Save search' to keep it here.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(items) { saved ->
                    SavedSearchItem(
                        item = saved,
                        onClick = { onSearchClick(saved) },
                        onDeleteClick = { onDeleteClick(saved) }
                    )
                }
            }
        }
    }
}

@Composable
private fun SavedSearchItem(
    item: SavedSearch,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = item.title,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f)
            )

            TextButton(onClick = onDeleteClick) {
                Text("Delete")
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = "${item.location} • ${item.timeRange}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = item.filters,
            style = MaterialTheme.typography.bodySmall
        )

        Divider(modifier = Modifier.padding(top = 12.dp))
    }
}
