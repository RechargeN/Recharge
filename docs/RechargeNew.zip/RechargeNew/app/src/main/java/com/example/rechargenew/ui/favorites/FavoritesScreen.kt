package com.example.rechargenew.ui.favorites

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.ui.events.EventCard
import com.example.rechargenew.ui.events.EventModel
import kotlinx.coroutines.launch

@Composable
fun FavoritesScreen(
    onEventClick: (String) -> Unit,
    onGoToSearchClick: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // ✅ Подписка на Flow репозитория
    val allEvents by EventRepository.events.collectAsState()
    val favoriteEvents = remember(allEvents) { allEvents.filter { it.isFavorite } }

    if (favoriteEvents.isEmpty()) {
        EmptyFavoritesState(onGoToSearchClick = onGoToSearchClick)
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(
                items = favoriteEvents,
                key = { it.id }
            ) { event ->
                EventCard(
                    event = event,
                    onClick = { onEventClick(event.id) },
                    onToggleFavorite = { ev ->
                        scope.launch {
                            val updated = ev.copy(isFavorite = !ev.isFavorite)

                            // ✅ ВАЖНО: тут твоя сигнатура — updateEvent(context, event)
                            EventRepository.updateEvent(context, updated)
                            // Ничего перечитывать не надо: Flow сам обновит UI
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun EmptyFavoritesState(
    onGoToSearchClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "У вас пока нет избранных мероприятий",
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "Нажмите на сердечко в понравившихся событиях, чтобы сохранить их здесь.",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onGoToSearchClick) {
            Text("Перейти к поиску")
        }
    }
}
