package com.example.rechargenew.ui.features.explore.navigation

object ExploreNavConstants {
    const val ROOT = "explore"

    const val ARG_ENTITY_TYPE = "entityType"
    const val ARG_ENTITY_ID = "entityId"

    const val ARG_UPGRADE_FROM = "from" // опционально
}
