package com.example.rechargenew.ui.features.explore.entity.variants

import com.example.rechargenew.domain.explore.model.UserRole
import com.example.rechargenew.ui.features.explore.entity.ExploreEntityUiState

class LocationPageComposer : EntityPageComposer {
    override fun compose(
        state: ExploreEntityUiState,
        roles: Set<UserRole>
    ): ExploreEntityUiState = state
}