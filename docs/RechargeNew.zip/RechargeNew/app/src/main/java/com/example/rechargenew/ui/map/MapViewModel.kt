package com.example.rechargenew.ui.map

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.data.filters.FilterState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

class MapViewModel(
    app: Application,
    private val eventRepository: EventRepository,
    private val filterStateFlow: StateFlow<FilterState>,
    private val updateFilter: (FilterState) -> Unit
) : AndroidViewModel(app) {

    private val _ui = MutableStateFlow(MapUiState())
    val ui: StateFlow<MapUiState> = _ui

    val filters: StateFlow<FilterState> = filterStateFlow

    fun toggleRadiusPanel(open: Boolean) {
        _ui.update { state ->
            if (open) {
                // при открытии берем текущий радиус в preview
                state.copy(
                    radiusPanelOpen = true,
                    radiusPreviewMeters = filters.value.radiusMeters
                )
            } else {
                state.copy(
                    radiusPanelOpen = false,
                    radiusPreviewMeters = null
                )
            }
        }
    }

    fun setRadiusPreviewKm(km: Int) {
        _ui.update { it.copy(radiusPreviewMeters = km * 1000) }
    }

    fun setRadiusPreviewUnlimited() {
        _ui.update { it.copy(radiusPreviewMeters = null) }
    }
    fun setPeopleCount(count: Int) {
        val f = filters.value
        updateFilter(f.copy(peopleCount = count.coerceAtLeast(1)))
    }

    fun toggleOnlyFree() {
        val f = filters.value
        updateFilter(f.copy(onlyFree = !f.onlyFree))
    }

    fun applyRadiusFromPreview() {
        val f = filters.value
        val preview = ui.value.radiusPreviewMeters
        updateFilter(f.copy(radiusMeters = preview))
    }

    fun setCenter(lat: Double, lng: Double) {
        val f = filters.value
        updateFilter(f.copy(centerLat = lat, centerLng = lng))
    }

    fun openLocationSearch(open: Boolean) {
        _ui.update { it.copy(locationSearchOpen = open) }
    }

    // остальная логика (кластеры/панель) без изменений
}
