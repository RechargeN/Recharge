package com.example.rechargenew.ui.events

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rechargenew.data.events.EventRepository
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalContext

/**
 * Лента событий (блок D), работающая через общий EventsViewModel.
 * Показывает отфильтрованные события, поддерживает подгрузку и избранное.
 */
@Composable
fun EventsFeedScreen(
    eventsViewModel: EventsViewModel,
    onEventClick: (String) -> Unit
) {
    val uiState by eventsViewModel.uiState.collectAsState()

    EventsFeedContent(
        events = uiState.events,
        isLoading = uiState.isLoading,
        canLoadMore = uiState.canLoadMore,
        onLoadMore = { eventsViewModel.loadNextPage() },
        onRefresh = { eventsViewModel.refresh(resetFilter = false) },
        onEventClick = onEventClick
    )
}

@Composable
private fun EventsFeedContent(
    events: List<EventModel>,
    isLoading: Boolean,
    canLoadMore: Boolean,
    onLoadMore: () -> Unit,
    onRefresh: () -> Unit,
    onEventClick: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current   // ✅ ВНЕ launch, на уровне composable


    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(events, key = { it.id }) { event ->
            EventCard(
                event = event,
                onClick = { onEventClick(event.id) },
                onToggleFavorite = { e ->
                    scope.launch {
                        try {
                            val toggled = e.copy(isFavorite = !e.isFavorite) // ✅ создаём toggled
                            EventRepository.updateEvent(context, toggled)      // ✅ правильный вызов
                            onRefresh()
                        } catch (err: Exception) {
                            err.printStackTrace()
                        }
                    }
                }
            )
        }


        // Простейшая автодогрузка следующей страницы
        if (canLoadMore && !isLoading && events.isNotEmpty()) {
            item {
                LaunchedEffect(events.size) {
                    onLoadMore()
                }
            }
        }
    }
}
