package com.example.rechargenew.ui.features.explore.entity.blocks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rechargenew.ui.features.explore.entity.model.EntityActionUi

@Composable
fun ActionsBlock(
    actions: List<EntityActionUi>,
    onAction: (EntityActionUi) -> Unit
) {
    if (actions.isEmpty()) return

    val rows = actions.chunked(2)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        rows.forEach { rowActions ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowActions.forEach { action ->
                    ActionButton(
                        action = action,
                        onClick = { onAction(action) },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (rowActions.size == 1) {
                    androidx.compose.foundation.layout.Spacer(
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionButton(
    action: EntityActionUi,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    when (action.kind) {
        EntityActionUi.Kind.PRIMARY -> {
            Button(
                onClick = onClick,
                enabled = action.enabled,
                modifier = modifier
            ) {
                Text(action.title)
            }
        }

        EntityActionUi.Kind.SECONDARY,
        EntityActionUi.Kind.DANGER -> {
            OutlinedButton(
                onClick = onClick,
                enabled = action.enabled,
                modifier = modifier
            ) {
                Text(action.title)
            }
        }
    }
}