package com.example.rechargenew.ui.events.create

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.rechargenew.data.categories.CategoryData
import com.example.rechargenew.data.categories.SubcategoryData
import com.example.rechargenew.model.EventCategory

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CategoriesSection(
    selectedCategories: List<EventCategory>,
    activeCategory: EventCategory?,
    selectedSubcategoryIdsByCategory: Map<EventCategory, List<String>>,
    categories: List<CategoryData>,
    subcategories: List<SubcategoryData>,
    onCategoryClick: (EventCategory) -> Unit,
    onSubcategoryClick: (String) -> Unit,
    error: String?
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {

            Text(
                text = "Category",
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = "Select all categories that match your activity, then add tags.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // --- МНОГОКРАТНЫЙ ВЫБОР КАТЕГОРИЙ ---
            if (categories.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                ) {
                    categories.forEach { category ->
                        val isSelected = selectedCategories.contains(category.id)

                        AssistChip(
                            onClick = { onCategoryClick(category.id) },
                            label = {
                                Text(
                                    text = "${category.emoji}  ${category.title}",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                )
                            },
                            leadingIcon = if (isSelected) {
                                {
                                    androidx.compose.material3.Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = "Selected"
                                    )
                                }
                            } else null,
                            modifier = Modifier.padding(end = 8.dp, bottom = 4.dp),
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor =
                                    if (isSelected)
                                        MaterialTheme.colorScheme.primaryContainer
                                    else
                                        MaterialTheme.colorScheme.surfaceVariant,
                                labelColor =
                                    if (isSelected)
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    else
                                        MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }

            // --- ПОДКАТЕГОРИИ ДЛЯ ACTIVE CATEGORY ---
            if (activeCategory != null && selectedCategories.contains(activeCategory)) {
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Refine your activity",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = "Tags for ${activeCategory.name.lowercase().replaceFirstChar { it.uppercase() }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                val filtered = subcategories.filter { it.parent == activeCategory }
                val selectedIdsForActive =
                    selectedSubcategoryIdsByCategory[activeCategory] ?: emptyList()

                if (filtered.isNotEmpty()) {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        maxItemsInEachRow = 3
                    ) {
                        filtered.forEach { sub ->
                            val isSelected = selectedIdsForActive.contains(sub.id)

                            FilterChip(
                                selected = isSelected,
                                onClick = { onSubcategoryClick(sub.id) },
                                label = {
                                    Text(
                                        text = sub.title,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                    )
                                },
                                leadingIcon = if (isSelected) {
                                    {
                                        androidx.compose.material3.Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = "Selected"
                                        )
                                    }
                                } else null,
                                modifier = Modifier.padding(4.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor =
                                        MaterialTheme.colorScheme.secondaryContainer,
                                    selectedLabelColor =
                                        MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            )
                        }
                    }
                } else {
                    Text(
                        text = "No tags for this category yet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // --- СПИСОК ВЫБРАННЫХ КАТЕГОРИЙ ПОСТРОЧНО ---
            if (selectedCategories.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Selected",
                    style = MaterialTheme.typography.titleSmall
                )

                selectedCategories.forEach { cat ->
                    val catData = categories.firstOrNull { it.id == cat }
                    val emoji = catData?.emoji ?: "•"
                    val title =
                        catData?.title ?: cat.name.lowercase().replaceFirstChar { it.uppercase() }

                    val selectedIds = selectedSubcategoryIdsByCategory[cat] ?: emptyList()
                    val subsForCat = subcategories
                        .filter { it.parent == cat && selectedIds.contains(it.id) }

                    val line = if (subsForCat.isNotEmpty()) {
                        "$emoji $title: " + subsForCat.joinToString(", ") { it.title }
                    } else {
                        "$emoji $title"
                    }

                    Text(
                        text = line,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (error != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = error,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
