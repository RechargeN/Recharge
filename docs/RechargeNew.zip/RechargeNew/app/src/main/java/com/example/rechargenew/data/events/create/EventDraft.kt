package com.example.rechargenew.data.events.create

import com.example.rechargenew.data.events.EventLocation
import com.example.rechargenew.model.EventCategory
import com.example.rechargenew.model.EventKind
import com.example.rechargenew.model.TimeOfDay
/**
 * Черновик создаваемого события.
 * Теперь поддерживает несколько основных категорий.
 */
data class EventDraft(
    val title: String = "",
    val description: String = "",

    // несколько основных категорий
    val categories: List<EventCategory> = emptyList(),

    // подкатегории по категориям
    val subcategoryIdsByCategory: Map<EventCategory, List<String>> = emptyMap(),

    // дата/время (для разовых событий)
    val dateTimeMillis: Long? = null,

    val price: Double? = null,

    // место
    val location: EventLocation? = null,

    // фото
    val photoUri: String? = null,           // обложка
    val photoUris: List<String> = emptyList(), // все фото

    // НОВОЕ: тип события
    val kind: EventKind = EventKind.ONE_TIME,

    // НОВОЕ: когда уместно рекомендовать (для PLACE)
    val recommendedTimes: List<TimeOfDay> = emptyList()
)
