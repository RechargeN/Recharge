package com.example.rechargenew.data.events

import com.example.rechargenew.ui.events.EventModel

/**
 * Интерфейс "лёгкого сервера".
 * Сейчас его реализует LocalMockApi.
 * Потом можно сделать FirestoreEventApi / SupabaseEventApi с теми же методами.
 */
interface EventApi {

    suspend fun getAllEvents(): List<EventModel>

    suspend fun searchEvents(
        query: String?,
        category: String?,
        minPrice: Double?,
        maxPrice: Double?
    ): List<EventModel>

    suspend fun getNearbyEvents(
        lat: Double,
        lon: Double,
        radiusKm: Double,
        category: String?
    ): List<EventModel>

    suspend fun getEventById(id: String): EventModel?

    /**
     * Добавить новое событие (режим организатора).
     * В будущем этот метод будет писать в Firestore / Supabase.
     */
    suspend fun addEvent(event: EventModel)

}
