package com.example.rechargenew.data.explore.entities.model

data class PlaceEntity(
    val id: String,
    val title: String,
    val about: String,
    val tags: List<String> = emptyList()
)
