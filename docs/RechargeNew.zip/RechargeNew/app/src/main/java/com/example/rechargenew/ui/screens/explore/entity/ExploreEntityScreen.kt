package com.example.rechargenew.ui.screens.explore.entity

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rechargenew.ui.events.EventCard
import com.example.rechargenew.ui.events.EventModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreEntityScreen(
    entityType: String,
    entityId: String,
    onBack: () -> Unit,
    onOpenEvent: (String) -> Unit,
    vm: ExploreEntityViewModel = viewModel()
) {
    val flow = remember(entityType, entityId) { vm.state(entityType, entityId) }
    val ui by flow.collectAsState()

    var tab by remember { mutableStateOf(ExploreEntityTab.UPCOMING) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = ui.header.title.ifBlank { "Entity" },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (ui.header.subtitle.isNotBlank()) {
                            Text(
                                text = ui.header.subtitle,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
        ) {

            // Tabs
            ExploreEntityTabs(tab = tab, onTab = { tab = it })
            Spacer(Modifier.height(10.dp))

            // Content
            when (tab) {
                ExploreEntityTab.UPCOMING -> EventsList(
                    events = ui.upcoming,
                    emptyText = "No upcoming events",
                    onOpenEvent = onOpenEvent
                )

                ExploreEntityTab.PAST -> EventsList(
                    events = ui.past,
                    emptyText = "No past events",
                    onOpenEvent = onOpenEvent
                )

                ExploreEntityTab.PHOTOS -> PhotosGrid(
                    urls = ui.photoUrls,
                    emptyText = "No photos yet"
                )
            }

            // About (always at bottom like in our scheme)
            Spacer(Modifier.height(10.dp))
            ExploreEntityAboutBlock(about = ui.about, tags = ui.tags)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun EventsList(
    events: List<EventModel>,
    emptyText: String,
    onOpenEvent: (String) -> Unit
) {
    if (events.isEmpty()) {
        Text(emptyText, modifier = Modifier.padding(16.dp))
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(events, key = { it.id }) { event ->
            EventCard(
                event = event,
                onClick = { onOpenEvent(event.id) },
                onToggleFavorite = { /* позже */ }
            )
        }
    }
}

@Composable
private fun PhotosGrid(
    urls: List<String>,
    emptyText: String
) {
    if (urls.isEmpty()) {
        Text(emptyText, modifier = Modifier.padding(16.dp))
        return
    }

    // MVP: сетка, пока без картинок (только url текстом не делаем).
    // Если позже захочешь — подключим Coil AsyncImage.
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 200.dp, max = 420.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(urls) { _ ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
            ) {}
        }
    }
}
