package com.example.rechargenew.ui.features.explore.entity.blocks

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AboutBlock(about: String, tags: List<String>) {
    if (about.isBlank() && tags.isEmpty()) return

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("About", style = MaterialTheme.typography.titleMedium)
        if (about.isNotBlank()) {
            Text(about, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 6.dp))
        }
        if (tags.isNotEmpty()) {
            Text(
                tags.joinToString("  •  "),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
