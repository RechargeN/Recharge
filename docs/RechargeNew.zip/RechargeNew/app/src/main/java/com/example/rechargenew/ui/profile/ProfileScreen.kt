package com.example.rechargenew.ui.profile

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rechargenew.ui.profile.components.ProfileHeader
import com.example.rechargenew.ui.profile.components.ProfileMenuItem
import com.example.rechargenew.ui.profile.components.ProfileSectionHeader
import com.example.rechargenew.ui.profile.components.SpacerBlock

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    // главное: коллбэк для открытия консоли организатора
    onCreateEventClick: () -> Unit = {}
) {

    // временно жёстко задаём данные, потом вытащишь из ViewModel
    val name = "Nikita"
    val city = "Amsterdam"
    val status = "Explorer"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "My Recharge") },
                actions = {
                    IconButton(onClick = { /* TODO: open settings */ }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {

            ProfileHeader(
                name = name,
                city = city,
                status = status,
                onEditClick = { /* TODO: open edit profile */ }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // --- My favourites & searches ---
            ProfileSectionHeader(title = "My favourites & searches")

            ProfileMenuItem(
                icon = Icons.Default.FavoriteBorder,
                title = "Favourite activities",
                onClick = { /* TODO: open favourites */ }
            )

            ProfileMenuItem(
                icon = Icons.Default.Search,
                title = "Saved searches",
                badgeText = "New",
                onClick = { /* TODO: open saved searches */ }
            )

            SpacerBlock()

            // --- My activity ---
            ProfileSectionHeader(title = "My activity")

            ProfileMenuItem(
                icon = Icons.Default.Event,
                title = "My bookings",
                onClick = { /* TODO: open bookings */ }
            )

            ProfileMenuItem(
                icon = Icons.Default.History,
                title = "Visited & history",
                onClick = { /* TODO: open history */ }
            )

            ProfileMenuItem(
                icon = Icons.Default.StarBorder,
                title = "My reviews",
                onClick = { /* TODO: open reviews */ }
            )

            SpacerBlock()

            // --- Organizer tools (ВАЖНО!) ---
            ProfileSectionHeader(title = "Organizer")

            ProfileMenuItem(
                icon = Icons.Default.Add,
                title = "Create activity",
                onClick = onCreateEventClick   // ← вот здесь вызывается экран создания события
            )

            SpacerBlock()

            // --- Payments & friends ---
            ProfileSectionHeader(title = "Payments & friends")

            ProfileMenuItem(
                icon = Icons.Default.CreditCard,
                title = "Payments",
                onClick = { /* TODO: open payments */ }
            )

            ProfileMenuItem(
                icon = Icons.Default.Group,
                title = "Invite a friend",
                onClick = { /* TODO: open invite */ }
            )

            SpacerBlock()

            // --- Settings & privacy ---
            ProfileSectionHeader(title = "Settings & privacy")

            ProfileMenuItem(
                icon = Icons.Default.Security,
                title = "Privacy preferences",
                onClick = { /* TODO: open privacy */ }
            )

            ProfileMenuItem(
                icon = Icons.Default.Info,
                title = "Help & info",
                onClick = { /* TODO: open help */ }
            )

            SpacerBlock()

            // --- Logout ---
            ProfileMenuItem(
                icon = Icons.Default.ExitToApp,
                title = "Log out",
                isDestructive = true,
                onClick = { /* TODO: logout */ }
            )
        }
    }
}
