package com.example.rechargenew.ui.features.explore.entity.model

data class EntityHeaderUi(
    val title: String = "",
    val subtitle: String = "",
    val avatarUrl: String? = null,
    val coverUrl: String? = null,
    val badges: List<String> = emptyList()
)