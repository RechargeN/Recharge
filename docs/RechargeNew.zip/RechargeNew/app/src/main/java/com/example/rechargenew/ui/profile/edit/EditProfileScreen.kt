package com.example.rechargenew.ui.profile.edit

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Модель редактируемого профиля.
 * Можно потом вынести в общий пакет models, если захочешь.
 */
data class EditableProfile(
    val name: String = "",
    val city: String = "",
    val status: String = "",
    val about: String = ""
)

/**
 * BD1.1 — экран редактирования профиля.
 *
 * @param initialProfile - стартовые данные пользователя
 * @param onBack - вернуться назад (на профиль)
 * @param onSave - сохранить изменения (отдаём наружу обновлённый EditableProfile)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    initialProfile: EditableProfile = EditableProfile(
        name = "Nikita",
        city = "Amsterdam",
        status = "Explorer",
        about = ""
    ),
    onBack: () -> Unit = {},
    onSave: (EditableProfile) -> Unit = {}
) {
    var name by remember { mutableStateOf(initialProfile.name) }
    var city by remember { mutableStateOf(initialProfile.city) }
    var status by remember { mutableStateOf(initialProfile.status) }
    var about by remember { mutableStateOf(initialProfile.about) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Edit profile",
                        fontWeight = FontWeight.SemiBold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            onSave(
                                EditableProfile(
                                    name = name.trim(),
                                    city = city.trim(),
                                    status = status.trim(),
                                    about = about.trim()
                                )
                            )
                        }
                    ) {
                        Text("Save")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Имя
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Город
            OutlinedTextField(
                value = city,
                onValueChange = { city = it },
                label = { Text("City") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Статус (типа Explorer / Active / Night owl и т.д.)
            OutlinedTextField(
                value = status,
                onValueChange = { status = it },
                label = { Text("Status") },
                singleLine = true,
                supportingText = {
                    Text("Например: Explorer, Night owl, Sport lover")
                },
                modifier = Modifier.fillMaxWidth()
            )

            // О себе
            OutlinedTextField(
                value = about,
                onValueChange = { about = it },
                label = { Text("About me") },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false),
                minLines = 3
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Кнопка Save внизу (дублирует кнопку в top bar — удобно на долгих формах)
            Button(
                onClick = {
                    onSave(
                        EditableProfile(
                            name = name.trim(),
                            city = city.trim(),
                            status = status.trim(),
                            about = about.trim()
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text("Save changes")
            }
        }
    }
}
