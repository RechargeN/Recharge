package com.example.rechargenew.ui.map

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapRadiusSheet(
    currentRadiusMeters: Int?,
    onDismiss: () -> Unit,
    onPreview: (Int?) -> Unit,
    onCommit: (Int?) -> Unit
) {
    // state synced to incoming value
    var unlimited by remember(currentRadiusMeters) { mutableStateOf(currentRadiusMeters == null) }

    var kmValue by remember(currentRadiusMeters) {
        mutableFloatStateOf(
            when (val r = currentRadiusMeters) {
                null -> 5f
                else -> (r / 1000f).coerceIn(1f, 50f)
            }
        )
    }

    fun metersFromKm(km: Float): Int =
        km.roundToInt().coerceIn(1, 50) * 1000

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Радиус", style = MaterialTheme.typography.titleLarge)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Без ограничения")
                Switch(
                    checked = unlimited,
                    onCheckedChange = { checked ->
                        unlimited = checked
                        onPreview(if (checked) null else metersFromKm(kmValue))
                    }
                )
            }

            if (!unlimited) {
                Text(
                    "Текущий: ${kmValue.roundToInt().coerceIn(1, 50)} км",
                    style = MaterialTheme.typography.titleMedium
                )

                Slider(
                    value = kmValue,
                    onValueChange = { v ->
                        kmValue = v
                        onPreview(metersFromKm(v)) // live preview
                    },
                    valueRange = 1f..50f,
                    steps = 48
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    listOf(1, 3, 5, 10, 25, 50).forEach { km ->
                        AssistChip(
                            onClick = {
                                kmValue = km.toFloat()
                                onPreview(km * 1000) // live preview
                            },
                            label = { Text("$km") }
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss) { Text("Отмена") }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        val result = if (unlimited) null else metersFromKm(kmValue)
                        onCommit(result)
                        onDismiss()
                    }
                ) { Text("Применить") }
            }

            Spacer(Modifier.height(18.dp))
        }
    }
}
