package com.example.rechargenew.ui.features.explore.manage

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rechargenew.ui.features.explore.manage.blocks.EntityRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyEntitiesScreen(
    onBack: () -> Unit,
    onOpenEntity: (type: String, id: String) -> Unit,
    vm: MyEntitiesViewModel = viewModel()
) {
    val ui by vm.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { androidx.compose.material3.Text("My pages") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) {
        LazyColumn {
            items(ui.items, key = { it.type + it.id }) { item ->
                EntityRow(item = item, onClick = { onOpenEntity(item.type, item.id) })
            }
        }
    }
}
