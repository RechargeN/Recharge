package com.example.rechargenew.ui.profile.payments

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.clickable

data class PaymentMethod(
    val id: String,
    val type: String,    // "Visa", "Mastercard", "iDeal"
    val masked: String   // "**** 1234"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentsScreen(
    methods: List<PaymentMethod>,
    onBack: () -> Unit = {},
    onAddMethodClick: () -> Unit = {},
    onMethodClick: (PaymentMethod) -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Payments") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(onClick = onAddMethodClick) {
                        Text("Add")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (methods.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
            ) {
                Text("No payment methods yet.")
                Spacer(Modifier.height(4.dp))
                Text(
                    "Add a card or method to pay for tickets and activities.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                items(methods) { method ->
                    PaymentMethodItem(
                        item = method,
                        onClick = { onMethodClick(method) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PaymentMethodItem(
    item: PaymentMethod,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text("${item.type} ${item.masked}", style = MaterialTheme.typography.bodyLarge)
        Divider(Modifier.padding(top = 12.dp))
    }
}
