package com.example.rechargenew.ui.dcba

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DCBAScreen() {
    var text by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.padding(16.dp)
    ) {
        Text("Экран DCBA – умный поиск по желанию пользователя")

        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Что ты хочешь делать?") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp)
        )

        Button(
            onClick = { /* TODO: обработать запрос и выдать предложения D */ },
            modifier = Modifier.padding(top = 8.dp)
        ) {
            Text("Найти варианты")
        }
    }
}
