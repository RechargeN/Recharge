package com.example.rechargenew.ui.map

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun MapRadiusSelector(
    selectedRadius: Int?,
    onRadiusSelected: (Int?) -> Unit,
    modifier: Modifier = Modifier
) {
    // Источник правды: если selectedRadius == null -> без ограничений
    val noLimit = selectedRadius == null

    // UI значения (км)
    var sliderKm by rememberSaveable { mutableStateOf(3f) }
    var inputKmText by rememberSaveable { mutableStateOf("3") }

    // ✅ Синхронизация UI с внешним состоянием
    LaunchedEffect(selectedRadius) {
        if (selectedRadius != null) {
            val km = (selectedRadius / 1000f).coerceIn(1f, 100f)
            sliderKm = km
            inputKmText = km.roundToInt().toString()
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = noLimit,
                    onCheckedChange = { checked ->
                        if (checked) {
                            onRadiusSelected(null)
                        } else {
                            val meters = sliderKm.roundToInt() * 1000
                            onRadiusSelected(meters)
                        }
                    }
                )
                Text(
                    text = "Без ограничения по радиусу",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (!noLimit) {
                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Радиус: ${sliderKm.roundToInt()} км (~${sliderKm.roundToInt() * 1000} м)",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start
                )

                Spacer(modifier = Modifier.height(4.dp))

                Slider(
                    value = sliderKm,
                    onValueChange = { value ->
                        sliderKm = value.coerceIn(0.001f, 100f) // ✅ можно хоть 1 метр
                        val meters = (sliderKm * 1000).roundToInt().coerceAtLeast(1)
                        inputKmText = if (sliderKm < 1f) {
                            // показываем метры, если меньше 1 км
                            (meters).toString()
                        } else {
                            sliderKm.roundToInt().toString()
                        }
                        onRadiusSelected(meters)
                    },
                    valueRange = 0.001f..100f,  // ✅ 1 метр .. 100 км
                    steps = 0,                  // ✅ непрерывный, можно ставить в любую точку
                    modifier = Modifier.fillMaxWidth(),
                    colors = SliderDefaults.colors()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = inputKmText,
                    onValueChange = { newText ->
                        inputKmText = newText

                        // ✅ Разрешаем ввод в метрах или км — простой вариант:
                        // если число <= 100 -> считаем что это км
                        // если > 100 -> считаем что это метры
                        val n = newText.toIntOrNull() ?: return@OutlinedTextField

                        if (n in 1..100) {
                            sliderKm = n.toFloat()
                            onRadiusSelected(n * 1000)
                        } else if (n in 1..100000) {
                            sliderKm = (n / 1000f).coerceIn(0.001f, 100f)
                            onRadiusSelected(n)
                        }
                    },
                    label = { Text("Радиус (введи км ≤100 или метры >100)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
