package com.example.rechargenew.domain.explore.usecases

import com.example.rechargenew.domain.explore.model.EntityType

data class MyEntityDomainItem(
    val type: EntityType,
    val id: String,
    val title: String
)

interface GetMyEntitiesUseCase {
    suspend fun execute(): ExploreResult<List<MyEntityDomainItem>>
}
