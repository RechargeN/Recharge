package com.example.rechargenew.domain.explore.usecases

import com.example.rechargenew.data.explore.entities.MyEntitiesRepository
import com.example.rechargenew.data.explore.session.SessionRepository
import kotlinx.coroutines.flow.first

class GetMyEntitiesUseCaseImpl(
    private val session: SessionRepository,
    private val myEntitiesRepository: MyEntitiesRepository
) : GetMyEntitiesUseCase {

    override suspend fun execute(): ExploreResult<List<MyEntityDomainItem>> {
        return try {
            val roles = session.rolesFlow.first()
            val items = myEntitiesRepository.buildMyEntities(
                userId = session.userId,
                roles = roles
            )
            ExploreResult.Success(items)
        } catch (e: Exception) {
            ExploreResult.Error(e.message ?: "Failed to load my pages", e)
        }
    }
}
