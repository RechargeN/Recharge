package com.example.rechargenew.domain.multistop

import com.example.rechargenew.data.filters.FilterState


class GuidedAlternativesEngine {

    fun build(
        filter: FilterState,
        exactMatchesCount: Int,
        itinerariesCount: Int,
        cheapestSingleOptionTotal: Double? = null,
        shortestTravelMinutes: Int? = null,
        minRequiredMinutesForPlan: Int? = null
    ): GuidedAlternativesResult {

        val reasons = mutableListOf<FailureReason>()
        val suggestions = mutableListOf<SuggestedAdjustment>()

        val hasExact = exactMatchesCount > 0 || itinerariesCount > 0
        if (hasExact) {
            return GuidedAlternativesResult(
                originalRequestSupported = true,
                failureReasons = emptyList(),
                suggestedAlternatives = emptyList()
            )
        }

        // 1. Бюджет
        val currentBudget = filter.maxPrice ?: filter.budgetMaxInput?.toDouble()
        if (currentBudget != null &&
            cheapestSingleOptionTotal != null &&
            cheapestSingleOptionTotal > currentBudget
        ) {
            val recommendedBudget = roundUpBudget(cheapestSingleOptionTotal)

            reasons += FailureReason(
                type = FailureReasonType.BUDGET_TOO_LOW,
                message = "Под текущий бюджет подходящих вариантов не найдено. Ближайший вариант начинается примерно от €${formatMoney(cheapestSingleOptionTotal)}."
            )

            suggestions += SuggestedAdjustment(
                type = AlternativeType.INCREASE_BUDGET,
                title = "Увеличить бюджет",
                description = "Поднять общий бюджет до €${formatMoney(recommendedBudget)}.",
                newBudgetTotal = recommendedBudget
            )
        }

        // 2. Время в пути
        if (filter.maxTravelTimeMinutes != null &&
            shortestTravelMinutes != null &&
            shortestTravelMinutes > filter.maxTravelTimeMinutes
        ) {
            val recommendedTravelTime = roundUpMinutes(shortestTravelMinutes)

            reasons += FailureReason(
                type = FailureReasonType.TRAVEL_TIME_TOO_SHORT,
                message = "Под текущий лимит времени в пути подходящих вариантов не найдено. Ближайшее подходящее время — около $shortestTravelMinutes мин."
            )

            suggestions += SuggestedAdjustment(
                type = AlternativeType.INCREASE_TRAVEL_TIME,
                title = "Увеличить время в пути",
                description = "Поднять лимит дороги до $recommendedTravelTime мин.",
                newMaxTravelTimeMinutes = recommendedTravelTime
            )
        }

        // 3. Свободное время / число точек
        if (filter.multiStopEnabled && filter.freeTimeMinutes != null && minRequiredMinutesForPlan != null) {
            if (minRequiredMinutesForPlan > filter.freeTimeMinutes) {
                reasons += FailureReason(
                    type = FailureReasonType.FREE_TIME_TOO_SHORT,
                    message = "Маршрут не помещается в доступное время. Минимально нужно около $minRequiredMinutesForPlan мин."
                )

                if (filter.maxStops > 1) {
                    suggestions += SuggestedAdjustment(
                        type = AlternativeType.REDUCE_STOPS,
                        title = "Уменьшить число посещений",
                        description = "Снизить количество точек с ${filter.maxStops} до ${filter.maxStops - 1}.",
                        newMaxStops = (filter.maxStops - 1).coerceAtLeast(1)
                    )
                }

                if (filter.includeReturnTrip) {
                    suggestions += SuggestedAdjustment(
                        type = AlternativeType.DISABLE_RETURN_TRIP,
                        title = "Не учитывать обратную дорогу",
                        description = "Убрать возврат в расчёте времени маршрута.",
                        newIncludeReturnTrip = false
                    )
                }
            }
        }

        // 4. Если ничего конкретного не нашли
        if (reasons.isEmpty()) {
            reasons += FailureReason(
                type = FailureReasonType.NO_MATCHES_FOUND,
                message = "По текущим параметрам подходящих вариантов не найдено."
            )
        }

        return GuidedAlternativesResult(
            originalRequestSupported = false,
            failureReasons = reasons.distinctBy { it.type },
            suggestedAlternatives = suggestions
                .distinctBy { it.type }
                .take(3)
        )
    }

    private fun roundUpBudget(value: Double): Double {
        val step = 5.0
        return kotlin.math.ceil(value / step) * step
    }

    private fun roundUpMinutes(value: Int): Int {
        val step = 5
        return ((value + step - 1) / step) * step
    }

    private fun formatMoney(value: Double): String {
        return if (value % 1.0 == 0.0) {
            value.toInt().toString()
        } else {
            "%.2f".format(value)
        }
    }
}