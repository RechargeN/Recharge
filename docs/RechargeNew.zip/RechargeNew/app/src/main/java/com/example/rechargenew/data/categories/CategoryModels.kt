package com.example.rechargenew.data.categories

import com.example.rechargenew.model.EventCategory

/**
 * Модель категории для блока C.
 */
data class CategoryData(
    val id: EventCategory,  // enum, например EventCategory.MUSIC
    val title: String,
    val subtitle: String,
    val emoji: String
)

/**
 * Модель подкатегории для блока C (C-sub).
 *
 * id – строковый (из subcategories.json), parent – enum EventCategory.
 */
data class SubcategoryData(
    val id: String,                // "music_concerts"
    val parent: EventCategory,     // EventCategory.MUSIC
    val title: String              // "Concerts"
)
