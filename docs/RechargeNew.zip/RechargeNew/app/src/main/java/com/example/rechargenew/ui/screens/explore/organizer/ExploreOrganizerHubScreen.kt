package com.example.rechargenew.ui.screens.explore.organizer

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreOrganizerHubScreen(
    onCreateEvent: () -> Unit,
    onMyEvents: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Organizer") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Text("←")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Manage your activities",
                style = MaterialTheme.typography.titleMedium
            )

            Button(
                onClick = onCreateEvent,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Create activity")
            }

            OutlinedButton(
                onClick = onMyEvents,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("My events")
            }
        }
    }
}
