package com.example.rechargenew.domain.explore.usecases

interface GetEntityPageUseCase {
    suspend fun execute(input: EntityPageInput): ExploreResult<EntityPageDomain>
}
