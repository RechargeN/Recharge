package com.example.rechargenew.ui.categories

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.rechargenew.data.categories.CategoriesRepository
import com.example.rechargenew.data.events.EventRepository
import com.example.rechargenew.model.EventCategory
import com.example.rechargenew.ui.events.EventCard
import com.example.rechargenew.ui.events.EventModel
import com.example.rechargenew.ui.events.filterEventsByCategoryAndSubcategory

/**
 * Экран C + D:
 *  - сверху: горизонтальный список категорий (мультивыбор)
 *  - ниже: подкатегории (мультивыбор, объединение субов выбранных категорий)
 *  - снизу: лента событий D, отфильтрованных по выбору
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoriesScreen(
    viewModel: CategoriesViewModel = viewModel(),
    onCategoryClickExternal: (EventCategory) -> Unit = {},
    onEventClick: (String) -> Unit = {}
) {
    val context = LocalContext.current

    // Категории из VM
    val categories by viewModel.categories.collectAsState()

    // Все субкатегории (загружаем один раз)
    var allSubcategories by remember { mutableStateOf<List<SubcategoryItem>>(emptyList()) }

    // Локальное состояние выбора
    var selectedCategories by remember { mutableStateOf<Set<EventCategory>>(emptySet()) }
    var selectedSubcategoryIds by remember { mutableStateOf<Set<String>>(emptySet()) }

    // События
    var allEvents by remember { mutableStateOf<List<EventModel>>(emptyList()) }
    var filteredEvents by remember { mutableStateOf<List<EventModel>>(emptyList()) }

    // Загружаем категории, субкатегории и события один раз
    LaunchedEffect(Unit) {
        viewModel.loadCategories(context)

        val subsData = CategoriesRepository.getSubcategories(context)
        allSubcategories = subsData.map { it.toUi() }

        val events = EventRepository.getAllEvents()
        allEvents = events
        filteredEvents = events
    }

    // Какие субкатегории показывать: объединение для выбранных категорий
    val visibleSubcategories = remember(allSubcategories, selectedCategories) {
        if (selectedCategories.isEmpty()) {
            emptyList()
        } else {
            allSubcategories.filter { it.parent in selectedCategories }
        }
    }

    // Пересчитываем фильтр при изменении условий
    LaunchedEffect(allEvents, selectedCategories, selectedSubcategoryIds) {
        filteredEvents = filterEventsByCategoryAndSubcategory(
            allEvents = allEvents,
            selectedCategories = selectedCategories,
            selectedSubcategoryIds = selectedSubcategoryIds
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Categories") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .background(MaterialTheme.colorScheme.background)
        ) {

            // ---- Ряд категорий (C, мультивыбор) ----
            Text(
                text = "Choose categories",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { category ->
                    val isSelected = selectedCategories.contains(category.id)

                    CategoryChip(
                        category = category,
                        isSelected = isSelected,
                        onClick = {
                            selectedCategories =
                                if (isSelected) {
                                    selectedCategories - category.id
                                } else {
                                    selectedCategories + category.id
                                }

                            // при смене категорий убираем субы,
                            // которые к ним больше не относятся
                            selectedSubcategoryIds =
                                selectedSubcategoryIds.filter { subId ->
                                    allSubcategories.any {
                                        it.id == subId && it.parent in selectedCategories
                                    }
                                }.toSet()

                            onCategoryClickExternal(category.id)
                        }
                    )
                }
            }

            // ---- Подкатегории (C-sub, мультивыбор) ----
            if (visibleSubcategories.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Refine by subcategories",
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(modifier = Modifier.height(4.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(visibleSubcategories, key = { it.id }) { sub ->
                        val isSelected = selectedSubcategoryIds.contains(sub.id)

                        SubcategoryChip(
                            subcategory = sub,
                            isSelected = isSelected,
                            onClick = {
                                selectedSubcategoryIds =
                                    if (isSelected) {
                                        selectedSubcategoryIds - sub.id
                                    } else {
                                        selectedSubcategoryIds + sub.id
                                    }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ---- Лента D ----
            Text(
                text = "Matching activities",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (filteredEvents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No activities for this combination yet.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredEvents, key = { it.id }) { event ->
                        EventCard(
                            event = event,
                            onClick = { id -> onEventClick(id) },
                            onToggleFavorite = { e ->
                                val toggled = e.copy(isFavorite = !e.isFavorite)
                                allEvents = allEvents.map {
                                    if (it.id == toggled.id) toggled else it
                                }

                                filteredEvents = filterEventsByCategoryAndSubcategory(
                                    allEvents = allEvents,
                                    selectedCategories = selectedCategories,
                                    selectedSubcategoryIds = selectedSubcategoryIds
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

// ---------- UI-элементы для чипов ----------

@Composable
private fun CategoryChip(
    category: CategoryItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(50),
        color = if (isSelected)
            MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
        else
            MaterialTheme.colorScheme.surface,
        tonalElevation = if (isSelected) 2.dp else 0.dp
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = category.emoji,
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(
                    text = category.title,
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (category.subtitle.isNotBlank()) {
                    Text(
                        text = category.subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun SubcategoryChip(
    subcategory: SubcategoryItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(50),
        color = if (isSelected)
            MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f)
        else
            MaterialTheme.colorScheme.surface,
        tonalElevation = if (isSelected) 1.dp else 0.dp
    ) {
        Text(
            text = subcategory.title,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
